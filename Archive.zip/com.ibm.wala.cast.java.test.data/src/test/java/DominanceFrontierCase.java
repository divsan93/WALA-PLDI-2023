public class DominanceFrontierCase {

  public static void main(String[] args) {
    (new DominanceFrontierCase()).convert(3);
  }

    public int convert(Integer i) {
        switch (i.intValue()) {
        default:
            return 1;
        }
    }
}
