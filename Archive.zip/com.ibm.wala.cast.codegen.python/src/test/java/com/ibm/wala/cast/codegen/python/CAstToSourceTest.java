package com.ibm.wala.cast.codegen.python;

import org.junit.Test;

import static org.junit.Assert.*;

public class CAstToSourceTest {
    @Test
    public void testGeneratedSourceIsOverriden() {
        assertEquals("Python", (new CAstToPython()).generatedCode);
    }

}