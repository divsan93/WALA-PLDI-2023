package com.ibm.wala.cast.codegen.python;

import com.ibm.wala.analysis.typeInference.TypeInference;
import com.ibm.wala.cast.codegen.toSource.ToSource;
import com.ibm.wala.cast.tree.CAst;
import com.ibm.wala.cast.tree.CAstNode;
import com.ibm.wala.cast.tree.impl.CAstImpl;
import com.ibm.wala.cast.tree.visit.CAstVisitor;
import com.ibm.wala.ipa.cfg.ExceptionPrunedCFG;
import com.ibm.wala.ipa.cfg.PrunedCFG;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.ISSABasicBlock;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.types.FieldReference;
import com.ibm.wala.types.MethodReference;
import com.ibm.wala.types.TypeReference;
import com.ibm.wala.util.intset.IntSetUtil;
import com.ibm.wala.util.intset.MutableIntSet;

import java.util.LinkedList;
import java.util.List;

public class CAstToPython extends ToSource {
    public static String generatedCode="";

    static void println(String input)
    {
        System.err.println(input);
        generatedCode = generatedCode + input + "\n";
    }

    static void print(String input)
    {
        System.err.print(input);
        generatedCode = generatedCode + input;
    }

    @Override
    public void translate(IR ir, IClassHierarchy cha, TypeInference types) {
        PrunedCFG<SSAInstruction, ISSABasicBlock> cfg =
                ExceptionPrunedCFG.makeUncaught(ir.getControlFlowGraph());

        RegionTreeNode root = makeTreeNode(ir, cha, types, cfg);

        System.out.println("tree");
        System.out.println(root);
        CAstNode ast = root.toCAst();
        System.out.println("CAst tree");
        System.out.println(ast);

        CAst cast = new CAstImpl();
        MutableIntSet done = IntSetUtil.make();
        List<CAstNode> inits = new LinkedList<>();
        root.mergedValues.foreach(
                vn -> {
                    vn = root.mergePhis.find(vn);
                    if (!done.contains(vn)) {
                        done.add(vn);
                        inits.add(
                                cast.makeNode(
                                        CAstNode.DECL_STMT,
                                        cast.makeNode(CAstNode.VAR, cast.makeConstant("var_" + vn)),
                                        cast.makeConstant(types.getType(vn))));
                    }
                });

        assert ast.getKind() == CAstNode.BLOCK_STMT;
        for (CAstNode c : ast.getChildren()) {
            inits.add(c);
        }
        ast = cast.makeNode(CAstNode.BLOCK_STMT, inits);

        PythonVisitor toPython = new PythonVisitor(0);
        toPython.visit(ast, new TypeInferenceContext(types), toPython);
    }

    public static class PythonVisitor extends ToTargetVisitor {
        public PythonVisitor(int indent) {
            super(indent);
        }

        @Override
        protected void indent() {
            for (int i = 0; i < indent; i++) {
            print("  ");
            }
        }

        @Override
        protected boolean visitDeclStmt(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            indent();
            visit(n.getChild(0), c, visitor);
            print(": " + n.getChild(1).getValue());
            if (n.getChildCount() > 2) {
                print(" = ");
                visit(n.getChild(2), c, visitor);
            }
            println("");
            return true;
        }


        @Override
        protected boolean visitBlockStmt(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {

            indent();
            PythonVisitor pythonVisitor = new PythonVisitor(indent + 1);
            for (CAstNode child: n.getChildren()) {
                pythonVisitor.visit(child, c, pythonVisitor);
            }
            println("");
            return true;
            }


        @Override
        protected boolean visitConstant(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
                Object val = n.getValue();
                if (val instanceof FieldReference) {
                    print(((FieldReference) val).getName().toString());
                } else {
                    print(val.toString());
                }
                return true;
            }


        @Override
        protected boolean visitVar(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            print(n.getChild(0).getValue().toString());
            return true;
            }


        @Override
        public boolean visitAssign(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            indent();
            visit(n.getChild(0), c, visitor);
            print(" = ");
            visit(n.getChild(1), c, visitor);
            return true;
        }


        @Override
        protected boolean visitCall(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            MethodReference target = (MethodReference) n.getChild(0).getValue();
            boolean isStatic = ((Boolean) n.getChild(1).getValue()).booleanValue();
            boolean isVoid = target.getReturnType()== TypeReference.Void? true: false;
            if(isVoid)
                indent();
            if ("<init>".equals(target.getName().toString())) {
                throw new UnsupportedOperationException("Constructors are not yet implemented. Open an issue if encountered.");
            } else if (isStatic) {
                print(target.getDeclaringClass().getName().toString().substring(1)+"." + target.getName() + "(");
                for (int i = 2; i < n.getChildCount(); i++) {
                    if (i != 2) {
                        print(", ");
                    }
                    visit(n.getChild(i), c, visitor);
                }
                print(")");
            } else {
                visit(n.getChild(2), c, this);
                print("." + target.getName() + "(");
                for (int i = 3; i < n.getChildCount(); i++) {
                    if (i != 3) {
                        print(", ");
                    }
                    visit(n.getChild(i), c, visitor);
                }
                print(")");
            }
            if(isVoid)
            {
                println("");
            }
            return true;
        }


        @Override
        protected boolean visitBlockExpr(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            for (int i = 0; i < n.getChildCount(); i++) {
                visit(n.getChild(i), c, visitor);
            }
            return true;
        }


        @Override
        protected boolean visitLoop(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            PythonVisitor pythonVisitor = new PythonVisitor(indent+1);
            indent();
            print("while ");
            pythonVisitor.visit(n.getChild(0), c, pythonVisitor);
            println(": ");
            pythonVisitor.visit(n.getChild(1), c, pythonVisitor);
            return true;

        }


        @Override
        protected boolean visitIfStmt(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            PythonVisitor pythonVisitor = new PythonVisitor(indent+1);
            indent();
            print("if ");
            pythonVisitor.visit(n.getChild(0), c, pythonVisitor);
            println(": ");
            pythonVisitor.visit(n.getChild(1), c, pythonVisitor);
            if (n.getChildCount() > 2) {
                // Todo: Do we need the following indent?
                indent();
                println("else:");
                pythonVisitor.visit(n.getChild(2), c, pythonVisitor);
            }
            return true;
            }


        @Override
        public boolean visitNode(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
                return false;
            }

        /**
         * @param n
         * @param context
         * @param visitor
         * @return
         */
        @Override
        protected boolean doVisit(
            CAstNode n, TypeInferenceContext context, CAstVisitor<TypeInferenceContext> visitor) {
            switch (n.getKind()) {
                case CAstNode.BREAK:
                {
                    indent();
                    println("break");
                    return true;
                }
                default:
                    break;
            }
            return true;
        }


        @Override
        protected boolean visitBinaryExpr(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            print("(");
            visit(n.getChild(1), c, this);
            print(" " + n.getChild(0).getValue() + " ");
            visit(n.getChild(2), c, this);
            print(")");
            return true;
        }


        @Override
        protected boolean visitUnaryExpr(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            print(n.getChild(0).getValue() + " ");
            visit(n.getChild(1), c, this);
            return true;
        }


        @Override
        protected boolean visitCast(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            print(n.getChild(0).getValue() + "(");
            visit(n.getChild(1), c, visitor);
            print(")");
            return true;
        }


        @Override
        protected boolean visitArrayRef(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            visit(n.getChild(0), c, visitor);
            print("[");
            visit(n.getChild(1), c, visitor);
            print("]");
            return true;
            }

        @Override
        protected boolean visitObjectRef(
            CAstNode n, TypeInferenceContext c, CAstVisitor<TypeInferenceContext> visitor) {
            visit(n.getChild(0), c, visitor);
            print(".");
            visit(n.getChild(1), c, visitor);
            return true;
            }
    }
}
