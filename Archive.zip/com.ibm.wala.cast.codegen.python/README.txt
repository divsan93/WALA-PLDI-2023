

1. Pip install JEP

2. Export LD_LIBRARY_PATH