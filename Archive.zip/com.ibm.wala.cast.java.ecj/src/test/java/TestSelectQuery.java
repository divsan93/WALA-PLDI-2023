

public class TestSelectQuery {
    public static void main (String[] args) {
        int number1, number2, sum;
        number1 =10;
        number2 = 20;
        sum = number1+ 20;
        System.out.println(sum);
    }
}
