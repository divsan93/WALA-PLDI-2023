//public class Super {
//    int x;
//    Super(int x)
//    {
//        this.x=x;
//    }
//}
