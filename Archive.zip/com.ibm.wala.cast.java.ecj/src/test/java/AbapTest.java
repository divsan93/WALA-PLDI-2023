public class AbapTest {
    public static void main(String[] args)
    {
        int number1;
        int number2;
        int Sum;
        number1 = 10;
        number2 = 20;
        Sum = number1 + number2;
        System.out.println(Sum);
    }

}
