## ModPL: Modernizing Propietary Language to Modern Programming Languages
Modernizing programming languages has always been a challenge in software engineering. Especially when the source language belongs to the legacy family and requires closed environment to operate. For instance, SAP ABAP is a proprietary language that has been created by SAP. However, codes written in such languages often require the presence of a specific environment, e.g., in case of ABAP, it is the SAP HANA. Developers that apply these programming languages to build their application logic, are tied to the environment and cannot modernize their applications easily. Currently, if needed, one needs to manually write the code written in such languages to a more modern programming language i.e., Python, to be benefitted from the modern software properties i.e., executing the code independent of closed environment, moving to microservices world, etc,. With that motivation, in this work, we are proposing to build a pipeline that takes a legacy/proprietary programming language as input and produces syntactically and semantically equivalent code in programming languages with more modern features.
## Antlr Steps
We used Antlr v4.5.3 to generate the parser and visitor.
The commands are

 ``java -jar antlr-4.5.3-complete.jar -Dlanguage=Java *.g4 -visitor``
 
 ``javac -classpath antlr-4.5.3-complete.jar *.java``

## Steps to follow to generate IR for a new language.

1. Generate the lexer and parser using Antlr4 systax. For more, please check ...
2. Use Antlr to generate the visitors for the grammar.
3. The first step is to convert the parse tree generated from the Antlr into CAst tree format. Start by taking example from JDT2CAstTranslator ...
4. Write one visitor for each statement in the grammar.

For example,

 ```
 Expr : Expr + Expr
      | Expr * Expr
      | Expr - Expr
      | Number;

Number: [0-9]+; 
```
