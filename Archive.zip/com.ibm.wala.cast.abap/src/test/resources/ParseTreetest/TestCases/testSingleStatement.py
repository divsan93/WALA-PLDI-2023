import sys
from antlr4 import *
from abapLexer import abapLexer
from abapParser import abapParser
from abapParserListener import abapParserListener
import unittest
class TestGrammarCallStatement(unittest.TestCase):
    def test_when_clause(self):
        input_stream = FileStream("when_clause.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_end_class(self):
        input_stream = FileStream("endclass.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_class_def(self):
        input_stream = FileStream("class_def.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_try_statement_line(self):
        input_stream = FileStream("try_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_endtry_statement_line(self):
        input_stream = FileStream("endtry_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_endselect(self):
        input_stream = FileStream("endselect.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_select(self):
        input_stream = FileStream("select.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_select2(self):
        input_stream = FileStream("select2.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_select3(self):
        input_stream = FileStream("select3.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_endwhile(self):
        input_stream = FileStream("endwhile.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_while_statement_line(self):
        input_stream = FileStream("while_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_endcatch(self):
        input_stream = FileStream("endcatch.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_catch_statement_line(self):
        input_stream = FileStream("catch_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_endcase(self):
        input_stream = FileStream("endcase.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_case_statement(self):
        input_stream = FileStream("case_statement.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_enddo(self):
        input_stream = FileStream("enddo.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_do_statement_line(self):
        input_stream = FileStream("do_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_endloop(self):
        input_stream = FileStream("endloop.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_loop_statement_line(self):
        input_stream = FileStream("loop_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_endif(self):
        input_stream = FileStream("endif.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_if_statement_line(self):
        input_stream = FileStream("if_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_elseif(self):
        input_stream = FileStream("elseif.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_elseT(self):
        input_stream = FileStream("else.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_endat(self):
        input_stream = FileStream("endat.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_at(self):
        input_stream = FileStream("at.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_enddefine(self):
        input_stream = FileStream("enddefine.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_define_statement_line(self):
        input_stream = FileStream("define_statement_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))


    def test_endchain(self):
        input_stream = FileStream("endchain.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_chain(self):
        input_stream = FileStream("chain.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))


    def test_endform(self):
        input_stream = FileStream("endform.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_form_definition_line(self):
        input_stream = FileStream("form_definition_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_endmethod(self):
        input_stream = FileStream("endmethod.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_method_definition_line(self):
        input_stream = FileStream("method_definition_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_endmodule(self):
        input_stream = FileStream("endmodule.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_module_form_line(self):
        input_stream = FileStream("module_form_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_endfunction(self):
        input_stream = FileStream("endfunction.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

    def test_function_definition_line(self):
        input_stream = FileStream("function_definition_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))

if __name__ == '__main__':
    unittest.main()
        #Passed
        #when_clause()
        #Passed
        #end_class()
        #Passed
        #class_def()
        #Passed
        #endtry_statement_line()
        #Passed
        #try_statement_line()
        #Passed
        #endselect()
        #Passed
        #select()
        #Failed
        #select2()
        #Failed
        #select3()
        #Passed
        #endwhile()
        #Passed
        #while_statement_line()
        #Passed
        #catch_statement_line()
        #Passed
        #endcatch()
        #Passed
        #endcase()
        #Passed
        #case_statement()
        #Passed
        #enddo()
        #Passed
        #do_statement_line()
        #Passed
        #endloop()
        #Passed
        #loop_statement_line()
        #Passed
        #endif()
        #Passed
        #if_statement_line()
        #Passed
        #elseT()
        #Passed
        #elseif()
        #Passed
        #endat()
        #Passed
        #at()
        #Passed
        #enddefine()
        #Passed
        #if_statement_line()
        #Passed
        #endchain()
        #Passed
        #chain()
        #Passed
        #endmethod()
        #Passed
        #method_definition_line()
        #Passed
        #endform()
        #Passed
        #form_definition_line()
        #Passed
        #endmodule()
        #Passed
        #module_form_line()
        #Passed
        #endfunction()
        #Passed
        #function_definition_line()

# 37 Test Cases
# Passed 35   
# Failed 2 test_select3, test_select2, 