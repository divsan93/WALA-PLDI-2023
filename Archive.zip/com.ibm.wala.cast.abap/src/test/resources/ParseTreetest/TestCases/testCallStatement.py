import sys
from antlr4 import *
from abapLexer import abapLexer
from abapParser import abapParser
from abapParserListener import abapParserListener
import unittest
class TestGrammarCallStatement(unittest.TestCase):
# Post all unneccesary codes here that can be reused later.
    def test_misc(self):
        #self.assertNotIn("extraneous",input_stream)
        #self.assertNotIn("extraneous",lexer)
        #object_methods = [method_name for method_name in dir(lexer)
        #              if callable(getattr(lexer, method_name))]
        #self.assertNotIn("extraneous",dir(lexer))
        #self.assertNotIn("extraneous",lexer.getAllTokens())
        #self.assertNotIn("extraneous",stream.getTokens(0,0))
        #self.assertNotIn("extraneous",parser.__dict__.keys())
        #object_methods = [method_name for method_name in dir(parser)
        #              if callable(getattr(parser, method_name))]
        #self.assertNotIn("extraneous",object_methods)
        #tree = abapParserListener().enterNumber(parser)
        #self.assertNotIn("extraneous",tree.enter)
        #self.assertNotIn("extraneous",tree)
        return 0

    def test_test1_endmethod_definition_line(self):
        input_stream = FileStream("endmethod_definition_line.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
        listener = abapParserListener()
        walker = ParseTreeWalker()
        walker.walk(listener, tree)

    def report1(self):
        input_stream = FileStream("code.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_clear_stmt(self):
        input_stream = FileStream("clear_statement.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_clear_stmt2(self):
        input_stream = FileStream("clear_statement2.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_dialog(self):
        input_stream = FileStream("call_dialog.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_method(self):
        input_stream = FileStream("call_method.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_method_of(self):
        #No example found in the SAP Abap documentation
        return 0
    def test_call_selection_screen(self):
        input_stream = FileStream("call_selection_screen.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_function(self):
        input_stream = FileStream("call_function.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_customer_function(self):
        input_stream = FileStream("call_customer_function.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_screen(self):
        input_stream = FileStream("call_screen.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_transaction(self):
        input_stream = FileStream("call_transaction.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_subscreen(self):
        input_stream = FileStream("call_subscreen.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_subscreen2(self):
        input_stream = FileStream("call_subscreen2.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_customer_subscreen(self):
        input_stream = FileStream("call_customer_subscreen.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_transformation(self):
        input_stream = FileStream("call_transformation.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_call_subscreen_colon(self):
        #No example found in the SAP Abap documentation
        return 0
    def test_call_use_literal_id(self):
        #No example found in the SAP Abap documentation
        return 0
if __name__ == '__main__':
    unittest.main()
# 18 Test Cases
# Passed 16
# Failed 2
# test_call_transaction, test_call_customer_function
