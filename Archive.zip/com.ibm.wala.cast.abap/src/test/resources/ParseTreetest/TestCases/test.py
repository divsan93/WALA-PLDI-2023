import sys
from antlr4 import *
from abapLexer import abapLexer
from abapParser import abapParser
from abapParserListener import abapParserListener
import unittest
class TestGrammar(unittest.TestCase):
    def test_select2(self):
        input_stream = FileStream("select2.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
    def test_select3(self):
        input_stream = FileStream("select3.txt")
        lexer = abapLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = abapParser(stream)
        tree = parser.program()
        self.assertNotIn("extraneous",tree.toStringTree(recog=parser))
        self.assertNotIn("no viable alternative",tree.toStringTree(recog=parser))
        self.assertNotIn("mismatched",tree.toStringTree(recog=parser))
        self.assertRaises

if __name__ == '__main__':
    unittest.main()
        #Passed
        #when_clause()
        #Passed
        #end_class()
        #Passed
        #class_def()
        #Passed
        #endtry_statement_line()
        #Passed
        #try_statement_line()
        #Passed
        #endselect()
        #Passed
        #select()
        #Failed
        #select2()
        #Failed
        #select3()
        #Passed
        #endwhile()
        #Passed
        #while_statement_line()
        #Passed
        #catch_statement_line()
        #Passed
        #endcatch()
        #Passed
        #endcase()
        #Passed
        #case_statement()
        #Passed
        #enddo()
        #Passed
        #do_statement_line()
        #Passed
        #endloop()
        #Passed
        #loop_statement_line()
        #Passed
        #endif()
        #Passed
        #if_statement_line()
        #Passed
        #elseT()
        #Passed
        #elseif()
        #Passed
        #endat()
        #Passed
        #at()
        #Passed
        #enddefine()
        #Passed
        #if_statement_line()
        #Passed
        #endchain()
        #Passed
        #chain()
        #Passed
        #endmethod()
        #Passed
        #method_definition_line()
        #Passed
        #endform()
        #Passed
        #form_definition_line()
        #Passed
        #endmodule()
        #Passed
        #module_form_line()
        #Passed
        #endfunction()
        #Passed
        #function_definition_line()

# 37 Test Cases
# Passed 35   
# Failed 2 test_select3, test_select2, 