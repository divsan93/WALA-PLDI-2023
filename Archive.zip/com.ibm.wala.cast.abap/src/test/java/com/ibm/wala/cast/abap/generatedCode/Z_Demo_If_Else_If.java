package com.ibm.wala.cast.abap.generatedCode;

public class Z_Demo_If_Else_If{

	public static void main(String[] args) 
		{
  int var_5;
  int var_10 = (10 - 20);
  if (((10 == 10) == false))
    {
      var_5 = (10 + 20);
    }
  else
    {
      if (((20 == 10) == false))
        {
          var_5 = (10 - 20);
        }
      else
        {
          var_5 = (10 / 20);
        }
    }
  System.out.println(var_5);
}

}
