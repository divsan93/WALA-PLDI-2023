package com.ibm.wala.cast.abap.CodeGen;

import com.ibm.wala.cast.abap.test.Code2AntlrParseTree;
import com.ibm.wala.util.WalaException;
import java.io.IOException;
import java.util.Scanner;

public class GenerateJavaCode {
    public static void main(String[] args) throws IOException, WalaException {
        System.out.println("---------Please provide the SAP ABAP File Name---------");
        //Scanner scanner = new Scanner(System.in);
        //String name = scanner.nextLine();
        //String path = System.getProperty("user.dir")+"/src/test/resources/Demo/";
        //new Code2AntlrParseTree().parseCode(path+name, name.split("\\.")[0]);
        String path = System.getProperty("user.dir")+"/com.ibm.wala.cast.abap/src/test/resources/DemoPrograms/";
        new Code2AntlrParseTree().parseCodeToPython(path+"ZTEST_SUM2.abap", "ZTEST_SUM2");

    }
}
