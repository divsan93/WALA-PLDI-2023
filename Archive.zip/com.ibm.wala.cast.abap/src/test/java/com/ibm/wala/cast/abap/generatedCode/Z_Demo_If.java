package com.ibm.wala.cast.abap.generatedCode;

public class Z_Demo_If{

	public static void main(String[] args) 
		{
  int var_5;
  var_5 = (10 - 20);
  if (! ((10 == 20) == false))
    {
      var_5 = (10 + var_5);
    }
  int var_13 = (var_5 + 20);
  System.out.println(var_5);
}

}
