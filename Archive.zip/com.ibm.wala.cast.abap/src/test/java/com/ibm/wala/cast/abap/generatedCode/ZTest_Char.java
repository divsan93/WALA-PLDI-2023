package com.ibm.wala.cast.abap.generatedCode;

public class ZTest_Char{

	public static void main(String[] args) 
		{
  System.out.println('A');
}

}
