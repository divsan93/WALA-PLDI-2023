def main(): 
  var_5: int
  var_10: int = (10 - 20)
  if ((10 == 10) == false): 
          var_5 = (10 + 20)
  else:
          var_5 = (10 / 20)
  System.out.println((var_5 + 10))



