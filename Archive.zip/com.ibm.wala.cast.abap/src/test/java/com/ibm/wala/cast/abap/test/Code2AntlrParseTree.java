package com.ibm.wala.cast.abap.test;

//import com.ibm.wala.cast.codegen.toSource.ToSource;
import com.ibm.wala.cast.codegen.python.CAstToPython;
import com.ibm.wala.analysis.typeInference.TypeInference;
import com.ibm.wala.cast.abap.callgraph.ABAPCallGraphUtil;
import com.ibm.wala.cast.abap.loader.FileEntry;
import com.ibm.wala.cast.abap.translator.CAstABAPTranslator;
import com.ibm.wala.cast.ir.ssa.AstIRFactory;
import com.ibm.wala.classLoader.IClass;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.ipa.callgraph.impl.Everywhere;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.IRFactory;
import com.ibm.wala.ssa.SSAOptions;
import com.ibm.wala.util.WalaException;
import java.io.IOException;
import java.io.PrintWriter;


public class Code2AntlrParseTree{

    public String codeGenJava(String filename, String codeBlock)
    {
        String retCode="";
        retCode = retCode+"package com.ibm.wala.cast.abap.generatedCode;\n\n";
        retCode = retCode+"public class " +filename +"{\n\n";
        retCode = retCode+"\tpublic static void main(String[] args) \n";
        retCode = retCode+"\t\t" + codeBlock +"\n";
        retCode = retCode + "}";
        return retCode;
    }

    public String codeGenPython(String filename, String codeBlock)
    {
        String retCode="";
        retCode = retCode+"def main(): \n";
        retCode = retCode + codeBlock +"\n";
        return retCode;
    }
//    public void parseCode(String filename, String reportName) throws IOException, WalaException {
//
//        FileEntry modules = new FileEntry(filename);
//        //ABAPCallGraphUtil.setTranslatorFactory(new ABAPTranslatorFactory());
//        ABAPCallGraphUtil.setTranslatorFactory(new CAstABAPTranslator(modules));
//        IClassHierarchy cha = ABAPCallGraphUtil.makeHierarchyForScripts(filename);
//        for(IClass c: cha)
//        {
//            for(IMethod m: c.getDeclaredMethods())
//            {
//                System.out.println(m);
//                IRFactory<IMethod> f = AstIRFactory.makeDefaultFactory();
//                IR ir=f.makeIR(m, Everywhere.EVERYWHERE, SSAOptions.defaultOptions());
//                TypeInference t1=TypeInference.make(ir, true);
//                System.out.println(t1);
//                System.out.println(ir);
//                // The below line starts the codegen.
//                ToSource codeGen = new ToSource();
//                codeGen.toJava(ir, cha, TypeInference.make(ir, true));
//                String code = codeGen.generatedCode;
//                System.out.println(code);
//                codeGen.generatedCode= "";
//                String updatedCode = codeGenJava(reportName, code);
//                PrintWriter writer = new PrintWriter(System.getProperty("user.dir")+"/src/test/java/com/ibm/wala/cast/abap/generatedCode/"+reportName+".java", "UTF-8");
//                writer.println(updatedCode);
//                writer.close();
//                //System.getProperty("user.dir")+"/src/test/resources/DemoPrograms/"
//
//
//            }
//        }
//        com.ibm.wala.cast.util.Util.checkForFrontEndErrors(cha);
////        Map<String, ModuleEntry> m = new LinkedHashMap<>();
////        m.put(filename, modules);
////        ABAPSourceModuleTranslator.sourceLoader = (ABAPLoader) cha.getLoaders()[0];
////        ABAPSourceModuleTranslator.ABAPAstToIR abap2ir = new ABAPSourceModuleTranslator.ABAPAstToIR(m);
////        abap2ir.acceptAST(filename, tree);
////        System.out.println("Done");
//
//
//        //CAstNode ret =  new Antlr2CAstTranslator().parseAntlr2CAst(tree);
////        CAstEntity ret = new Antlr2CAstTranslator<Position>().translateToCAst(filename);
////        SourceFileModule module = new SourceFileModule(myObj, filename, null);
////
////        System.out.println("CAst Tree");
////        System.out.println(ret);
//        /*
//        This section is for debugging the empty node deletion.
//         */
////        System.out.println("Duplicate CAst Tree");
////        CAst2CAstTranslator removeEmpty = new CAst2CAstTranslator();
////        CAstNode duplicate = removeEmpty.copyCAstTree(ret);
////        System.out.println(duplicate);
////        System.out.println("Nodes that are deleted");
////        System.out.println(removeEmpty.removedNodetype);
//    }

    public void parseCodeToPython(String filename, String reportName) throws IOException, WalaException {

        FileEntry modules = new FileEntry(filename);
        //ABAPCallGraphUtil.setTranslatorFactory(new ABAPTranslatorFactory());
        ABAPCallGraphUtil.setTranslatorFactory(new CAstABAPTranslator(modules));
        IClassHierarchy cha = ABAPCallGraphUtil.makeHierarchyForScripts(filename);
        for(IClass c: cha)
        {
            for(IMethod m: c.getDeclaredMethods())
            {
                System.out.println(m);
                IRFactory<IMethod> f = AstIRFactory.makeDefaultFactory();
                IR ir=f.makeIR(m, Everywhere.EVERYWHERE, SSAOptions.defaultOptions());
                TypeInference t1=TypeInference.make(ir, true);
                System.out.println(t1);
                System.out.println(ir);
                // The below line starts the codegen.
                CAstToPython codeGen = new CAstToPython();
                codeGen.translate(ir, cha, TypeInference.make(ir, true));
                String code = CAstToPython.generatedCode;
                System.out.println(code);
                CAstToPython.generatedCode = "";
                String updatedCode = codeGenPython(reportName, code);
                System.out.println(updatedCode);
                PrintWriter writer = new PrintWriter(System.getProperty("user.dir")+"/src/test/java/com/ibm/wala/cast/abap/generatedCode/"+reportName+".py", "UTF-8");
                writer.println(updatedCode);
                writer.close();
            }
        }
        com.ibm.wala.cast.util.Util.checkForFrontEndErrors(cha);
    }
}
