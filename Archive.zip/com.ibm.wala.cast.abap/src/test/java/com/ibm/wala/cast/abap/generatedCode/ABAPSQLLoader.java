package com.ibm.wala.cast.abap.generatedCode;

public class ABAPSQLLoader {
}
