package com.ibm.wala.cast.abap.test;

import com.ibm.wala.ipa.cha.ClassHierarchyException;
import com.ibm.wala.util.WalaException;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.fail;

@RunWith(Parameterized.class)
public class ParseTreeTest {
    private String filename;
    static String path = System.getProperty("user.dir")+"/src/test/resources/DemoPrograms/";
    //static String path = System.getProperty("user.dir")+"/src/test/resources/ParseTreetest/TestCases/";
    public ParseTreeTest(String file) {
        this.filename = file;
    }

    @Parameterized.Parameters
    public static Collection paths() {
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();
        List<String>strFilename = new ArrayList<>();
        for (int i = 0; i < listOfFiles.length; i++) {
            if(!(listOfFiles[i].getName().contains("_line")))
                strFilename.add(listOfFiles[i].getName());
        }
        return strFilename;
    }
    @Test
    public void test_ParseTree() {
        try {
            new Code2AntlrParseTree().parseCodeToPython(path+filename, filename);
        } catch (RuntimeException | IOException | WalaException re) {
            String msg = filename;
            fail(msg);
        }
    }


}

