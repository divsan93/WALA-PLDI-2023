package com.ibm.wala.cast.abap.test;

import com.ibm.wala.ipa.cha.ClassHierarchyException;
import com.ibm.wala.util.WalaException;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;

public class TestIndividual {
    @Test
    public void test_parseTreeIndividual() throws IOException, WalaException {
        String path = System.getProperty("user.dir")+"/src/test/resources/DemoPrograms/";
//        new Code2AntlrParseTree().parseCodeToPython(path+"ZTEST_SUM2.abap", "ZTEST_SUM2"); //Done
//        new Code2AntlrParseTree().parseCode(path+"ZTEST_SUM.abap", "ZTEST_SUM");  //Done
//        new Code2AntlrParseTree().parseCode(path+"ZTEST_SUM.abap", "ZTEST_SUM");  //Done
//        new Code2AntlrParseTree().parseCode(path+"ZTest_Char.abap", "ZTest_Char"); //Done
//        new Code2AntlrParseTree().parseCode(path+"Z_Demo_If.abap", "Z_Demo_If"); //Done
        new Code2AntlrParseTree().parseCodeToPython(path+"Z_Demo_If_Else.abap", "Z_Demo_If_Else"); //Done
//        new Code2AntlrParseTree().parseCode(path+"Z_Demo_If_Else_If.abap", "Z_Demo_If_Else_If");
//        new Code2AntlrParseTree().parseCode(path+"Z_Demo_While_Loop.abap", "Z_Demo_While_Loop"); //Done
//        new Code2AntlrParseTree().parseCode(path+"Z_Demo_Select_Where_Expression.abap", "Z_Demo_Select_Where_Expression");
        //new Code2AntlrParseTree().parseCode(path+"Z_Demo_Simple_Structure.abap", "Z_Demo_Simple_Structure");
        //new Code2AntlrParseTree().parseCode(path+"Z_Demo_Numerical_Function.abap", "Z_Demo_Numerical_Function");
        org.junit.Assert.assertTrue( new ArrayList().isEmpty() );
    }
}
