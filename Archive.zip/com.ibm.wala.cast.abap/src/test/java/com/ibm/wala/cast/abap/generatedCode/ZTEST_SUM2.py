def main(): 
		  var_11: int = (10 + 20):
  System.out.println((10 + (20 + 30):):)



