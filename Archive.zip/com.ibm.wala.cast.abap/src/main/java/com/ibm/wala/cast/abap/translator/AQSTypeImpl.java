package com.ibm.wala.cast.abap.translator;

import java.util.ArrayList;
import java.util.List;

public class AQSTypeImpl implements ABAPQuerySpecificType {

    protected List<Integer> kind;

    public AQSTypeImpl(List<Integer> kind) {
        this.kind = kind;
    }
    public AQSTypeImpl() {
        this.kind = new ArrayList<Integer>();
    }

    public AQSTypeImpl(int kind) {
        if(this.kind!=null)
            this.kind.add(kind);
    }

    @Override
    public List<Integer> getKind() {
        return kind;
    }
    @Override
    public int getKind(int i) {
        return i;
    }

    @Override
    public Object getValue() {
        return null;
    }
    public void setKind(int kind) {
        if(!this.kind.contains(kind)) this.kind.add(kind);
    }

    @Override
    public String toString() {
        String ret = "";
        for (int type : this.kind) {
            ret+= ABAPQuerySpecificType.getKindAsString(type)+" ,";
        }
        if(ret!="")
        {
            ret = ret.replaceAll(" ,$", "");
        }
        return ret;
    }

    @Override
    public int hashCode() {
        int code = (this.kind.size() + 13);
        for (int i = 0; i < this.kind.size() && i < 15; i++) {
            if (this.kind.get(i) != null) {
                code *= this.kind.get(i);
            }
        }
        return code;
    }
}
