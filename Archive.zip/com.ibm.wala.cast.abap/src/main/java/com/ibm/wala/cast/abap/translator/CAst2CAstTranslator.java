//package com.ibm.wala.cast.abap.translator;
//
//import com.ibm.wala.cast.tree.CAstNode;
//import com.ibm.wala.cast.tree.impl.CAstOperator;
//
//import java.util.ArrayList;
//import java.util.List;
//
//// Due to the presence of various EMPTY nodes in the CAst for ABAP, we use a post-processing technique to remove that.
//public class CAst2CAstTranslator extends Antlr2CAstTranslator {
//    public static List<Integer> removedNodetype= new ArrayList<>();
//
//    public CAst2CAstTranslator() {
//        //super();
//    }
//
//    public CAstNode copyCAstTree(CAstNode tree)
//    {
//        Boolean flag = false;
//        List<CAstNode> children= new ArrayList<>();
//        if (tree == null)
//        {
//            return null;
//        }
//        if(tree.getKind()==CAstNode.CONSTANT)
//            return tree;
//        if(tree instanceof CAstOperator)
//            return tree;
//        for(CAstNode child: tree.getChildren())
//        {
//            if(child.getKind()==CAstNode.EMPTY)
//            {
//                if(child.getChildCount()!=0)
//                {
//                    for(CAstNode grandChild: child.getChildren())
//                    {
//                        if(grandChild.getChildCount()!=0)
//                        {
//                            if(grandChild.getKind()!=CAstNode.EMPTY)
//                                children.add(copyCAstTree(grandChild));
//                            else
//                            {
//                                for(CAstNode greatgrandChild: grandChild.getChildren())
//                                {
//                                    children.add(copyCAstTree(greatgrandChild));
//                                }
//                                if(flag!=true)
//                                {
//                                    flag=true;
//                                    removedNodetype.add(grandChild.getKind());
//                                }
//                            }
//
//                        }
//                        else if(grandChild.getKind()==CAstNode.CONSTANT)
//                        {
//                            children.add(new Antlr2CAstTranslator(fSourceLoader).fFactory.makeConstant(grandChild.getValue()));
//                        }
//                        else
//                        {
//                            if(flag!=true)
//                            {
//                                flag=true;
//                                removedNodetype.add(child.getKind());
//                            }
//                        }
//
//                    }
//                }
//                else
//                {
//                    if(flag!=true)
//                    {
//                        flag=true;
//                        removedNodetype.add(tree.getKind());
//                    }
//                }
//            }
//            else
//                children.add(copyCAstTree(child));
//        }
//        return new Antlr2CAstTranslator(fSourceLoader).fFactory.makeNode(tree.getKind(), children);
//    }
//}
