/*
 * Copyright (c) 2022 IBM Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 */
package com.ibm.wala.cast.abap.tree;

import com.ibm.wala.cast.abap.translator.ABAPQuerySpecificType;
import com.ibm.wala.cast.abap.types.AbapPrimitiveTypeMap;
import com.ibm.wala.cast.tree.CAstType;

import java.util.List;
// This class captures all the neccessary information for SQL queries.
public class CAstQueryImpl {
    private final int _queryType;
    private final boolean _isUnique;
    private final boolean _isDistinct;
    private final String _fromTableName;

    public CAstType type() {
        return _type;
    }

    private final List<String> _fields;

    private final CAstType _type;

    public int queryType() {
        return _queryType;
    }

    public boolean isUnique() {
        return _isUnique;
    }

    public boolean isDistinct() {
        return _isDistinct;
    }

    public String fromTableName() {
        return _fromTableName;
    }

    public List<String> fields() {
        return _fields;
    }

    public CAstQueryImpl(int queryType, boolean isUnique, boolean isDistinct, String fromTableName, List<String> fields, CAstType type) {
        _queryType = queryType;
        _isUnique = isUnique;
        _isDistinct = isDistinct;
        _fromTableName = fromTableName;
        _fields = fields;
        _type = type;
    }
    public String toString() {
        return ABAPQuerySpecificType.getKindAsString(_queryType);
    }
}
