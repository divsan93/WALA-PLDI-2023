package com.ibm.wala.cast.abap.client;

import com.ibm.wala.cast.abap.loader.ABAPLoader;
import com.ibm.wala.cast.abap.loader.ABAPLoaderFactory;
import com.ibm.wala.cast.abap.translator.ABAPTranslatorFactory;
import com.ibm.wala.cast.abap.translator.CAstABAPTranslator;
import com.ibm.wala.cast.ipa.callgraph.CAstAnalysisScope;
import com.ibm.wala.cast.ir.ssa.AstIRFactory;
import com.ibm.wala.classLoader.Module;
import com.ibm.wala.classLoader.SourceModule;
import com.ibm.wala.client.AbstractAnalysisEngine;
import com.ibm.wala.ipa.callgraph.*;
import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;
import com.ibm.wala.ipa.callgraph.propagation.PointerAnalysis;
import com.ibm.wala.ipa.cha.ClassHierarchyException;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ipa.cha.SeqClassHierarchyFactory;
import com.ibm.wala.util.CancelException;
import com.ibm.wala.util.MonitorUtil;
import com.ibm.wala.util.collections.HashSetFactory;
import com.ibm.wala.util.debug.Assertions;

import java.util.Collections;
import java.util.Set;
import java.util.jar.JarFile;

public class ABAPSOurceAnalysisEngine extends AbstractAnalysisEngine<InstanceKey, CallGraphBuilder<InstanceKey>, Void> {

    protected ABAPLoaderFactory loaderFactory;

    protected CAstABAPTranslator translatorFactory;

    @Override
    protected CallGraphBuilder<InstanceKey> getCallGraphBuilder(IClassHierarchy cha, AnalysisOptions options, IAnalysisCacheView cache2) {
        return null;
    }

    @Override
    public void buildAnalysisScope() {
        loaderFactory = new ABAPLoaderFactory(translatorFactory);

        SourceModule[] files = moduleFiles.toArray(new SourceModule[0]);

        scope = new CAstAnalysisScope(files, loaderFactory, Collections.singleton(ABAPLoader.ABAP));
    }

    @Override
    public IClassHierarchy buildClassHierarchy() {
        try {
            return setClassHierarchy(
                    SeqClassHierarchyFactory.make(getScope(), loaderFactory, ABAPLoader.ABAP));
        } catch (ClassHierarchyException e) {
            Assertions.UNREACHABLE(e.toString());
            return null;
        }
    }

    public void setTranslatorFactory(CAstABAPTranslator factory) {
        this.translatorFactory = factory;
    }

//    @Override
//    public void setJ2SELibraries(JarFile[] libs) {
//        Assertions.UNREACHABLE("Illegal to call setJ2SELibraries");
//    }
//
//    @Override
//    public void setJ2SELibraries(Module[] libs) {
//        Assertions.UNREACHABLE("Illegal to call setJ2SELibraries");
//    }

//    @Override
//    protected Iterable<Entrypoint> makeDefaultEntrypoints(IClassHierarchy cha) {
//        return new JavaScriptEntryPoints(cha, cha.getLoader(JavaScriptTypes.jsLoader));
//    }

    @Override
    public IAnalysisCacheView makeDefaultCache() {
        return new AnalysisCacheImpl(AstIRFactory.makeDefaultFactory());
    }

//    @Override
//    public ABAPAnalysisOptions getDefaultOptions(Iterable<Entrypoint> roots) {
//        final JSAnalysisOptions options = new JSAnalysisOptions(scope, roots);
//
//        options.setUseConstantSpecificKeys(true);
//
//        options.setUseStacksForLexicalScoping(true);
//
//        return options;
//    }

}
