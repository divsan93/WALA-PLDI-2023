package com.ibm.wala.cast.abap.translator;

import com.ibm.wala.cast.ir.translator.TranslatorToCAst;
import com.ibm.wala.cast.tree.CAst;
import com.ibm.wala.classLoader.ModuleEntry;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.IOException;

public class ABAPTranslatorFactory  {
    public TranslatorToCAst make(CAst ast, ModuleEntry M) throws IOException {
        return new CAstABAPTranslator(M );
    }
}
