package com.ibm.wala.cast.abap.translator;
import com.ibm.wala.cast.abap.loader.ABAPLoader;
import com.ibm.wala.cast.tree.CAst;
import com.ibm.wala.cast.tree.CAstEntity;
import com.ibm.wala.cast.tree.CAstSourcePositionMap;
import com.ibm.wala.cast.tree.impl.CAstImpl;
import com.ibm.wala.classLoader.ModuleEntry;
import com.ibm.wala.classLoader.SourceFileModule;
import com.ibm.wala.util.collections.HashMapFactory;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.IOException;
import java.util.*;

public class ABAPSourceModuleTranslator implements SourceModuleTranslator {
    @Override
    public void loadAllSources(Set<ModuleEntry> modules) {
        List<String> sources = new LinkedList<>();
        Map<String, ModuleEntry> sourceMap = HashMapFactory.make();
        for (ModuleEntry m : modules) {
            if (m.isSourceFile()) {
                SourceFileModule s = (SourceFileModule) m;
                sourceMap.put(s.getAbsolutePath(), s);
                sources.add(s.getAbsolutePath());
            }
        }
    }

     public static class ABAPToCAstTranslator extends Antlr2CAstTranslator<CAstSourcePositionMap.Position> {
        public ABAPToCAstTranslator(ModuleEntry m,
                ABAPLoader sourceLoader,
                ParseTree astRoot,
                String fullPath, boolean dump) throws IOException {
            super(new CAstImpl(),
            m, fullPath);
            //super(sourceLoader, astRoot, fullPath, dump);
        }
    }

    public static final class ABAPAstToIR{
        private final Map<String, ModuleEntry> sourceMap;

        public ABAPAstToIR(Map<String, ModuleEntry> sourceMap) {
            this.sourceMap = sourceMap;
        }

        public void acceptAST(String filename, ParseTree ast) throws IOException {
            Antlr2CAstTranslator<CAstSourcePositionMap.Position> abap2cast = makeCAstTranslator(sourceMap.get(filename),ast, filename);
            CAstEntity treeCAst = abap2cast.translateToCAst(filename);
            final ABAPAstTranslator abap2ir = new ABAPAstTranslator(sourceLoader);
//            Set<Pair<CAstEntity, ModuleEntry>> topLevelEntities = new HashSet<>();
//            topLevelEntities.add(new Pair<CAstEntity, ModuleEntry>(treeCAst, sourceMap));
            abap2ir.translate(treeCAst, sourceMap.get(filename));

        }
    }
    public static ABAPLoader sourceLoader;

    protected static Antlr2CAstTranslator<CAstSourcePositionMap.Position> makeCAstTranslator(
            ModuleEntry m, ParseTree cu, String fullPath) throws IOException {
        return new ABAPToCAstTranslator(m, sourceLoader, cu, fullPath, false);
    }
}
