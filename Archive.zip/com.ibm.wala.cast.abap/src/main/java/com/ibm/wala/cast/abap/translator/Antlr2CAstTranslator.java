package com.ibm.wala.cast.abap.translator;
import com.ibm.wala.cast.abap.Antlr.abapLexer;
import com.ibm.wala.cast.abap.Antlr.abapParser;
import com.ibm.wala.cast.abap.Antlr.abapParser.*;
import com.ibm.wala.cast.abap.loader.ABAPLoader;
import com.ibm.wala.cast.abap.tree.CAstQueryImpl;
import com.ibm.wala.cast.abap.types.AbapPrimitiveTypeMap;
import com.ibm.wala.cast.ir.translator.TranslatorToCAst;
import com.ibm.wala.cast.tree.*;
import com.ibm.wala.cast.tree.CAstSourcePositionMap.Position;
import com.ibm.wala.cast.tree.impl.*;
import com.ibm.wala.cast.tree.rewrite.CAstRewriter;
import com.ibm.wala.cast.tree.rewrite.CAstRewriterFactory;
import com.ibm.wala.cast.util.CAstPrinter;
import com.ibm.wala.classLoader.ModuleEntry;
import com.ibm.wala.util.collections.EmptyIterator;
import com.ibm.wala.util.collections.HashMapFactory;
import com.ibm.wala.util.collections.Pair;
import com.ibm.wala.util.debug.Assertions;
import org.antlr.v4.gui.TreeViewer;
import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.antlr.v4.runtime.tree.TerminalNodeImpl;
import com.ibm.wala.cast.abap.types.AbapPrimitiveTypeMap.*;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import javax.swing.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static sun.misc.Unsafe.getUnsafe;

/*
In this class, we define the mechanism to translate the parse tree
generated using the Antlr4 into a tree formed using CAstEntity. CAstEntity is
a WALA representation, where based on the type of instructions the entity can be different.
For instance, one type of entity can be ClassEntity, which will store all the class related information
alongwith the CAstNode of the members of the class. CAstNode is the WALA presentation of the tree.
 */
public class Antlr2CAstTranslator<T extends Position> implements TranslatorToCAst {
    /* In this part, we define various fields that we will using in the later part.*/
    protected boolean dump = false;
    /* Antlr Parse tree */
    protected ParseTree tree;
    /* CAstImpl class has various type of CAstNode creation implementation that we will using based on the scenario. */
    protected final CAst fFactory;
    //protected final ABAPLoader fSourceLoader;
    protected String fullPath;

    private final ModuleEntry sourceModule;



public Antlr2CAstTranslator(
        CAst Ast,
        ModuleEntry m,
        String scriptName) throws IOException {
    this.fFactory = Ast;
    this.fullPath = scriptName;
    this.sourceModule = m;
    if(!fullPath.contains("/"))
        fullPath=System.getProperty("user.dir")+"/src/test/resources/DemoPrograms/"+fullPath;
    ANTLRFileStream input = new ANTLRFileStream(fullPath);
    abapLexer lexer = new abapLexer(input);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    abapParser parser = new abapParser(tokens);
    this.tree  = parser.program();
    System.out.println(tree.toStringTree(parser));
//    TreeViewer viewr = new TreeViewer(Arrays.asList(
//            parser.getRuleNames()),tree);
//    viewr.open();
//    System.out.println("Check");
}
//    public Antlr2CAstTranslator(ABAPLoader loader, ParseTree tree, String fullPath,boolean dump) {
//        fSourceLoader = loader;
//        this.dump = dump;
//        this.tree = tree;
//        this.fullPath = fullPath;
//    }


//    public Antlr2CAstTranslator(ABAPLoader fSourceLoader) {
//        this.fSourceLoader = fSourceLoader;
//    }


    public CAstEntity translateToCAst(String filename) {
        /* In ABAP, the root node is a program node.*/
        CAstEntity abapEntities;
        abapEntities =  visitProgram(tree, new RootContext());

        if (dump) {
            CAstPrinter.printTo(abapEntities, new PrintWriter(System.err));
            }
        return new FileEntity(filename, abapEntities);
    }

    @Override
    public <C extends CAstRewriter.RewriteContext<K>, K extends CAstRewriter.CopyKey<K>> void addRewriter(CAstRewriterFactory<C, K> factory, boolean prepend) {
        assert false;
    }

    @Override
    public CAstEntity translateToCAst() throws Error, IOException {
        CAstEntity abapEntities;

        abapEntities =  visitProgram(tree, new RootContext());

        if (dump) {
            CAstPrinter.printTo(abapEntities, new PrintWriter(System.err));
        }

        return new FileEntity(fullPath.substring(fullPath.lastIndexOf('-') + 1), abapEntities);
    }



    /* DO NOT ENTER: Construction Ahead */

    protected final class FieldEntity implements CAstEntity {
        private final AbapPrimitiveType type;

        private final String name;

        private final T position;

        private final T namePos;

        private final Set<CAstAnnotation> annotations;

        private FieldEntity(
                String name,
                AbapPrimitiveType type,
                T position,
                Set<CAstAnnotation> annotations,
                T namePos) {
            super();
            this.type = type;
            this.name = name;
            this.namePos = namePos;
            this.position = position;
            this.annotations = annotations;
        }

        @Override
        public Collection<CAstAnnotation> getAnnotations() {
            return annotations;
        }

        @Override
        public int getKind() {
            return CAstEntity.FIELD_ENTITY;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String getSignature() {
            return null;
        }

        @Override
        public String[] getArgumentNames() {
            return new String[0];
        }

        @Override
        public CAstNode[] getArgumentDefaults() {
            return new CAstNode[0];
        }

        @Override
        public int getArgumentCount() {
            return 0;
        }

        @Override
        public Iterator<CAstEntity> getScopedEntities(CAstNode construct) {
            return EmptyIterator.instance();
        }

        @Override
        public Map<CAstNode, Collection<CAstEntity>> getAllScopedEntities() {
            return Collections.emptyMap();
        }

        @Override
        public CAstNode getAST() {
            // No AST for a field decl; initializers folded into
            // constructor processing...
            return null;
        }

        @Override
        public CAstControlFlowMap getControlFlow() {
            // No AST for a field decl; initializers folded into
            // constructor processing...
            return null;
        }

        @Override
        public CAstSourcePositionMap getSourceMap() {
            // No AST for a field decl; initializers folded into
            // constructor processing...
            return null;
        }

        @Override
        public CAstSourcePositionMap.Position getPosition() {
            return position;
        }

        @Override
        public CAstNodeTypeMap getNodeTypeMap() {
            // No AST for a field decl; initializers folded into
            // constructor processing...
            return null;
        }

        @Override
        public Collection<CAstQualifier> getQualifiers() {
            return null;
        }
        //TODO:Implement this part.
        @Override
        public CAstType getType() {

            //return fTypeDict.getCAstTypeFor(type);
            return null;
        }

        @Override
        public Position getPosition(int arg) {
            return namePos;
        }

        @Override
        public Position getNamePosition() {
            // TODO Auto-generated method stub
            return null;
        }
    }
    protected static final class FileEntity implements CAstEntity {
        private final String fName;

        private final CAstEntity fTopLevelDecls;

        public FileEntity(
                String fName, CAstEntity topLevelDecls) {
            this.fName = fName;
            fTopLevelDecls = topLevelDecls;
        }

        @Override
        public Collection<CAstAnnotation> getAnnotations() {
            return null;
        }

        @Override
        public int getKind() {
            return FILE_ENTITY;
        }

        @Override
        public String getName() {
            return fName;
        }

        @Override
        public String getSignature() {
            Assertions.UNREACHABLE();
            return null;
        }

        @Override
        public String[] getArgumentNames() {
            return new String[0];
        }

        @Override
        public CAstNode[] getArgumentDefaults() {
            return new CAstNode[0];
        }

        @Override
        public int getArgumentCount() {
            return 0;
        }

        @Override
        public Map<CAstNode, Collection<CAstEntity>> getAllScopedEntities() {
            return Collections.singletonMap(null, Collections.singletonList( fTopLevelDecls ) );
        }

        @Override
        public Iterator<CAstEntity> getScopedEntities(CAstNode construct) {
            Assertions.UNREACHABLE(
                    "CompilationUnitEntity asked for AST-related entities, but it has no AST.");
            return null;
        }

        @Override
        public CAstNode getAST() {
            return null;
        }

        @Override
        public CAstControlFlowMap getControlFlow() {
            Assertions.UNREACHABLE("CompilationUnitEntity.getControlFlow()");
            return null;
        }

        @Override
        public CAstSourcePositionMap getSourceMap() {
            Assertions.UNREACHABLE("CompilationUnitEntity.getSourceMap()");
            return null;
        }

        @Override
        public CAstSourcePositionMap.Position getPosition() {
            return null;
        }

        @Override
        public CAstNodeTypeMap getNodeTypeMap() {
            Assertions.UNREACHABLE("CompilationUnitEntity.getNodeTypeMap()");
            return null;
        }

        @Override
        public Collection<CAstQualifier> getQualifiers() {
            return Collections.emptyList();
        }

        @Override
        public CAstType getType() {
            Assertions.UNREACHABLE("CompilationUnitEntity.getType()");
            return null;
        }

        @Override
        public Position getPosition(int arg) {
            return null;
        }

        @Override
        public Position getNamePosition() {
            return null;
        }
    }

    protected final class QueryEntity implements CAstEntity
    {
        private final ABAPQuerySpecificType fqueryType;

        private final Map<CAstNode, Collection<CAstEntity>> fsubs;

        private final CAstNode fast;

        private final Position fnamePosition;

        private QueryEntity(ABAPQuerySpecificType fqueryType, Map<CAstNode, Collection<CAstEntity>> fsubs, CAstNode fast, Position fnamePosition) {
            this.fqueryType = fqueryType;
            this.fsubs = fsubs;
            this.fast = fast;
            this.fnamePosition = fnamePosition;
        }

        @Override
        public int getKind() {
            return 0;
        }

        @Override
        public String getName() {
            return null;
        }

        @Override
        public String getSignature() {
            return null;
        }

        @Override
        public String[] getArgumentNames() {
            return new String[0];
        }

        @Override
        public CAstNode[] getArgumentDefaults() {
            return new CAstNode[0];
        }

        @Override
        public int getArgumentCount() {
            return 0;
        }

        public ABAPQuerySpecificType getQueryType()
        {
            return fqueryType;
        }
        @Override
        public Map<CAstNode, Collection<CAstEntity>> getAllScopedEntities() {
            return null;
        }

        @Override
        public Iterator<CAstEntity> getScopedEntities(CAstNode construct) {
            return null;
        }

        @Override
        public CAstNode getAST() {
            return fast;
        }

        @Override
        public CAstControlFlowMap getControlFlow() {
            return null;
        }

        @Override
        public CAstSourcePositionMap getSourceMap() {
            return null;
        }

        @Override
        public Position getPosition() {
            return fnamePosition;
        }

        @Override
        public Position getNamePosition() {
            return null;
        }

        @Override
        public Position getPosition(int arg) {
            return null;
        }

        @Override
        public CAstNodeTypeMap getNodeTypeMap() {
            return null;
        }

        @Override
        public Collection<CAstQualifier> getQualifiers() {
            return null;
        }

        @Override
        public CAstType getType() {
            return null;
        }

        @Override
        public Collection<CAstAnnotation> getAnnotations() {
            return null;
        }
    }

    //TODO: Seems like done.
    protected class ReportEntity implements CAstEntity {

        private final String name;

        private final int kind;

        private final Map<CAstNode, Collection<CAstEntity>> subs;

        private final CAstNode ast;

        private final CAstControlFlowMap map;

        private final CAstSourcePositionMap pos;

        private final Position entityPosition;

        private ReportEntity(ParseTree n,
                             Map<CAstNode, Collection<CAstEntity>> subs,
                             CAstNode ast,
                             CAstControlFlowMap map,
                             CAstSourcePositionMap pos,
                             String name) {
            this.name = name;
            this.subs = subs;
            this.ast = ast;
            this.map = map;
            this.pos = pos;
            kind = CAstEntity.SCRIPT_ENTITY;
            this.entityPosition = pos.getPosition(ast);
        }

        @Override
        public int getKind() {
            return kind;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String getSignature() {
            return null;
        }

        @Override
        public String[] getArgumentNames() {
            return new String[0];
        }

        @Override
        public CAstNode[] getArgumentDefaults() {
            return new CAstNode[0];
        }

        @Override
        public int getArgumentCount() {
            return 0;
        }

        @Override
        public Map<CAstNode, Collection<CAstEntity>> getAllScopedEntities() {
            return Collections.unmodifiableMap(subs);
        }

        @Override
        public Iterator<CAstEntity> getScopedEntities(CAstNode construct) {
            if (subs.containsKey(construct)) return subs.get(construct).iterator();
            else return EmptyIterator.instance();
        }

        @Override
        public CAstNode getAST() {
            return ast;
        }

        @Override
        public CAstControlFlowMap getControlFlow() {
            return map;
        }

        @Override
        public CAstSourcePositionMap getSourceMap() {
            return pos;
        }

        @Override
        public Position getPosition() {
            return entityPosition;
        }

        @Override
        public Position getNamePosition() {
            return null;
        }

        @Override
        public Position getPosition(int arg) {
            return null;
        }

        @Override
        public CAstNodeTypeMap getNodeTypeMap() {
            return null;
        }

        @Override
        public Collection<CAstQualifier> getQualifiers() {
            Assertions.UNREACHABLE("RangeetsUnnamedCAstEntity$2.getQualifiers()");
            return null;
        }

        @Override
        public CAstType getType() {
            return ABAPAstTranslator.Any;
        }

        @Override
        public Collection<CAstAnnotation> getAnnotations() {
            return null;
        }
    }
    protected final class GlobalEntity implements CAstEntity
    {

        private final String fName;

        private final Map<CAstNode, CAstEntity> fEntities;

        private final CAstNode fNode;

        private final CAstType fABAPType; // TAGALONG

        private final T fSourcePosition;


        private GlobalEntity(String fName, Map<CAstNode, CAstEntity> fEntities, CAstType fABAPType, T fSourcePosition, CAstNode fNode) {
            this.fName = fName;
            this.fEntities = fEntities;
            this.fABAPType = fABAPType;
            this.fSourcePosition = fSourcePosition;
            this.fNode = fNode;
        }

        @Override
        public int getKind() {
            return 0;
        }

        @Override
        public String getName() {
            return null;
        }

        @Override
        public String getSignature() {
            return null;
        }

        @Override
        public String[] getArgumentNames() {
            return new String[0];
        }

        @Override
        public CAstNode[] getArgumentDefaults() {
            return new CAstNode[0];
        }

        @Override
        public int getArgumentCount() {
            return 0;
        }

        @Override
        public Map<CAstNode, Collection<CAstEntity>> getAllScopedEntities() {
            return null;
        }

        @Override
        public Iterator<CAstEntity> getScopedEntities(CAstNode construct) {
            return null;
        }

        @Override
        public CAstNode getAST() {
            return null;
        }

        @Override
        public CAstControlFlowMap getControlFlow() {
            return null;
        }

        @Override
        public CAstSourcePositionMap getSourceMap() {
            return null;
        }

        @Override
        public Position getPosition() {
            return null;
        }

        @Override
        public Position getNamePosition() {
            return null;
        }

        @Override
        public Position getPosition(int arg) {
            return null;
        }

        @Override
        public CAstNodeTypeMap getNodeTypeMap() {
            return null;
        }

        @Override
        public Collection<CAstQualifier> getQualifiers() {
            return null;
        }

        @Override
        public CAstType getType() {
            return null;
        }

        @Override
        public Collection<CAstAnnotation> getAnnotations() {
            return null;
        }
    }


    protected final class ClassEntity implements CAstEntity
    {
        private final String fName;

        private final Collection<CAstQualifier> fQuals;

        private final Collection<CAstEntity> fEntities;

        private final CAstType fABAPType; // TAGALONG

        private final T fSourcePosition;

        private final T fNamePos;

        public ClassEntity(
                CAstType ABAPType,
                String name,
                Collection<CAstQualifier> quals,
                Collection<CAstEntity> entities,
                T pos,
                T namePos) {
            fNamePos = namePos;
            fName = name;
            fQuals = quals;
            fEntities = entities;
            fABAPType = ABAPType;
            fSourcePosition = pos;
        }

        @Override
        public int getKind() {
            return TYPE_ENTITY;
        }

        @Override
        public String getName() {
            return null;
        }

        @Override
        public String getSignature() {
            return null;
        }

        @Override
        public String[] getArgumentNames() {
            return new String[0];
        }

        @Override
        public CAstNode[] getArgumentDefaults() {
            return new CAstNode[0];
        }

        @Override
        public int getArgumentCount() {
            return 0;
        }

        @Override
        public Map<CAstNode, Collection<CAstEntity>> getAllScopedEntities() {
            return null;
        }

        @Override
        public Iterator<CAstEntity> getScopedEntities(CAstNode construct) {
            return null;
        }

        @Override
        public CAstNode getAST() {
            return null;
        }

        @Override
        public CAstControlFlowMap getControlFlow() {
            return null;
        }

        @Override
        public CAstSourcePositionMap getSourceMap() {
            return null;
        }

        @Override
        public Position getPosition() {
            return null;
        }

        @Override
        public Position getNamePosition() {
            return null;
        }

        @Override
        public Position getPosition(int arg) {
            return null;
        }

        @Override
        public CAstNodeTypeMap getNodeTypeMap() {
            return null;
        }

        @Override
        public Collection<CAstQualifier> getQualifiers() {
            return null;
        }

        @Override
        public CAstType getType() {
            return null;
        }

        @Override
        public Collection<CAstAnnotation> getAnnotations() {
            return null;
        }
    }



    /* Now that the structure of an ABAP program has been defined, can you please convert it :) */
    public CAstEntity visitProgram(ParseTree n, WalkContext context)
    {

        if(n.getChild(0) instanceof Program_or_report_definitionContext)
            return visitProgramOrReport((Program_or_report_definitionContext)n.getChild(0), context);
        else if(n.getChild(0) instanceof FormsContext)
            return visitForms((FormsContext)n.getChild(0), context);
        else
            return visitSingleStmt((Single_line_stmtContext)n.getChild(0), context);

    }

    private CAstEntity visitSingleStmt(Single_line_stmtContext n, WalkContext context) {
        return null;
    }

    private CAstEntity visitForms(FormsContext n, WalkContext context) {
        return null;
    }
    //TODO: Create FileEntity and followed by GlobalEntity or ClassEntity depending on the scenrio.
    private CAstEntity visitProgramOrReport(Program_or_report_definitionContext n, WalkContext context) {
//        private CAstEntity walkEntity(
//        final AstNode n, List<CAstNode> body, String name, WalkContext child) {
        final ReportWalkContext child = new ReportWalkContext(new RootContext(), n);
        //pushSourcePosition(child, n, makePosition(n));
        // WalkContext child = new DelegatingContext(context);
        final List<CAstNode> stmts;
        stmts = new ArrayList<>(n.getChildCount());
        for(ParseTree c: n.children) {
            CAstNode visitChild = visit(c, child);
            if(visitChild.getKind()!=CAstNode.EMPTY)
                stmts.add(makeNode(child, fFactory, n, CAstNode.BLOCK_STMT, visitChild));
        }
        final CAstNode rast =
                makeNode(
                        context,
                        fFactory,
                        null,
                        CAstNode.LOCAL_SCOPE,
                        makeNode(
                                child, fFactory, n, CAstNode.BLOCK_STMT, stmts));
        final CAstNode ast = makeNode(
                context,
                fFactory,
                null,
                CAstNode.IF_STMT,
                fFactory.makeConstant(true),
                rast);
        //final CAstNode ast = makeNode(child, fFactory, n, CAstNode.BLOCK_STMT, stmts);
        final CAstControlFlowMap map = child.cfg();
        final CAstSourcePositionMap pos = child.pos();
        final Map<CAstNode, Collection<CAstEntity>> subs =
                HashMapFactory.make(child.getScopedEntities());
        System.out.println(ast);
        return new ReportEntity(n, subs, ast, map, pos, n.use1_identifier().identifier().getText());
    }

    private CAstEntity createProgram(ParseTree n, String name, int modifier, List<Program_or_report_optionContext> options, List<ParseTree> forms, WalkContext context) {

        return null;
    }
//No need to use it as it has been deprecated because of the usage of CAstEntity
//    public CAstNode parseAntlr2CAst(ParseTree n)
//    {
//        CAstNode cNode = visit(n, new WalkContext() {
//            @Override
//            public Map<ParseTree, String> getLabelMap() {
//                return null;
//            }
//
//            @Override
//            public boolean needLValue() {
//                return false;
//            }
//
//            @Override
//            public TranslatorToCAst.WalkContext<WalkContext, ParseTree> getParent() {
//                return null;
//            }
//        });
//        return cNode;
//    }

    /**
     * HANDLING OF VARIOUS THINGS
     */
    private CAstNode visit(ParseTree n, WalkContext context) {
        if(n==null || ( n instanceof End_of_statementContext) || (n instanceof Endselect_stmt_lineContext)) {
            return makeNode(context, fFactory, null, CAstNode.EMPTY);

        } else if (n instanceof Andor_expressionContext) {
            return visit((Andor_expressionContext)n, context);
        } else if (n instanceof Appending_clauseContext) {
            return visit((Appending_clauseContext)n, context);
        } else if (n instanceof Arrow_expressionContext) {
            return visit((Arrow_expressionContext)n, context);
        } else if (n instanceof AssignmentContext) {
            return visit((AssignmentContext) n, context);
        } else if (n instanceof AssignmentLeftHandSideContext) {
            return visit((AssignmentLeftHandSideContext) n, context);
        } else if (n instanceof Between_expressionContext) {
            return visit((Between_expressionContext)n, context);
        } else if (n instanceof Binary_expressionContext) {
            return visit((Binary_expressionContext)n, context);
        } else if (n instanceof Call_expressionContext) {
            return visit((Call_expressionContext)n, context);
        } else if (n instanceof Comparison_expressionContext) {
            return visit((Comparison_expressionContext)n, context);
        }else if (n instanceof Data_declarationContext) {
            return visit((Data_declarationContext) n, context);
        }else if (n instanceof Data_decl_clauseContext) {
            return visit((Data_decl_clauseContext) n, context);
        }else if (n instanceof Part_declContext) {
            return visit((Part_declContext) n, context);
        }else if (n instanceof Decl_option_clauseContext) {
            return visit((Decl_option_clauseContext) n, context);
        }else if (n instanceof Decl_type_clauseContext) {
            return visit((Decl_type_clauseContext) n, context);
        }else if (n instanceof Def_assignmentLeftHandSideContext) {
            return visit((Def_assignmentLeftHandSideContext) n, context);
        }else if (n instanceof Def_andor_expressionContext) {
            return visit((Def_andor_expressionContext) n, context);
        }else if (n instanceof Def_into_clauseContext) {
            return visit((Def_into_clauseContext) n, context);
        }else if (n instanceof Def_write_toContext) {
            return visit((Def_write_toContext) n, context);
        }else if (n instanceof Equal_select_expressionContext) {
            return visit((Equal_select_expressionContext) n, context);
        }else if (n instanceof Expression_statementContext) {
            return visit((Expression_statementContext) n, context);
        }else if (n instanceof For_all_entries_clauseContext) {
            return visit((For_all_entries_clauseContext) n, context);
        }else if (n instanceof Format_declContext) {
            return visit((Format_declContext) n, context);
        }else if (n instanceof FormsContext) {
            return visit((FormsContext)n, context);
        }else if (n instanceof From_clauseContext) {
            return visit((From_clauseContext)n, context);
        }else if (n instanceof From_elementContext) {
            return visit((From_elementContext)n, context);
        }else if (n instanceof Group_by_clauseContext) {
            return visit((Group_by_clauseContext)n, context);
        }else if (n instanceof Group_by_tailContext) {
            return visit((Group_by_tailContext)n, context);
        }else if (n instanceof Having_clauseContext) {
            return visit((Having_clauseContext)n, context);
        } else if (n instanceof IdentifierContext) {
            return visit((IdentifierContext) n, context);
        }else if (n instanceof Identifier_lexContext) {
            return visit((Identifier_lexContext) n, context);
        }else if (n instanceof If_statementContext) {
            return visit((If_statementContext) n, context);
        }else if (n instanceof In_clauseContext) {
            return visit((In_clauseContext) n, context);
        }else if (n instanceof Into_clauseContext) {
            return visit((Into_clauseContext) n, context);
        }else if (n instanceof Is_initial_expressionContext) {
            return visit((Is_initial_expressionContext)n, context);
        }else if (n instanceof Keyword_as_identifierContext) {
            return visit((Keyword_as_identifierContext) n, context);
        }else if (n instanceof Keyword_as_identifierContext) {
            return visit((Keyword_as_identifierContext) n, context);
        }else if (n instanceof NumberContext) {
            return visit((NumberContext) n, context);
        }else if (n instanceof Order_by_clauseContext) {
            return visit((Order_by_clauseContext) n, context);
        }else if (n instanceof Order_by_tailContext) {
            return visit((Order_by_tailContext) n, context);
        }else if (n instanceof OtherContext) {
            return visit((OtherContext) n, context);
        }else if (n instanceof Paren_andor_expressionContext) {
            return visit((Paren_andor_expressionContext)n, context);
        }else if (n instanceof Paren_select_between_expressionContext) {
            return visit((Paren_select_between_expressionContext)n, context);
        } else if (n instanceof Prefix_expressionContext) {
            return visit((Prefix_expressionContext)n, context);
        }else if (n instanceof ProgramContext) {
            return visit((ProgramContext) n, context);
        } else if(n instanceof Program_or_report_definitionContext) {
            return visit((Program_or_report_definitionContext) n, context);
        } else if (n instanceof R_formatContext) {
            return visit((R_formatContext) n, context);
        } else if (n instanceof R_typeContext) {
            return visit((R_typeContext) n, context);
        } else if (n instanceof Select_andor_expressionContext) {
            return visit((Select_andor_expressionContext) n, context);
        }else if (n instanceof Select_between_expressionContext) {
            return visit((Select_between_expressionContext) n, context);
        }else if (n instanceof Select_binary_expressionContext) {
            return visit((Select_binary_expressionContext) n, context);
        }else if (n instanceof Select_call_expressionContext) {
            return visit((Select_call_expressionContext) n, context);
        }else if (n instanceof Select_comparison_expressionContext) {
            return visit((Select_comparison_expressionContext) n, context);
        } else if (n instanceof Select_expression_dContext) {
            return visit((Select_expression_dContext) n, context);
        } else if (n instanceof Select_expression_2Context) {
            return visit((Select_expression_2Context) n, context);
        } else if (n instanceof Select_clauseContext) {
            return visit((Select_clauseContext) n, context);
        } else if (n instanceof Select_where_clauseContext) {
            return visit((Select_where_clauseContext) n, context);
        } else if (n instanceof Select_expression_sContext) {
            return visit((Select_expression_sContext) n, context);
        } else if (n instanceof Select_statementContext) {
            return visit((Select_statementContext) n, context);
        } else if (n instanceof Select_statement_expressionContext) {
            return visit((Select_statement_expressionContext) n, context);
        }else if (n instanceof Statement_formContext) {
            return visit((Statement_formContext) n, context);
        }else if (n instanceof Start_statement_formContext) {
            return visit((Start_statement_formContext) n, context);
        }else if (n instanceof Sub_unary_expressionContext) {
            return visit((Sub_unary_expressionContext) n, context);
        }else if (n instanceof TableContext) {
            return visit((TableContext)n, context);
        }else if (n instanceof Table_declarationContext) {
            return visit((Table_declarationContext)n, context);
        }else if (n instanceof Table_decl_clauseContext) {
            return visit((Table_decl_clauseContext)n, context);
        }else if (n instanceof TerminalNodeImpl) {
            return visit((TerminalNodeImpl) n, context);
            //}else if (n instanceof End_of_statementContext) {
            //    return visit((End_of_statementContext) n, context);
        }else if (n instanceof Udvar_keyword_as_identifierContext) {
            return visit((Udvar_keyword_as_identifierContext) n, context);
        }else if (n instanceof Unary_expressionContext) {
            return visit((Unary_expressionContext) n, context);
        }else if (n instanceof Up_to_clauseContext) {
            return visit((Up_to_clauseContext) n, context);
        }else if (n instanceof Use1_andor_expressionContext) {
            return visit((Use1_andor_expressionContext)n, context);
        }else if (n instanceof Use1_appending_clauseContext) {
            return visit((Use1_appending_clauseContext) n, context);
        }else if (n instanceof Use1_binary_expressionContext) {
            return visit((Use1_binary_expressionContext) n, context);
        }else if (n instanceof Use1_decl_type_clauseContext) {
            return visit((Use1_decl_type_clauseContext) n, context);
        }else if (n instanceof Use1_for_all_entries_clauseContext) {
            return visit((Use1_for_all_entries_clauseContext) n, context);
        }else if (n instanceof Use1_format_declContext) {
            return visit((Use1_format_declContext) n, context);
        }else if (n instanceof Use1_formatContext) {
            return visit((Use1_formatContext) n, context);
        }else if (n instanceof Use1_from_elementContext) {
            return visit((Use1_from_elementContext)n, context);
        }else if (n instanceof Use1_group_by_clauseContext) {
            return visit((Use1_group_by_clauseContext)n, context);
        }else if (n instanceof Use1_having_clauseContext) {
            return visit((Use1_having_clauseContext)n, context);
        }else if (n instanceof Use1_identifierContext) {
            return visit((Use1_identifierContext) n, context);
        }else if (n instanceof Use1_otherContext) {
            return visit((Use1_otherContext) n, context);
        }else if (n instanceof Use1_select_binary_expressionContext) {
            return visit((Use1_select_binary_expressionContext) n, context);
        }else if (n instanceof Use1_sub_unary_expressionContext) {
            return visit((Use1_sub_unary_expressionContext) n, context);
        }else if (n instanceof Use1_unary_expressionContext) {
            return visit((Use1_unary_expressionContext) n, context);
        }else if (n instanceof Use1_up_to_clauseContext) {
            return visit((Use1_up_to_clauseContext) n, context);
        }else if (n instanceof Use1_valueContext) {
            return visit((Use1_valueContext) n, context);
        }else if (n instanceof Usedef_work_areaContext) {
            return visit((Usedef_work_areaContext) n, context);
        }else if (n instanceof Use1_write_optionContext) {
            return visit((Use1_write_optionContext) n, context);
        }else if (n instanceof Use1_write_tailContext) {
            return visit((Use1_write_tailContext) n, context);
        }else if (n instanceof While_statementContext) {
            return visit((While_statementContext) n, context);
        }else if (n instanceof Whenever_clauseContext) {
            return visit((Whenever_clauseContext) n, context);
        }else if (n instanceof Write_statementContext) {
            return visit((Write_statementContext) n, context);
        }else if (n instanceof Write_clauseContext) {
            return visit((Write_clauseContext) n, context);
        }else if (n instanceof Write_optionContext) {
            return visit((Write_optionContext) n, context);
        }else if (n instanceof Write_tailContext) {
            return visit((Write_tailContext) n, context);
        }else if (n instanceof Write_toContext) {
            return visit((Write_toContext) n, context);}


        Assertions.UNREACHABLE("Unhandled node type " + n.getClass().getCanonicalName());

        return null;

    }
    // Code for while statement. Here, we take the loop condition and the body under the loop. Also to mark the break and continue labels, we create a dummy node having the
    // the body of the loop in this. Since, with every iteration, the loop condition will be checked, the break and continue will point there.
    private CAstNode visit(While_statementContext n, WalkContext context)
    {
        Use1_andor_expressionContext cond = n.while_stmt_line().use1_andor_expression();
        List<Statement_formContext> body = n.statement_form();

        ParseTree breakTarget = makeBreakOrContinueTarget(n, "breakLabel" + ((ParserRuleContext)n).getStart().getStartIndex());

        CAstNode breakNode = makeNode(
                context,
                fFactory,
                n,
                CAstNode.BLOCK_STMT,
                makeNode(
                        context,
                        fFactory,
                        n,
                        CAstNode.LABEL_STMT,
                        fFactory.makeConstant("breakLabel")),
                visit(breakTarget, context));
        //context.cfg().map(n, breakNode);
        ParseTree continueTarget = makeBreakOrContinueTarget(n, "continueLabel" + ((ParserRuleContext)n).getStart().getStartIndex());
        CAstNode continueNode = makeNode(
                context,
                fFactory,
                n,
                CAstNode.BLOCK_STMT,
                makeNode(
                        context,
                        fFactory,
                        n,
                        CAstNode.LABEL_STMT,
                        fFactory.makeConstant("continueLabel")),
                visit(continueTarget, context));
        //context.cfg().map(n, continueNode);
        String loopLabel = "continueLabel";
        LoopContext lc = new LoopContext(context, loopLabel, breakTarget, continueTarget);
        List<CAstNode> bodyCAst = new ArrayList<>();
        for(Statement_formContext b: body)
        {
            bodyCAst.add(visit(b, lc));
        }
        CAstNode bodySingleCAst = makeNode(context,fFactory,n, CAstNode.BLOCK_STMT, bodyCAst);
        return makeNode(
                context,
                fFactory,
                n,
                CAstNode.BLOCK_STMT,
                makeNode(
                        context,
                        fFactory,
                        n,
                        CAstNode.LOOP,
                        visit(cond, context),
                        makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, bodySingleCAst, continueNode)),
                breakNode);
    }

    private ParseTree makeBreakOrContinueTarget(ParseTree n, String s) {
        String dummyNode = "report " + s + ".\n";
        ANTLRFileStream input = null;
        try {
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write(dummyNode);
            myWriter.close();
            input = new ANTLRFileStream("filename.txt");
        } catch (IOException e) {
            getUnsafe().throwException(new IOException());
        }
        abapLexer lexer = new abapLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        abapParser parser = new abapParser(tokens);
        return parser.program();

    }

    private CAstNode visit(If_statementContext n, WalkContext context)
    {
        CAstNode if_stmt = null;
        List<Andor_operatorContext> operatorList = n.if_stmt_line().use_andor_expression().andor_expression().andor_operator();
        List<ParseTree> expressionList = new ArrayList<>();
        for (ParseTree subtree:n.if_stmt_line().use_andor_expression().andor_expression().children)
        {
            if(! (subtree instanceof  TerminalNode) && !(subtree instanceof Andor_operatorContext))
                expressionList.add(subtree);
        }
        if(n.if_stmt_line().use_andor_expression().andor_expression().getChildCount()>1)
        {
            CAstNode start=null;

            for(int i=expressionList.size()-1;i>=1;i--)
            {
                if(start==null)
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcodeBool(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), visit(expressionList.get(i),context),n);
                }
                else
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcodeBool(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), start,n);
                }

            }
            if_stmt= start;
        }
        else
        {
            if_stmt= visit(n.if_stmt_line().use_andor_expression().andor_expression().between_expression(0).comparison_expression(), context);
        }
        CAstNode else_stmt = null;
        if(n.else_clause()!=null) {
            final List<CAstNode> elsestmts;
            elsestmts = new ArrayList<>(n.else_clause().statement_form().size());
            for (ParseTree c : n.else_clause().statement_form()) {
                elsestmts.add(makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, visit(c, context)));
            }
            else_stmt = makeNode(
                    context,
                    fFactory,
                    null,
                    CAstNode.LOCAL_SCOPE,makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, elsestmts));
        }
        if(n.elseif_clause().size()!=0)
        {

            for(int i=n.elseif_clause().size()-1;i>=0;i--)
            {
                CAstNode elseifCondition = null;
                List<Andor_operatorContext> else_if_operatorList = n.elseif_clause(i).use1_andor_expression().andor_expression().andor_operator();
                List<ParseTree> else_if_expressionList = new ArrayList<>();
                for (ParseTree subtree:n.elseif_clause(i).use1_andor_expression().andor_expression().children)
                {
                    if(! (subtree instanceof  TerminalNode) && !(subtree instanceof Andor_operatorContext))
                        else_if_expressionList.add(subtree);
                }
                if(n.elseif_clause(i).use1_andor_expression().andor_expression().getChildCount()>1)
                {
                    CAstNode start=null;

                    for(int j=expressionList.size()-1;j>=1;j--)
                    {
                        if(start==null)
                        {
                            start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcodeBool(else_if_operatorList.get(i-1)),
                                    visit(else_if_expressionList.get(i-1),context), visit(else_if_expressionList.get(i),context),n);
                        }
                        else
                        {
                            start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcodeBool(else_if_operatorList.get(i-1)),
                                    visit(else_if_expressionList.get(i-1),context), start,n);
                        }

                    }
                    elseifCondition= start;
                }
                else
                {
                    elseifCondition= visit(n.elseif_clause(i).use1_andor_expression().andor_expression().between_expression(0).comparison_expression(), context);
                }
                List<CAstNode> elseifExpr;
                elseifExpr = new ArrayList<>(n.elseif_clause(i).statement_form().size());
                for(ParseTree c: n.elseif_clause(i).statement_form()) {
                    elseifExpr.add(makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, visit(c, context)));
                }
                CAstNode elseifExprNode = makeNode(
                        context,
                        fFactory,
                        null,
                        CAstNode.LOCAL_SCOPE,makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, elseifExpr));
                else_stmt = makeNode(
                                context,
                                fFactory,
                                n,
                                CAstNode.IF_STMT,
                                elseifCondition,
                                elseifExprNode,
                                else_stmt);

            }
        }
        final List<CAstNode> thenstmts;
        thenstmts = new ArrayList<>(n.then_clause().statement_form().size());
        for(ParseTree c: n.then_clause().statement_form()) {
            thenstmts.add(makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, visit(c, context)));
        }
        CAstNode then_stmt = makeNode(
                context,
                fFactory,
                null,
                CAstNode.LOCAL_SCOPE,makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, thenstmts));
        if(else_stmt!=null)
            return makeNode(
                context,
                fFactory,
                n,
                CAstNode.IF_STMT,
                if_stmt,
                then_stmt,
                else_stmt);
        else
            return makeNode(
                    context,
                    fFactory,
                    n,
                    CAstNode.IF_STMT,
                    if_stmt,
                    then_stmt);
    }
    private CAstNode visit(Def_andor_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Into_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl nodeType = new AQSTypeImpl();
        nodeType.setKind(ABAPQuerySpecificType.INTO);
        children.add(fFactory.makeConstant(nodeType));
        for(int i=0;i<n.getChildCount();i++)
        {
            if(n.getChild(i) instanceof TerminalNode)
                children.add(fFactory.makeConstant(n.getChild(i)));
            else
                children.add(visit(n.getChild(i), context));
        }
        return fFactory.makeNode(CAstNode.CLAUSES, children);
    }
    private CAstNode visit(Write_statementContext n, WalkContext context)
    {
        if(n.write_clause().size()!=0)
        {
            List<CAstNode> childrenEdit = new ArrayList<>();
            List<CAstNode> children = new ArrayList<>();
            children.add(fFactory.makeConstant("WRITE"));
            for(int i=0;i<n.write_clause().size();i++)
            {
                childrenEdit.add(visit(n.write_clause(i), context));
            }
            for(CAstNode e: childrenEdit)
            {
                if(e.getKind()==CAstNode.EMPTY)
                {
                    if(e.getChildren().size()>0)
                    {
                        for(CAstNode d: e.getChildren())
                        {
                            if(d.getKind()==CAstNode.CONSTANT)
                            {
                                for (CAstNode c : context.getNameDecls()) {
                                    if (c.getKind() == CAstNode.DECL_STMT) {
                                        CAstSymbolImpl val = (CAstSymbolImpl) c.getChildren().get(0).getValue();
                                        if (val.name().equals(d.getChild(0).getValue()))
                                            children.add(makeNode(
                                                    context,
                                                    fFactory,
                                                    n,
                                                    CAstNode.VAR,
                                                    fFactory.makeConstant(val.name()),
                                                    fFactory.makeConstant(val.type())));
                                    }
                                }
                            }
                            else if(d.getKind()==CAstNode.VAR)
                            {
                                children.add(d);
                            }

                        }
                    }
                }
            }

            return fFactory.makeNode(CAstNode.PRIMITIVE, children);
        }
        return null;
    }

    private CAstNode visit(Write_clauseContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }

    private CAstNode visit(Use1_binary_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_formatContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_format_declContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_write_tailContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_write_optionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(Def_write_toContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(Write_toContext n, WalkContext context)
    {
        return fFactory.makeNode(CAstNode.ASSIGN, visit(n.getChild(1),context));
    }

    private CAstNode visit(Write_optionContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        for(int i=0;i<n.getChildCount();i++)
        {
            if(n.getChild(i) instanceof TerminalNode)
                children.add(fFactory.makeConstant(n.getChild(i)));
            else
                children.add(visit(n.getChild(i), context));
        }
        return fFactory.makeNode(CAstNode.EMPTY, children);
    }

    private CAstNode visit(Write_tailContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        for(int i=0;i<n.getChildCount();i++)
        {
            if(n.getChild(i) instanceof TerminalNode)
                children.add(fFactory.makeConstant(n.getChild(i)));
            else
                children.add(visit(n.getChild(i), context));
        }
        return fFactory.makeNode(CAstNode.EMPTY, children);
    }

    private CAstNode visit(Format_declContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        for(int i=0;i<n.getChildCount();i++)
        {
            if(n.getChild(i) instanceof TerminalNode)
                children.add(fFactory.makeConstant(n.getChild(i)));
            else
                children.add(visit(n.getChild(i), context));
        }
        return fFactory.makeNode(CAstNode.EMPTY, children);
    }
    //Comment: TODO check how it prints
    private CAstNode visit(R_formatContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        for(int i=0;i<n.getChildCount();i++)
        {
            if(!(n.getChild(i) instanceof TerminalNode))
                children.add(visit(n.getChild(i), context));
        }
        if(children.size()==0)
            return null;
        return fFactory.makeNode(CAstNode.EMPTY, children);
    }

    private CAstNode visit(Select_statementContext n, WalkContext context)
    {
        int queryType = ABAPQuerySpecificType.SELECT;
        boolean unique = (n.select_expression_s()!=null?true:false);
        boolean distinct = (n.select_expression_d().select_option_d().size()>0?true:false);
        Select_clauseContext clauses =null;
        List<String> field = new ArrayList<>();
        List<Select_expression_2Context> fieldsExpr = new ArrayList<>();
        List<Select_clauseContext> allClauses = new ArrayList<>();
        String tableName = null;
        boolean isInto = false;
        String intoVar = null;
        if(n.select_expression_d()!=null)
        {
            fieldsExpr.add(n.select_expression_d().select_expression_2());
            Select_expression_2Context temp = n.select_expression_d().select_expression_2();
            while(temp.select_expression_2()!=null)
            {
                fieldsExpr.add(temp.select_expression_2());
                temp = temp.select_expression_2();
            }
            clauses = temp.select_clause();
            for(Select_expression_2Context s: fieldsExpr)
            {
                field.add(s.use1_unary_expression().unary_expression().identifier().identifier_lex().getChild(0).toString());
            }
        }
        if(n.select_expression_s()!=null)
        {
            fieldsExpr.add(n.select_expression_s().select_expression_2());
            Select_expression_2Context temp = n.select_expression_s().select_expression_2();
            while(temp.select_expression_2()!=null)
            {
                fieldsExpr.add(temp.select_expression_2());
                temp = temp.select_expression_2();
            }
            clauses = temp.select_clause();
            for(Select_expression_2Context s: fieldsExpr)
            {
                field.add(s.use1_unary_expression().unary_expression().identifier().identifier_lex().getText());
            }
        }
        allClauses.add(clauses);
        while(clauses!=null)
        {
            if(clauses.from_clause()!=null)
            {
                if(clauses.from_clause().select_clause()!=null)
                {
                    allClauses.add(clauses.from_clause().select_clause());
                    clauses = clauses.from_clause().select_clause();
                }
                else
                {
                    clauses = null;
                }
                break;
            }
            if(clauses.select_where_clause()!=null)
            {
                if(clauses.select_where_clause().select_clause()!=null)
                {
                    allClauses.add(clauses.select_where_clause().select_clause());
                    clauses = clauses.select_where_clause().select_clause();
                }
                else
                {
                    clauses = null;
                }
                break;
            }
            if(clauses.into_clause()!=null)
            {
                if(clauses.into_clause().select_clause()!=null)
                {
                    allClauses.add(clauses.into_clause().select_clause());
                    clauses = clauses.into_clause().select_clause();
                }
                else
                {
                    clauses = null;
                }
                break;
            }
        }
        for(Select_clauseContext c: allClauses)
        {
            if(c.from_clause()!=null)
            {
                tableName = c.from_clause().use1_from_element().from_element().table(0).identifier().getText();
            }
            if(c.into_clause()!=null)
            {
                isInto = true;
                intoVar = c.into_clause().def_andor_expression(0).andor_expression().between_expression(0).comparison_expression().binary_expression(0).call_expression(0).arrow_expression().prefix_expression(0).is_initial_expression().unary_expression().identifier().getText();
            }
        }
        if(isInto)
        {
            for (CAstNode c : context.getNameDecls()) {
                if (c.getKind() == CAstNode.DECL_STMT) {
                    CAstSymbolImpl val = (CAstSymbolImpl) c.getChildren().get(0).getValue();
                    if (val.name().equals(intoVar))
                        return makeNode(
                                context,
                                fFactory,
                                n,
                                CAstNode.ASSIGN,
                                makeNode(
                                        context,
                                        fFactory,
                                        n,
                                        CAstNode.VAR,
                                        fFactory.makeConstant(intoVar),
                                        fFactory.makeConstant(val.type())),
                                //makeNode(context, fFactory, n, CAstNode.CALL, fFactory.makeConstant("Dummy"),fFactory.makeConstant("dummy")));
                                makeNode(context, fFactory, n, CAstNode.QUERY, fFactory.makeConstant(new CAstQueryImpl(queryType, unique, distinct, tableName, field, val.type()))));
                }
            }
        }
        else
        {
            return makeNode(context, fFactory, n, CAstNode.QUERY, fFactory.makeConstant(new CAstQueryImpl(queryType, unique, distinct, tableName, field, null)));
        }

        return null;
        // Previous version of query handling
//        //Comment: For now not handling SELECT (select_type_clause COMMA)* END OF use1_identifier ENDEXEC? end_of_statement
//        AQSTypeImpl nodeType = new AQSTypeImpl();
//        nodeType.setKind(ABAPQuerySpecificType.SELECT);
//        if(n.select_expression_d()!=null)
//        {
//            if(n.select_expression_d().select_option_d().size()!=0)
//            {
//                nodeType.setKind(ABAPQuerySpecificType.DISTINCT);
//            }
//        }
//        if(n.select_expression_s()!=null)
//        {
//            nodeType.setKind(ABAPQuerySpecificType.UNIQUE);
//        }
//        List<CAstNode> children = new ArrayList<>();
//        if (nodeType.kind.size()!=0)
//            children.add(fFactory.makeConstant(nodeType));
//        for(int i =0; i<n.getChildCount(); i++)
//        {
//            children.add(visit(n.getChild(i), context));
//        }
//        return makeNode(context, fFactory, n, CAstNode.QUERY, children);
    }
    private CAstNode visit(Select_statement_expressionContext n, WalkContext context)
    {
        //Comment: For now not handling SELECT (select_type_clause COMMA)* END OF use1_identifier ENDEXEC? end_of_statement
        AQSTypeImpl nodeType = new AQSTypeImpl();
        nodeType.setKind(ABAPQuerySpecificType.SELECT);
        if(n.select_expression_d()!=null)
        {
            if(n.select_expression_d().select_option_d().size()!=0)
            {
                nodeType.setKind(ABAPQuerySpecificType.DISTINCT);
            }
        }
        if(n.select_expression_s()!=null)
        {
            nodeType.setKind(ABAPQuerySpecificType.UNIQUE);
        }
        List<CAstNode> children = new ArrayList<>();
        if (nodeType.kind.size()!=0)
            children.add(fFactory.makeConstant(nodeType));
        for(int i =0; i<n.getChildCount(); i++)
        {
            children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.QUERY, children);
    }

    private CAstNode visit(Select_expression_dContext n, WalkContext context)
    {
        return visit(n.select_expression_2(), context);
    }

    private CAstNode visit(Select_expression_2Context n, WalkContext context)
    {
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        if(n.COUNT()!=null)
            queryTypes.setKind(ABAPQuerySpecificType.COUNT);
        if(n.TIMES()!=null)
            queryTypes.setKind(ABAPQuerySpecificType.TIMES);
        if(n.select_option_d()!=null)
            queryTypes.setKind(ABAPQuerySpecificType.DISTINCT);
        List<CAstNode> children = new ArrayList<>();
        if (queryTypes.kind.size()!=0)
            children.add(fFactory.makeConstant(queryTypes));

        if(n.use1_unary_expression()!=null && !(n.getParent() instanceof Select_expression_2Context))
        {
            for(int i =0; i<n.use1_unary_expression().getChildCount(); i++)
            {
                children.add(visit(n.getChild(i), context));
            }
        }
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof Select_option_dContext))
                children.add(visit(n.getChild(i), context));
        }
            return makeNode(context, fFactory, n, CAstNode.FIELDS, children);
        //return makeNode(context, fFactory, n, CAstNode.EMPTY, children);
    }

    private CAstNode visit(Select_clauseContext n, WalkContext context)
    {
        if(n.from_clause()!=null)
        {
            List<CAstNode> from = new ArrayList<>();
            AQSTypeImpl queryTypes = new AQSTypeImpl();
            if(n.from_clause().use1_from_element().from_element().INNER().size()!=0)
                queryTypes.setKind(ABAPQuerySpecificType.INNER);
            if(n.from_clause().use1_from_element().from_element().LEFT().size()!=0)
                queryTypes.setKind(ABAPQuerySpecificType.LEFT);
            if(n.from_clause().use1_from_element().from_element().OUTER().size()!=0)
                queryTypes.setKind(ABAPQuerySpecificType.OUTER);
            if (queryTypes.kind.size()!=0)
                from.add(fFactory.makeConstant(queryTypes));
            for(int i =0; i<n.from_clause().use1_from_element().from_element().getChildCount(); i++)
            {
                from.add(visit(n.from_clause().use1_from_element().from_element().getChild(i), context));
            }
            if(n.from_clause().select_clause()!=null)
            {
                from.add(visit(n.from_clause().select_clause(), context));
            }
            return makeNode(context, fFactory, n, CAstNode.FROM_TABLE, from);
            //return makeNode(context, fFactory, n, CAstNode.FROM_TABLE, visit(n.getChild(0), context));
        }

        return makeNode(context, fFactory, n, CAstNode.CLAUSES, visit(n.getChild(0), context));
    }
//    select_clause
//    : from_clause
//    | into_clause
//    | appending_clause
//    | select_where_clause
//    | group_by_clause
//    | having_clause
//    | order_by_clause
//    | for_all_entries_clause
//    | up_to_clause
//    | in_clause
//    | whenever_clause
//    | hints_clause
//    ;

    private CAstNode visit(Use1_select_statement_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(In_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        queryTypes.setKind(ABAPQuerySpecificType.IN);
        children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof TerminalNode))
                children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

    private CAstNode visit(Use1_otherContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(OtherContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Whenever_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        queryTypes.setKind(ABAPQuerySpecificType.ERRORMESSAGE);
        children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof TerminalNode))
                children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

    private CAstNode visit(Def_into_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(Usedef_work_areaContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(Use1_appending_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_group_by_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_having_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_order_by_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_for_all_entries_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Use1_up_to_clauseContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(Group_by_tailContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Group_by_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        queryTypes.setKind(ABAPQuerySpecificType.GROUP_BY);
        children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof TerminalNode))
                children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

    private CAstNode visit(Having_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        queryTypes.setKind(ABAPQuerySpecificType.HAVING);
        children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof TerminalNode))
                children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

    private CAstNode visit(Order_by_tailContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }

    private CAstNode visit(Order_by_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        queryTypes.setKind(ABAPQuerySpecificType.ORDER_BY);
        if(n.PRIMARY()!=null)
            queryTypes.setKind(ABAPQuerySpecificType.PRIMARY);
        children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof TerminalNode))
                children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

    private CAstNode visit(Appending_clauseContext n, WalkContext context)
    {
        CAstNode tableName = visit(n.use1_itab(), context);
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        List<CAstNode> children = new ArrayList<>();
        children.add(tableName);
        queryTypes.setKind(ABAPQuerySpecificType.APPEND);
        if(n.PACKAGE_tok()!=null)
        {
            queryTypes.setKind(ABAPQuerySpecificType.PACKAGE);
            children.add(visit(n.use1_number(), context));
        }
        children.add(fFactory.makeConstant(queryTypes));
        if(n.select_clause()!=null)
            children.add(visit(n.select_clause(), context));
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, makeNode(context, fFactory, n, CAstNode.FROM_TABLE, children));
    }

    private CAstNode visit(For_all_entries_clauseContext n, WalkContext context)
    {
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        List<CAstNode> children = new ArrayList<>();
        queryTypes.setKind(ABAPQuerySpecificType.FORALL);
        children.add(fFactory.makeConstant(queryTypes));
        children.add(visit(n.use1_unary_expression(), context));
        if(n.select_clause()!=null)
            children.add(visit(n.select_clause(), context));
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

    private CAstNode visit(Up_to_clauseContext n, WalkContext context)
    {
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        List<CAstNode> children = new ArrayList<>();
        queryTypes.setKind(ABAPQuerySpecificType.ROWS);
        if(n.use1_number()!=null)
            children.add(visit(n.use1_number(), context));
        else
            children.add(visit(n.use1_identifier(), context));
        children.add(fFactory.makeConstant(queryTypes));
        if(n.select_clause()!=null)
            children.add(visit(n.select_clause(), context));
        return makeNode(context, fFactory, n, CAstNode.CLAUSES, children);
    }

//Remaining is INTO_Clause and HINTS_Caluse


    private CAstNode visit(Select_where_clauseContext n, WalkContext context)
    {
        List<CAstNode> children = new ArrayList<>();
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        queryTypes.setKind(ABAPQuerySpecificType.WHERE);
        children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            if(! (n.getChild(i) instanceof Select_option_dContext))
                children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.EMPTY, children);
    }

    private CAstNode visit(From_clauseContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Use1_from_elementContext n, WalkContext context)
    {
        return CreateEmptyNodeOneChild(n, context);
    }

    private CAstNode visit(From_elementContext n, WalkContext context)
    {
        AQSTypeImpl queryTypes = new AQSTypeImpl();
        if(n.INNER().size()!=0)
            queryTypes.setKind(ABAPQuerySpecificType.INNER);
        if(n.LEFT().size()!=0)
            queryTypes.setKind(ABAPQuerySpecificType.LEFT);
        if(n.OUTER().size()!=0)
            queryTypes.setKind(ABAPQuerySpecificType.OUTER);
        List<CAstNode> children = new ArrayList<>();
        if (queryTypes.kind.size()!=0)
            children.add(fFactory.makeConstant(queryTypes));
        for(int i =0; i<n.getChildCount(); i++)
        {
            children.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.EMPTY, children);
    }

    private CAstNode visit(TableContext n, WalkContext context)
    {
        if(n.AS()!=null)
            return makeNode(
                    context,
                    fFactory,
                    n,
                    CAstNode.ASSIGN,
                    visit(n.alias().identifier(), new AssignmentWalkContext(context)),
                    visit(n.identifier(), context));
        return visit(n.identifier(),context);
    }
    //TODO: PARAM LIKE use1_unary_expression ESCAPE use1_unary_expression Do not know how it is used.
    private CAstNode visit(Select_andor_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }

    private CAstNode visit (Sub_unary_expressionContext n, WalkContext context)
    {
        if(n.getChildCount()==1)
            return visit(n.getChild(0), context);
        else
            return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit (Use1_sub_unary_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }

    private CAstNode visit(Select_between_expressionContext n, WalkContext context)
    {
        if(n.BETWEEN()!=null)
        {
            CAstNode rhs = makeNode(context, fFactory,CAstNode.BINARY_EXPR,CAstOperator.OP_REL_AND,
                    visit(n.unary_expression(0),context), visit(n.unary_expression(1),context), n);
            return makeNode(context, fFactory,CAstNode.BINARY_EXPR,CAstOperator.OP_REL_BETWEEN,
                    visit(n.select_binary_expression(),context), rhs, n);
        }
        else if(n.getChildCount()==1)
            return visit(n.getChild(0), context);
        else if(n.NOT()!=null && n.EXISTS()!=null)
        {
            return makeNode(context, fFactory,CAstNode.UNARY_EXPR,CAstOperator.OP_NOT,
                    fFactory.makeConstant(ABAPQuerySpecificType.EXISTS),visit(n.use1_select_statement_expression(),context),n);
        }
        return null;
    }
    private CAstNode visit(Use1_select_binary_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    private CAstNode visit(Select_binary_expressionContext n, WalkContext context)
    {
        CAstNode opNode = null;
        List<Binary_operatorContext> operatorList = n.binary_operator();
        List<ParseTree> expressionList = new ArrayList<>();
        for (ParseTree subtree:n.children)
        {
            if(! (subtree instanceof  TerminalNode) && !(subtree instanceof Binary_operatorContext))
                expressionList.add(subtree);
        }
        if(n.getChildCount()>1)
        {
            CAstNode start=null;

            for(int i=expressionList.size()-1;i>=1;i--)
            {
                if(start==null)
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcode(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), visit(expressionList.get(i),context),n);
                }
                else
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcode(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), start,n);
                }

            }
            return start;
        }
        else
        {
            return visit(n.getChild(0), context);
        }
    }

    private CAstNode visit(Select_call_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }

    private CAstNode visit(Equal_select_expressionContext n, WalkContext context)
    {
        Comparison_operatorContext operator = n.comparison_operator();
        CAstNode rightHand;
        if(n.SOME()!=null)
        {
            AQSTypeImpl nodeType =  new AQSTypeImpl();
            nodeType.setKind(ABAPQuerySpecificType.SOME);
            List<CAstNode> children = new ArrayList<>();
            children.add(fFactory.makeConstant(nodeType));
            children.add(visit(n.select_statement_expression(), context));
            rightHand= makeNode(context, fFactory, n, CAstNode.EMPTY,children);
        }
        else
        {
        rightHand = visit(n.select_statement_expression(), context);
        }
        return makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapComparisonOpcode(operator),
                visit(n.use1_sub_unary_expression(),context), rightHand,n);
    }
    private CAstNode visit(Select_comparison_expressionContext n, WalkContext context)
    {
        CAstNode opNode = null;
        List<Comparison_operatorContext> operatorList = n.comparison_operator();
        List<ParseTree> expressionList = new ArrayList<>();
        for (ParseTree subtree:n.children)
        {
            if(! (subtree instanceof  TerminalNode) && !(subtree instanceof Comparison_operatorContext))
                expressionList.add(subtree);
        }
        if(n.getChildCount()>1)
        {
            CAstNode start=null;

            for(int i=expressionList.size()-1;i>=1;i--)
            {
                if(start==null)
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapComparisonOpcode(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), visit(expressionList.get(i),context),n);
                }
                else
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapComparisonOpcode(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), start,n);
                }

            }
            return start;
        }
        else
        {
            return visit(n.getChild(0), context);
        }
    }

    private CAstNode visit(Use1_valueContext n, WalkContext context)
    {

        if(n.value().number()!=null)
            return visit(n.value().number(),context);
        else
            return fFactory.makeConstant(n.value().LITERAL_ID());
//        if(n.value().number()!=null)
//            return visit(n.value().number(), context);
//        else
//            return visit(n.value().LITERAL_ID(), context);
    }

    private CAstNode visit (Paren_select_between_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(1), context);
    }
    private CAstNode visit(Select_expression_sContext n, WalkContext context)
    {
        return visit(n.select_expression_2(), context);
    }
    private CAstNode visit(Use1_unary_expressionContext n, WalkContext context)
    {
        return visit(n.getChild(0), context);
    }
    // This method is the entry point of all ABAP programs. We add all the child nodes to the root node.
    private CAstNode visit(ProgramContext n, WalkContext context)
    {
        return makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, visit(n.getChild(0),context));
    }
    private CAstNode CreateEmptyNodeOneChild(ParseTree n, WalkContext context)
    {
        if(n.getChildCount()==1){
            return visit(n.getChild(0),context);
        }
        return null;
    }
    private CAstNode CreateEmptyNodeGTOneChild(ParseTree n, WalkContext context)
    {
        if(n.getChildCount()==1){
            return visit(n.getChild(0),context);
        }
        else {
            ArrayList<CAstNode> nodeList = new ArrayList<>();
            for(int i =0; i<n.getChildCount(); i++)
            {
                nodeList.add(visit(n.getChild(i), context));
            }
            List<CAstNode> list = new ArrayList<CAstNode>();

            for(CAstNode s : nodeList) {
                if(s != null) {
                    list.add(s);
                }
            }
            return makeNode(context, fFactory, n, CAstNode.EMPTY, list);
        }
    }
    // This visitor parses the report or program definition e.g., REPORT test.
    private CAstNode visit(Program_or_report_definitionContext r, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        for(int i =0; i<r.getChildCount(); i++)
        {
            nodeList.add(visit(r.getChild(i), context));
        }
        return makeNode(context, fFactory, r, CAstNode.BLOCK_STMT, nodeList);
    }
    private CAstNode visit(FormsContext r, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        for(int i =0; i<r.getChildCount(); i++)
        {
            nodeList.add(visit(r.getChild(i), context));
        }
        return makeNode(context, fFactory, r, CAstNode.BLOCK_STMT, nodeList);
    }
    private CAstNode visit(Use1_identifierContext n, WalkContext context)
    {
        return fFactory.makeConstant(n.identifier().getText());
        //return visit(n.getChild(0), context);
    }
    private CAstNode visit(IdentifierContext n, WalkContext context)
    {
        return CreateEmptyNodeOneChild(n, context);
    }
    private CAstNode visit(Use1_andor_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeOneChild(n, context);
    }
    private CAstNode visit(Call_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Andor_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Between_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Paren_andor_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Comparison_expressionContext n, WalkContext context)
    {
        CAstNode opNode = null;
        List<Comparison_operatorContext> operatorList = n.comparison_operator();
        List<Binary_expressionContext> expressionList = n.binary_expression();
        //T pos = makePosition(n.getStart().getLine(), n.getStop().getLine());
        if(n.getChildCount()>1)
        {
            CAstNode start=null;

            for(int i=expressionList.size()-1;i>=1;i--)
            {
                if(start==null)
                {
                    CAstNode rhs = visit(expressionList.get(i),context);
                    if(rhs.getKind()==CAstNode.CONSTANT)
                    {
                        start = makeNode(context, fFactory, CAstNode.BINARY_EXPR, Antlr2CAstTranslator.mapComparisonOpcode(operatorList.get(i - 1)),
                                visit(expressionList.get(i - 1), context), fFactory.makeConstant(rhs.getChild(0).getValue()), n);
                    }
                    else {
                        start = makeNode(context, fFactory, CAstNode.BINARY_EXPR, Antlr2CAstTranslator.mapComparisonOpcode(operatorList.get(i - 1)),
                                visit(expressionList.get(i - 1), context), visit(expressionList.get(i), context), n);
                    }
                }
                else
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapComparisonOpcode(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), start,n);
                }

            }
            return start;
        }
        else
        {
            return visit(n.getChild(0), context);
        }
    }
    private CAstNode visit(Is_initial_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Arrow_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Prefix_expressionContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    private CAstNode visit(Udvar_keyword_as_identifierContext n, WalkContext context)
    {
        return CreateEmptyNodeOneChild(n, context);
    }
    private CAstNode visit(Keyword_as_identifierContext n, WalkContext context)
    {
        return fFactory.makeConstant(n.getChild(0).getText());
    }
    private CAstNode visit(Identifier_lexContext n, WalkContext context)
    {
        return fFactory.makeConstant(n.IDENTIFIER().getText());
    }
    private CAstNode visit(Return_statementContext r, WalkContext context) {
        return makeNode(context, fFactory, r, CAstNode.RETURN);
    }
    //TODO: Type of terminal node based operation not a general one.
    private CAstNode visit(Decl_type_clauseContext n, WalkContext context)
    {
        if(n.r_type()!=null)
            return CreateEmptyNodeOneChild(n, context);
        else
            return null;
    }
    //TODO:Check.
    private CAstNode visit(TerminalNodeImpl r, WalkContext context) {
        return makeNode(context, fFactory,r, CAstNode.EMPTY);
        //return fFactory.makeConstant(r.getText());
    }
    // Ask Julian how to tackle such cases.
    private CAstNode visit(End_of_statementContext r, WalkContext context) {
        return makeNode(context, fFactory, r, CAstNode.EMPTY);
    }

    private CAstNode visit(Statement_formContext n, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        for(int i =0; i<n.getChildCount(); i++)
        {
            nodeList.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, nodeList);
    }

    private CAstNode visit(Start_statement_formContext n, WalkContext context)
    {
        if(n.getChildCount()==1){
            return visit(n.getChild(0),context);
        }
        return null;
    }

    private CAstNode visit(Data_declarationContext n, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        for(int i =0; i<n.getChildCount(); i++)
        {
            nodeList.add(visit(n.getChild(i), context));
        }
        CAstEntity dataDeclarationEntity;
        final CAstNode declNode = makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, nodeList);
//        for (Data_decl_clauseContext dc: n.data_decl_clause()) {
//                dataDeclarationEntity = visitDataDecl(dc, context);
//                context.addScopedEntity(declNode, dataDeclarationEntity);
//        }
        return declNode;
    }
    //TODO: Enter more information
    private CAstEntity visitDataDecl(Data_decl_clauseContext n, WalkContext context) {
        if(n.identifier()==null)
        {
            String name = n.part_decl(0).identifier().getText();
            return new FieldEntity(name, null, makePosition(n),null, null);
        }
        //TODO:Not implemented
        return null;

    }

    private CAstNode visit(Table_declarationContext n, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        for(int i =0; i<n.getChildCount(); i++)
        {
            nodeList.add(visit(n.getChild(i), context));
        }
        return makeNode(context, fFactory, n, CAstNode.BLOCK_STMT, nodeList);
    }

    private CAstNode visit(Table_decl_clauseContext n, WalkContext context)
    {
        List<IdentifierContext> identifiers = n.identifier();
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        for(int i = 0; i<identifiers.size();i++)
        {
            nodeList.add(fFactory.makeConstant(identifiers.get(i).getText()));
        }
        return makeNode(context, fFactory, n, CAstNode.EMPTY, nodeList);
    }

    private CAstNode visit(Data_decl_clauseContext n, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        String varName=null;
        Object varValue=null;
        CAstType varType=null;
        for(int i =0; i<n.getChildCount(); i++)
        {
            nodeList.add(visit(n.getChild(i), context));
        }
        // Code for part_decl //
        if(n.BEGIN()==null)
        {
            varName = n.part_decl(0).identifier().getText();
            if(n.part_decl(0).decl_option_clause()!=null)
            {
                for(Decl_option_clauseContext d: n.part_decl(0).decl_option_clause())
                {

                    if(d.use1_decl_type_clause()!=null)
                    {
                        //It only works for primitive type declare.
                        varType =AbapPrimitiveTypeMap.lookupType(d.use1_decl_type_clause().decl_type_clause().r_type().identifier().getText());
                    }
                    if(varType!=null) {
                        if (d.VALUE() != null) {
                            if (d.use1_value() != null)
                                varValue = d.use1_value().getText();
                            else
                                varValue = d.use1_identifier().identifier().getText();
                        } else {
                            varValue = ABAPCastutils.defaultValueForType(varType);
                        }
                    }
                }
            }
        }
        // Code for User-defined data type //
        else
        {

        }
        CAstNode declNode = makeNode(context, fFactory, n, CAstNode.DECL_STMT, fFactory.makeConstant(new CAstSymbolImpl(varName, varType, false, varValue)));
        context.addNameDecl(declNode);
        return declNode;
    }
    // Need to check how part_decl works in practice.
    private CAstNode visit(Part_declContext n, WalkContext context)
    {
        return CreateEmptyNodeGTOneChild(n, context);
    }
    // Need to check how part_decl works in practice.
    private CAstNode visit(Decl_option_clauseContext n, WalkContext context)
    {
        if(n.RT()!=null || n.LIKE()!=null)
        {
            return makeNode(context, fFactory, n, CAstNode.TYPE_OF, visit(n.use1_decl_type_clause(), context));
        }
        //TODO:Check if the assignment is correct or not.
        if(n.LENGTH()!=null)
        {
            return makeNode(context, fFactory, n, CAstNode.ARRAY_LENGTH, visit(n.use1_size(), context));
        }
        if(n.VALUE()!=null)
        {
            if(n.use1_value()!=null)
                return makeNode(context, fFactory, n, CAstNode.ASSIGN, visit(n.use1_value(), context));
            else if(n.use1_identifier()!=null)
                return makeNode(context, fFactory, n, CAstNode.ASSIGN, visit(n.use1_identifier(), context));
            else
                return makeNode(context, fFactory, null, CAstNode.EMPTY);
        }
        return null;
    }
    private CAstNode visit(Use1_decl_type_clauseContext n, WalkContext context)
    {
        return CreateEmptyNodeOneChild(n, context);
    }
    private CAstNode visit(AssignmentContext n, WalkContext context)
    {
        int CAstNodeType;
        if(((Assignment_operatorContext)(n.getChild(1))).EQUALS()!=null)
        {
            CAstNodeType = CAstNode.ASSIGN;
        }
        else
        {
            CAstNodeType = CAstNode.CAST;
        }
        CAstNode lhs = visit(n.getChild(0), new AssignmentWalkContext(context));
        CAstNode rhs = visit(n.getChild(2), context);
        if(rhs.getKind()==CAstNode.CONSTANT)
        {
            return makeNode(
                    context,
                    fFactory,
                    n,
                    CAstNodeType,
                    lhs,
                    //fFactory.makeConstant(Integer.parseInt((String)rhs.getChild(0).getValue())));
                    fFactory.makeConstant(rhs.getChild(0).getValue()));
        }
        return makeNode(
                context,
                fFactory,
                n,
                CAstNodeType,
                lhs,
                visit(n.getChild(2), context));
    }

    private CAstNode visit(Def_assignmentLeftHandSideContext n, WalkContext context)
    {
        //zChange
        if(n.getChildCount()==1){
            return visit(n.getChild(0),context);
        }
        return null;
    }
    private CAstNode visit(AssignmentLeftHandSideContext n, WalkContext context)
    {
        if(n.getChildCount()==1)
        {
            if(n.identifier()!=null) {
                for (CAstNode c : context.getNameDecls()) {
                    if (c.getKind() == CAstNode.DECL_STMT) {
                        CAstSymbolImpl val = (CAstSymbolImpl) c.getChildren().get(0).getValue();
                        if (val.name().equals(n.identifier().get(0).getText()))
                            return makeNode(
                                    context,
                                    fFactory,
                                    n,
                                    CAstNode.VAR,
                                    fFactory.makeConstant(n.identifier().get(0).getText()),
                                    fFactory.makeConstant(val.type()));
                    }
                }
            }
        }
        return CreateEmptyNodeGTOneChild(n, context);
    }

//    private  CAstNode visit(Assignment_operatorContext n, WalkContext context)
//    {
//        return CreateEmptyNodeOneChild(n,context);
//    }
    private CAstNode visit(Expression_statementContext n, WalkContext context)
    {
        //return CreateEmptyNodeGTOneChild(n, context);
        if(n.assignment()!=null)
            return visit(n.assignment(), context);
        else
            return null;
        //TODO: Other expression statement not implemented.
    }
    private CAstNode visit(Unary_expressionContext n, WalkContext context)
    {
        ArrayList<CAstNode> nodeList = new ArrayList<>();
        if(n.LITERAL_ID().size()>0)
        {
            for(TerminalNode c: n.LITERAL_ID())
                nodeList.add(fFactory.makeConstant(c.getText()));
        }
        for(int i =0; i<n.getChildCount(); i++)
        {
            nodeList.add(visit(n.getChild(i), context));
        }
        //return fFactory.makeConstant(nodeList);
        if(n.identifier()!=null) {
            for (CAstNode c : context.getNameDecls()) {
                if (c.getKind() == CAstNode.DECL_STMT) {
                    CAstSymbolImpl val = (CAstSymbolImpl) c.getChildren().get(0).getValue();
                    if (val.name().equals(n.identifier().getText()))
                        return makeNode(
                                context,
                                fFactory,
                                n,
                                CAstNode.VAR,
                                fFactory.makeConstant(n.identifier().getText()),
                                fFactory.makeConstant(val.type()));
                }
            }
        }
        return makeNode(context, fFactory, n, CAstNode.CONSTANT, nodeList);
        //return makeNode(context, fFactory, n, CAstNode.UNARY_EXPR, fFactory.makeConstant(CAstNode.EMPTY), nodeList);
        //return makeNode(context, fFactory, n, CAstNode.UNARY_EXPR, nodeList);
    }
//    private CAstNode visit(Binary_operatorContext n, WalkContext context)
//    {
//        return mapBinaryOpcode(n);
//    }
    //TODO: Fix after the grammar has been fixed.
    private CAstNode visit(Binary_expressionContext n, WalkContext context)
    {
        CAstNode opNode = null;
        List<Binary_operatorContext> operatorList = n.binary_operator();
        List<Call_expressionContext> expressionList = n.call_expression();
        //T pos = makePosition(n.getStart().getLine(), n.getStop().getLine());
        if(n.getChildCount()>1)
        {
            CAstNode start=null;

            for(int i=expressionList.size()-1;i>=1;i--)
            {
                if(start==null)
                {
                    CAstNode rhs = visit(expressionList.get(i),context);
                    if(rhs.getKind()==CAstNode.CONSTANT)
                    {
                        start = makeNode(context, fFactory, CAstNode.BINARY_EXPR, Antlr2CAstTranslator.mapBinaryOpcode(operatorList.get(i - 1)),
                                visit(expressionList.get(i - 1), context), fFactory.makeConstant(rhs.getChild(0).getValue()), n);
                    }
                    else {
                        start = makeNode(context, fFactory, CAstNode.BINARY_EXPR, Antlr2CAstTranslator.mapBinaryOpcode(operatorList.get(i - 1)),
                                visit(expressionList.get(i - 1), context), visit(expressionList.get(i), context), n);
                    }
                }
                else
                {
                    start = makeNode(context, fFactory,CAstNode.BINARY_EXPR,Antlr2CAstTranslator.mapBinaryOpcode(operatorList.get(i-1)),
                            visit(expressionList.get(i-1),context), start,n);
                }

            }
            return start;
        }
        else
        {
            return visit(n.getChild(0), context);
        }
        //return opNode;
    }
    //    comparison_operator
//	:
//            (
//    EQUALS
//    |   EQ
//    |   LG
//    |   CO
//    |   CP
//    |   CS
//    |   CN
//    |   NA
//    |   NE
//    |   NP
//    |   NS
//    |   O
//    |   CA
//    |   LT_tok
//    |   LT_L_tok
//    |   LE_tok
//    |   LTE
//    |   ELT
//    |   GT
//    |   GT_tok
//    |   GE_tok
//    |   GTE
//    |   NE_tok
//    ) COLON?
//    ;
    private static CAstNode mapComparisonOpcode(Comparison_operatorContext operator) {
        if (operator.EQUALS() != null) return CAstOperator.OP_EQ;
        if (operator.EQ() != null) return CAstOperator.OP_EQ;
        if (operator.LG() != null) return CAstOperator.OP_NE;
        //if (operator.CO() != null) return CAstOperator.OP_DIV; -- No Idea
        //No Idea
//        if (operator.CP() != null) return CAstOperator.OP_ADD;
//        if (operator.CS() != null) return CAstOperator.OP_SUB;
//        if (operator.CN() != null) return CAstOperator.OP_MUL;
//        if (operator.NA() != null) return CAstOperator.OP_DIV;

        if (operator.NE() != null) return CAstOperator.OP_NE;
        //if (operator.NP() != null) return CAstOperator.OP_SUB; -- No Idea
        //if (operator.NS() != null) return CAstOperator.OP_MUL; -- No Idea
        //if (operator.O() != null) return CAstOperator.OP_DIV; -- No Idea

        //if (operator.CA() != null) return CAstOperator.OP_ADD; -- No Idea
        if (operator.LT_tok() != null) return CAstOperator.OP_LT;
        if (operator.LT_L_tok() != null) return CAstOperator.OP_LT;
        if (operator.LE_tok()!= null) return CAstOperator.OP_LE;

        if (operator.LTE() != null) return CAstOperator.OP_LE;
        //if (operator.ELT() != null) return CAstOperator.OP_SUB;OP_LE
        if (operator.GT() != null) return CAstOperator.OP_GT;
        if (operator.GT_tok() != null) return CAstOperator.OP_GT;

        if (operator.GE_tok() != null) return CAstOperator.OP_GE;
        if (operator.GTE() != null) return CAstOperator.OP_GE;
        if (operator.NE_tok() != null) return CAstOperator.OP_NE;
        if (operator.COLON() != null) return CAstOperator.OP_CONCAT;
        Assertions.UNREACHABLE(
                "Antlr2CAstTranslator.mapComparisonOpcode(): unrecognized binary operator.");
        return null;
    }
    //    binary_operator
//    :   PLUS
//    |   MINUS
//    |   TIMES
//    |   DIV
//    |   DIV_tok
//    |   IN_tok
//    |   NOT IN_tok
//    |   LIKE
//    |   NOT LIKE
//    |   MOD_tok
//    |   EXPONENT
//    |   SIGN
//    ;
    private static CAstNode mapBinaryOpcode(Binary_operatorContext operator) {
        if (operator.PLUS() != null) return CAstOperator.OP_ADD;
        if (operator.MINUS() != null) return CAstOperator.OP_SUB;
        if (operator.TIMES() != null) return CAstOperator.OP_MUL;
        if (operator.DIV() != null) return CAstOperator.OP_DIV;
        if (operator.EXPONENT() != null) return CAstOperator.OP_POW;
        //Rangeet: TODO: Check what to do here
        //if (operator.SIGN() != null) return CAstOperator.OP_ADD;
        //Token based: TODO: Have to check how actually it works in practice
        if (operator.DIV_tok() != null) return CAstOperator.OP_DIV;
        //TODO: Special Check needed here. Because if it is NOT IN_tok or NOT LIKE, then it will have two terminal nodes
        if (operator.NOT() != null && operator.IN_tok() != null) return CAstOperator.OP_NOT_IN;
        //TODO: No corresponding operator, so added some new.
        if (operator.LIKE() != null) return CAstOperator.OP_LIKE;
        if (operator.NOT() != null && operator.LIKE() != null) return CAstOperator.OP_NOT_LIKE;
        if (operator.MOD_tok() != null) return CAstOperator.OP_MOD;
        if (operator.IN_tok() != null) return CAstOperator.OP_IN;
        Assertions.UNREACHABLE(
                "Antlr2CAstTranslator.mapBinaryOpcode(): unrecognized binary operator.");
        return null;
    }
    private static CAstNode mapBinaryOpcodeBool(Andor_operatorContext operator) {
        if (operator.AND() != null) return CAstOperator.OP_REL_AND;
        if (operator.OR() != null) return CAstOperator.OP_REL_OR;
        Assertions.UNREACHABLE(
                "Antlr2CAstTranslator.mapBinaryOpcode(): unrecognized binary operator.");
        return null;
    }

    private CAstNode visit(NumberContext n, WalkContext context)
    {
        return fFactory.makeConstant(Integer.parseInt(n.NUMBER().getText()));
    }
    //TODO: Pass it to the type class to get the primitive type.
    private CAstNode visit(R_typeContext n, WalkContext context)
    {
        if(n.identifier()!=null)
        {
            String typeDecl = n.identifier().getText();
            AbapPrimitiveTypeMap.AbapPrimitiveType type = AbapPrimitiveTypeMap.lookupType(n.identifier().getText());
            if(type!=null)
                return fFactory.makeConstant(type);
            else
                return fFactory.makeConstant(typeDecl);
        }
        else
        {
            return makeNode(context, fFactory, n, CAstNode.EMPTY);
        }
    }

    ///// Making nodes based on different parameters
//    protected CAstNode makeNode(WalkContext wc, CAst Ast, ParseTree n, int kind) {
//        CAstNode cn = Ast.makeNode(kind);
//        setPos(wc, cn, n);
//        return cn;
//    }
    protected CAstNode makeNode(WalkContext wc, CAst Ast, ParseTree n, int kind) {
        CAstNode cn = Ast.makeNode(kind);
        setPos(wc, cn, n);
        return cn;
    }

    protected CAstNode makeNode(WalkContext wc, CAst Ast, ParseTree n, int kind, List<CAstNode> c) {
        CAstNode cn = Ast.makeNode(kind, c);
        setPos(wc, cn, n);
        return cn;
    }

    protected CAstNode makeNode(WalkContext wc, CAst Ast, T pos, int kind, List<CAstNode> c) {
        CAstNode cn = Ast.makeNode(kind, c);
        wc.pos().setPosition(cn, pos);
        return cn;
    }

    protected CAstNode makeNode(WalkContext wc, CAst Ast, ParseTree n, int kind, CAstNode c1, List<CAstNode> c) {
        c.add(0,c1);
        CAstNode cn = Ast.makeNode(kind, c);
        setPos(wc, cn, n);
        return cn;
    }

    protected CAstNode makeNode(
            WalkContext wc, CAst Ast, ParseTree n, int kind, CAstNode c1, CAstNode c2) {
        CAstNode cn = Ast.makeNode(kind, c1, c2);
        setPos(wc, cn, n);
        return cn;
    }

    protected CAstNode makeNode(WalkContext wc, CAst Ast, ParseTree n, int kind, CAstNode c) {
        CAstNode cn = Ast.makeNode(kind, c);
        setPos(wc, cn, n);
        return cn;
    }

    protected CAstNode makeNode(
            WalkContext wc, CAst Ast, ParseTree n, int kind, CAstNode c1, CAstNode c2, CAstNode c3) {
        CAstNode cn = Ast.makeNode(kind, c1, c2, c3);
        setPos(wc, cn, n);
        return cn;
    }

    protected CAstNode makeNode(
            WalkContext wc,
            CAst Ast,
            ParseTree n,
            int kind,
            CAstNode c1,
            CAstNode c2,
            CAstNode c3,
            CAstNode c4) {
        CAstNode cn = Ast.makeNode(kind, c1, c2, c3, c4);
        setPos(wc, cn, n);
        return cn;
    }
    protected CAstNode makeNode(
            WalkContext wc, CAst Ast, int kind, CAstNode c1, CAstNode c2, CAstNode c3, ParseTree n) {
        CAstNode cn = Ast.makeNode(kind, c1, c2, c3);
        setPos(wc, cn, n);
        //wc.pos().setPosition(wc, cn, pos);
        return cn;
    }
    protected CAstNode makeNode(
            WalkContext wc, CAst Ast, T pos, int kind, CAstNode c1, CAstNode c2, CAstNode c3) {
        CAstNode cn = Ast.makeNode(kind, c1, c2, c3);
        wc.pos().setPosition(cn, pos);
        return cn;
    }
    protected void setPos(WalkContext wc, CAstNode cn, ParseTree ptree) {
        if (ptree != null) wc.pos().setPosition(cn, makePosition(ptree));
    }
    //TODO: Is it line number of column number? If not, add here.
    //Check what is happening in actual life not in IDE life :D.
    public T makePosition(ParseTree n) {
        if(n instanceof TerminalNode)
            return makePosition(((TerminalNodeImpl) n).symbol.getLine(), ((TerminalNodeImpl) n).symbol.getStartIndex(), ((TerminalNodeImpl) n).symbol.getStopIndex());
        return makePosition(((ParserRuleContext)n).getStart().getLine(), ((ParserRuleContext)n).getStart().getStartIndex(), ((ParserRuleContext)n).getStop().getStopIndex());
    }

    public T makePosition(int line, int start, int end) {
        try {
            return (T) new RangePosition(
                    new URL("file://" + fullPath),
                    line,
                    start,
                    end);
        } catch (MalformedURLException e) {
            throw new RuntimeException("bad file: " + fullPath, e);
        }
    }

    public interface WalkContext extends TranslatorToCAst.WalkContext<WalkContext, ParseTree> {
        Collection<Pair<CAstType, Object>> getCatchTargets(CAstType type);

        Map<ParseTree, String> getLabelMap();

        boolean needLValue();
    }

    public static class RootContext extends TranslatorToCAst.RootContext<WalkContext, ParseTree>
            implements WalkContext {

        private final Vector<CAstNode> initializers = new Vector<>();

        @Override
        public Collection<Pair<CAstType, Object>> getCatchTargets(CAstType type) {
            Assertions.UNREACHABLE("RootContext.getCatchTargets()");
            return null;
        }

        @Override
        public Map<ParseTree, String> getLabelMap() {
            Assertions.UNREACHABLE("RootContext.getLabelMap()");
            return null;
        }

        @Override
        public boolean needLValue() {
            Assertions.UNREACHABLE("Rootcontext.needLValue()");
            return false;
        }
        @Override
        public void addNameDecl(CAstNode v) {
            initializers.add(v);
        }

        @Override
        public List<CAstNode> getNameDecls() {
            return initializers;
        }
    }
    public static class ReportWalkContext extends TranslatorToCAst.FunctionContext<WalkContext, ParseTree> implements WalkContext  {
        public ReportWalkContext(WalkContext parent, ParseTree s) {
            super(parent, s);
        }

        @Override
        public void addNameDecl(CAstNode n) {
            super.addNameDecl(n);
        }

        @Override
        public List<CAstNode> getNameDecls() {
            return super.getNameDecls();
        }

        @Override
        public CAstNode getCatchTarget() {
            return super.getCatchTarget();
        }

        @Override
        public CAstNode getCatchTarget(String s) {
            return super.getCatchTarget(s);
        }

        @Override
        public CAstNodeTypeMapRecorder getNodeTypeMap() {
            return super.getNodeTypeMap();
        }

        @Override
        public ParseTree getContinueFor(String label) {
            return super.getContinueFor(label);
        }

        @Override
        public ParseTree getBreakFor(String label) {
            return super.getBreakFor(label);
        }

        @Override
        public Collection<Pair<CAstType, Object>> getCatchTargets(CAstType type) {
            return null;
        }

        @Override
        public Map<ParseTree, String> getLabelMap() {
            return null;
        }

        @Override
        public boolean needLValue() {
            return false;
        }
    }

    private static class LoopContext extends BreakContext {
        private final Object continueTo;

        protected LoopContext(WalkContext parent, String label, Object breakTo, Object continueTo) {
            super(parent, label, breakTo);
            this.continueTo = continueTo;
        }

        @Override
        public ParseTree getContinueFor(String label) {
            return (label == null || label.equals(this.label)) ? (ParseTree) continueTo : super.getContinueFor(label);
        }
    }
    private static class BreakContext extends DelegatingContext {
        protected final String label;

        private final Object breakTo;

        BreakContext(WalkContext parent, String label, Object breakTo) {
            super(parent);
            this.label = label;
            this.breakTo = breakTo;
        }

        @Override
        public ParseTree getBreakFor(String label) {
            return (label == null || label.equals(this.label)) ? (ParseTree)breakTo : super.getBreakFor(label);
        }
    }
    public static class DelegatingContext
            extends TranslatorToCAst.DelegatingContext<WalkContext, ParseTree> implements WalkContext {

        public DelegatingContext(WalkContext parent) {
            super(parent);
        }

        @Override
        public Collection<Pair<CAstType, Object>> getCatchTargets(CAstType type) {
            return parent.getCatchTargets(type);
        }

        @Override
        public Map<ParseTree, String> getLabelMap() {
            return parent.getLabelMap();
        }

        @Override
        public boolean needLValue() {
            return parent.needLValue();
        }
    }
    public static class AssignmentWalkContext extends DelegatingContext {

        protected AssignmentWalkContext(WalkContext parent) {
            super(parent);
        }

        @Override
        public boolean needLValue() {
            return true;
        }
    }
    public class MethodContext implements WalkContext {
        private final Map<CAstNode, CAstEntity> fEntities;

        private final Map<ParseTree, String> labelMap = HashMapFactory.make(2);

        public MethodContext(Map<CAstNode, CAstEntity> entities) {
            // constructor did take: pd.procedureInstance(), memberEntities, context
            super();
            fEntities = entities;
        }

        private final Vector<CAstNode> initializers = new Vector<>();

        @Override
        public TranslatorToCAst.WalkContext<WalkContext, ParseTree> getParent() {
            return null;
        }

        @Override
        public void addNameDecl(CAstNode v) {
            initializers.add(v);
        }

        @Override
        public List<CAstNode> getNameDecls() {
            return initializers;
        }

        @Override
        public Collection<Pair<CAstType, Object>> getCatchTargets(CAstType type) {
            return (Collection<Pair<CAstType, Object>>) fEntities;
        }

        @Override
        public Map<ParseTree, String> getLabelMap() {
            return labelMap; // labels are kept within a method.
        }

        final CAstSourcePositionRecorder fSourceMap = new CAstSourcePositionRecorder();

        final CAstControlFlowRecorder fCFG = new CAstControlFlowRecorder(fSourceMap);

        final CAstNodeTypeMapRecorder fNodeTypeMap = new CAstNodeTypeMapRecorder();

        @Override
        public CAstControlFlowRecorder cfg() {
            return fCFG;
        }

        @Override
        public void addScopedEntity(CAstNode node, CAstEntity entity) {
            fEntities.put(node, entity);
        }

        @Override
        public CAstSourcePositionRecorder pos() {
            return fSourceMap;
        }

        @Override
        public CAstNodeTypeMapRecorder getNodeTypeMap() {
            return fNodeTypeMap;
        }
        @Override
        public CAstNode getCatchTarget() {
            return CAstControlFlowMap.EXCEPTION_TO_EXIT;
        }
//        @Override
//        public Collection<Pair<CAstType, Object>> getCatchTargets(CAstType label) {
//            // TAGALONG (need fRuntimeExcType)
//            // Why do we seemingly catch a RuntimeException in every method? this won't catch the
//            // RuntimeException above where
//            // it is supposed to be caught?
//            Collection<Pair<CAstType, Object>> result =
//                    Collections.singleton(
//                            Pair.<CAstType, Object>make(
//                                    null,CAstControlFlowMap.EXCEPTION_TO_EXIT));
//            return result;
//        }

        @Override
        public boolean needLValue() {
            return false;
        }
    }

}