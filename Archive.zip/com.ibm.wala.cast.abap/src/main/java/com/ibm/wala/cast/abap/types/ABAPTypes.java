package com.ibm.wala.cast.abap.types;

import com.ibm.wala.cast.ir.translator.AstTranslator;
import com.ibm.wala.cast.types.AstTypeReference;
import com.ibm.wala.core.util.strings.Atom;
import com.ibm.wala.types.ClassLoaderReference;
import com.ibm.wala.types.TypeReference;

public class ABAPTypes extends AstTypeReference {

    public static final String abNameStr = "ABAP";

    public static final String abLoaderNameStr = "ABAPLoader";

    public static final Atom abName = Atom.findOrCreateUnicodeAtom(abNameStr);

    public static final Atom abLoaderName = Atom.findOrCreateUnicodeAtom(abLoaderNameStr);

    public static final ClassLoaderReference abLoader =
            new ClassLoaderReference(abLoaderName, abName, null);

    public static final TypeReference Root = TypeReference.findOrCreate(abLoader, rootTypeName);

    public static final TypeReference Undefined = TypeReference.findOrCreate(abLoader, "LUndefined");

    public static final TypeReference Null = TypeReference.findOrCreate(abLoader, "LNull");

    public static final TypeReference Array = TypeReference.findOrCreate(abLoader, "LArray");

    public static final TypeReference Object = TypeReference.findOrCreate(abLoader, "LObject");

    public static final TypeReference CodeBody =
            TypeReference.findOrCreate(abLoader, functionTypeName);

    public static final TypeReference Function = TypeReference.findOrCreate(abLoader, "LFunction");

    public static final TypeReference Script = TypeReference.findOrCreate(abLoader, "LScript");

    public static final TypeReference ReferenceError =
            TypeReference.findOrCreate(abLoader, "LReferenceError");

    public static final TypeReference TypeError = TypeReference.findOrCreate(abLoader, "LTypeError");

    public static final TypeReference Primitives =
            TypeReference.findOrCreate(abLoader, "LPrimitives");

    public static final TypeReference FakeRoot = TypeReference.findOrCreate(abLoader, "LFakeRoot");

    public static final TypeReference Boolean = TypeReference.findOrCreate(abLoader, "LBoolean");

    public static final TypeReference Char = TypeReference.findOrCreate(abLoader, "LChar");

    public static final TypeReference String = TypeReference.findOrCreate(abLoader, "LString");

    public static final TypeReference Integer = TypeReference.findOrCreate(abLoader, "LInteger");

    public static final TypeReference Float = TypeReference.findOrCreate(abLoader, "LFloat");

    public static final TypeReference Number = TypeReference.findOrCreate(abLoader, "LNumber");

    public static final TypeReference Date = TypeReference.findOrCreate(abLoader, "LDate");

    public static final TypeReference RegExp = TypeReference.findOrCreate(abLoader, "LRegExp");

    public static final TypeReference BooleanObject =
            TypeReference.findOrCreate(abLoader, "LBooleanObject");

    public static final TypeReference StringObject =
            TypeReference.findOrCreate(abLoader, "LStringObject");

    public static final TypeReference NumberObject =
            TypeReference.findOrCreate(abLoader, "LNumberObject");

    public static final TypeReference DateObject =
            TypeReference.findOrCreate(abLoader, "LDateObject");

    public static final TypeReference RegExpObject =
            TypeReference.findOrCreate(abLoader, "LRegExpObject");
    public static final TypeReference DataLoader =
            TypeReference.findOrCreate(abLoader, "LDataLoader");
    public static final TypeReference Print =
            TypeReference.findOrCreate(abLoader, "LSystem.out");
}
