//package com.ibm.wala.cast.abap.ssa;
//
//import com.ibm.wala.cast.ir.ssa.AstInstructionFactory;
//import com.ibm.wala.classLoader.Language;
//
//public class SSAInstructionFactory extends  {
//}
