package com.ibm.wala.cast.abap.translator;

import java.util.List;

public interface ABAPQuerySpecificType {

    /** Query type **/
    int SELECT = 1;
    int UPDATE = 2;
    int DELETE = 3;
    int INSERT = 4;

    /** Aggregate Type **/
    int DISTINCT = 5;
    int UNIQUE = 6;
    int COUNT = 7;
    int TIMES = 8;
    int SINGLE = 9;

    /** Clause Type **/
    int WHERE = 10;
    int INTO = 11;
    int APPEND = 12;
    int GROUP_BY = 13;
    int HAVING = 14;
    int ORDER_BY = 15;
    int IN = 16;
    int INNER = 17;
    int LEFT = 18;
    int OUTER = 19;
    int SOME = 20;
    int EXISTS = 21;
    int ERRORMESSAGE = 22;
    int PRIMARY = 23;
    int PACKAGE = 24;
    int FORALL = 25;
    int ROWS = 26;

    List<Integer> getKind();

    int getKind(int i);

    /** Returns the constant value represented by this node, if appropriate, and null otherwise. */
    Object getValue();
    static String getKindAsString(int kind) {
        switch (kind) {
            // statements
            case ABAPQuerySpecificType.SELECT:
                return "SELECT";
            case ABAPQuerySpecificType.UPDATE:
                return "UPDATE";
            case ABAPQuerySpecificType.DELETE:
                return "DELETE";
            case ABAPQuerySpecificType.INSERT:
                return "INSERT";
            case ABAPQuerySpecificType.DISTINCT:
                return "DISTINCT";
            case ABAPQuerySpecificType.UNIQUE:
                return "UNIQUE";
            case ABAPQuerySpecificType.COUNT:
                return "COUNT";
            case ABAPQuerySpecificType.TIMES:
                return "TIMES";
            case ABAPQuerySpecificType.SINGLE:
                return "SINGLE";
            case ABAPQuerySpecificType.WHERE:
                return "WHERE";
            case ABAPQuerySpecificType.INTO:
                return "INTO";
            case ABAPQuerySpecificType.APPEND:
                return "APPEND";
            case ABAPQuerySpecificType.GROUP_BY:
                return "GROUP_BY";
            case ABAPQuerySpecificType.HAVING:
                return "HAVING";
            case ABAPQuerySpecificType.ORDER_BY:
                return "ORDER_BY";
            case ABAPQuerySpecificType.IN:
                return "IN";
            case ABAPQuerySpecificType.INNER:
                return "INNER";
            case ABAPQuerySpecificType.LEFT:
                return "LEFT";
            case ABAPQuerySpecificType.OUTER:
                return "OUTER";
            case ABAPQuerySpecificType.SOME:
                return "SOME";
            case ABAPQuerySpecificType.EXISTS:
                return "EXISTS";
            case ABAPQuerySpecificType.ERRORMESSAGE:
                return "NOT FOUND ERROR";
            case ABAPQuerySpecificType.PACKAGE:
                return "PACKAGE";
            case ABAPQuerySpecificType.FORALL:
                return "FORALL";
            case ABAPQuerySpecificType.PRIMARY:
                return "PRIMARY";
            case ABAPQuerySpecificType.ROWS:
                return "ROWS";
            default:
                return "UNKNOWN(" + kind + ')';
        }
    }

}