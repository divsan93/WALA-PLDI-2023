package com.ibm.wala.cast.abap.types;
import com.ibm.wala.cast.tree.CAstType;
import com.ibm.wala.util.collections.HashMapFactory;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
public class AbapPrimitiveTypeMap {
    public static final Map<String, AbapPrimitiveType> primNameMap = HashMapFactory.make();

    public static class AbapPrimitiveType implements CAstType.Primitive {
        public String fLongName;

        public String fShortName;

        private AbapPrimitiveType(String longName, String shortName) {
            fLongName = longName;
            fShortName = shortName;
        }

        @Override
        public String getName() {
            return fShortName;
        }

        public String getLongName() {
            return fLongName;
        }

        @Override
        public Collection<CAstType> getSupertypes() {
            return Collections.emptyList();
        }
    }

    public static String getShortName(String longName) {
        return primNameMap.get(longName).getName();
    }

    public static AbapPrimitiveType lookupType(String longName) {
        return primNameMap.get(longName);
    }

    //public static final AbapPrimitiveType VoidType = new AbapPrimitiveType("void", "V");


    static {
        primNameMap.put("i", new AbapPrimitiveType("int4", "I"));
        primNameMap.put("int8", new AbapPrimitiveType("int8", "J"));
        primNameMap.put("f", new AbapPrimitiveType("float", "F"));
        primNameMap.put("p", new AbapPrimitiveType("packed", "P"));
        primNameMap.put("decfloat16", new AbapPrimitiveType("float16", "Z"));
        primNameMap.put("decfloat34", new AbapPrimitiveType("float34", "X"));
        primNameMap.put("c", new AbapPrimitiveType("char", "C"));
        primNameMap.put("d", new AbapPrimitiveType("date", "D"));
        primNameMap.put("n", new AbapPrimitiveType("number", "N"));
        primNameMap.put("t", new AbapPrimitiveType("time", "T"));
        primNameMap.put("x", new AbapPrimitiveType("hex", "H"));
        primNameMap.put("string", new AbapPrimitiveType("string", "S"));
        primNameMap.put("xstring", new AbapPrimitiveType("compressed", "O"));
        //primNameMap.put("void", VoidType);
    }
}

