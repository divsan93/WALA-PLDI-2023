package com.ibm.wala.cast.abap.translator;

import com.ibm.wala.classLoader.ModuleEntry;
import java.util.Set;

public interface SourceModuleTranslator {
    void loadAllSources(Set<ModuleEntry> modules);
}