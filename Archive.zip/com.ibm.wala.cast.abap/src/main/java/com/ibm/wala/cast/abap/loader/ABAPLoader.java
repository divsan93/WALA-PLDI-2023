package com.ibm.wala.cast.abap.loader;

import com.ibm.wala.analysis.typeInference.PrimitiveType;
import com.ibm.wala.cast.abap.translator.ABAPAstTranslator;
import com.ibm.wala.cast.abap.translator.ABAPTranslatorFactory;
import com.ibm.wala.cast.abap.translator.CAstABAPTranslator;
import com.ibm.wala.cast.abap.types.ABAPTypes;
import com.ibm.wala.cast.ir.translator.AstTranslator;
import com.ibm.wala.cast.ir.translator.TranslatorToCAst;
import com.ibm.wala.cast.ir.translator.TranslatorToIR;
import com.ibm.wala.cast.loader.AstMethod;
import com.ibm.wala.cast.loader.CAstAbstractModuleLoader;
import com.ibm.wala.cast.tree.CAst;
import com.ibm.wala.cast.tree.CAstEntity;
import com.ibm.wala.cast.tree.CAstQualifier;
import com.ibm.wala.cast.tree.CAstSourcePositionMap;
import com.ibm.wala.cast.tree.rewrite.CAstRewriterFactory;
import com.ibm.wala.cast.types.AstTypeReference;
import com.ibm.wala.cfg.AbstractCFG;
import com.ibm.wala.cfg.IBasicBlock;
import com.ibm.wala.classLoader.*;
import com.ibm.wala.core.util.strings.Atom;
import com.ibm.wala.ipa.callgraph.AnalysisOptions;
import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.IAnalysisCacheView;
import com.ibm.wala.ipa.callgraph.impl.AbstractRootMethod;
import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;
import com.ibm.wala.ipa.callgraph.propagation.PointerAnalysis;
import com.ibm.wala.ipa.callgraph.propagation.PointerKey;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ipa.modref.ExtendedHeapModel;
import com.ibm.wala.ipa.modref.ModRef;
import com.ibm.wala.shrike.shrikeCT.InvalidClassFileException;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.ssa.SSAInstructionFactory;
import com.ibm.wala.ssa.SymbolTable;
import com.ibm.wala.types.ClassLoaderReference;
import com.ibm.wala.types.MethodReference;
import com.ibm.wala.types.TypeName;
import com.ibm.wala.types.TypeReference;
import com.ibm.wala.util.collections.HashSetFactory;
import com.ibm.wala.util.collections.Pair;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ABAPLoader extends CAstAbstractModuleLoader {
    private final CAstABAPTranslator translatorFactory;

    private final CAstRewriterFactory<?, ?> preprocessor;

    public ABAPLoader(IClassHierarchy cha, CAstABAPTranslator translatorFactory) {
        this(cha, translatorFactory, null);
    }

    public ABAPLoader(
            IClassHierarchy cha,
            CAstABAPTranslator translatorFactory,
            CAstRewriterFactory<?, ?> preprocessor) {
        super(cha);
        this.translatorFactory = translatorFactory;
        this.preprocessor = preprocessor;
    }
    public static final Language ABAP =
            new LanguageImpl() {
                @Override
                public Atom getName() {
                    return Atom.findOrCreateUnicodeAtom("ABAP");
                }

                @Override
                public TypeReference getRootType() {
                    return ABAPTypes.Root;
                }

                @Override
                public TypeReference getThrowableType() {
                    return ABAPTypes.Root;
                }

                @Override
                public TypeReference getConstantType(Object o) {
                    if (o == null) {
                        return TypeReference.Null;
                    } else {
                        Class<?> c = o.getClass();
                        if (c == Boolean.class) {
                            return TypeReference.Boolean;
                        } else if (c == String.class) {
                            return TypeReference.Char;
                        } else if (c == Integer.class) {
                            return TypeReference.Int;
                        } else if (c == Float.class) {
                            return TypeReference.Float;
                        } else if (c == Double.class) {
                            return TypeReference.Double;
                        } else {
                            assert false : "cannot determine type for " + o + " of class " + c;
                            return null;
                        }
                    }
                }

                @Override
                public boolean isNullType(TypeReference type) {
                    return type.equals(ABAPTypes.Undefined) || type.equals(ABAPTypes.Null);
                }

                @Override
                public boolean isIntType(TypeReference t) {
                    return t == ABAPTypes.Integer;
                }

                @Override
                public boolean isLongType(TypeReference t) {
                    return false;
                }

                @Override
                public boolean isVoidType(TypeReference t) {
                    return false;
                }

                @Override
                public boolean isFloatType(TypeReference t) {
                    return t == ABAPTypes.Float;
                }

                @Override
                public boolean isDoubleType(TypeReference t) {
                    return false;
                }

                @Override
                public boolean isStringType(TypeReference t) {
                    return t == ABAPTypes.String;
                }

                @Override
                public boolean isMetadataType(TypeReference t) {
                    return false;
                }

                @Override
                public boolean isCharType(TypeReference t) {
                    return t == ABAPTypes.Char;
                }

                @Override
                public boolean isBooleanType(TypeReference t) {
                    return t == ABAPTypes.Boolean;
                }

                @Override
                public Object getMetadataToken(Object value) {
                    return null;
                }

                @Override
                public TypeReference[] getArrayInterfaces() {
                    return new TypeReference[0];
                }

                @Override
                public TypeName lookupPrimitiveType(String name) {
                    if ("B".equals(name)) {
                        return TypeReference.Boolean.getName();
                    } else if ("I".equals(name)) {
                        return TypeReference.Int.getName();
                    } else if ("J".equals(name)) {
                        return TypeReference.Int.getName();
                    } else if ("C".equals(name)) {
                        return TypeReference.Char.getName();
                    }
                    return null;
//                    } else if ("D".equals(name)) {
//                        return TypeReference.Date.getName();
//                    } else {
//                        assert "RegExp".equals(name);
//                        return TypeReference.RegExp.getName();
//                    }
                }

                @Override
                public SSAInstructionFactory instructionFactory() {
                    return null;
                }

                @Override
                public Collection<TypeReference> inferInvokeExceptions(MethodReference target, IClassHierarchy cha) throws InvalidClassFileException {
                    return null;
                }

                @Override
                public TypeReference getStringType() {
                    return ABAPTypes.String;
                }

                @Override
                public TypeReference getPointerType(TypeReference pointee) throws UnsupportedOperationException {
                    throw new UnsupportedOperationException("ABAP does not permit explicit pointers");
                }

                @Override
                public PrimitiveType getPrimitive(TypeReference reference) {
                    return PrimitiveType.getPrimitive(reference);
                }

                @Override
                public boolean methodsHaveDeclaredParameterTypes() {
                    return false;
                }

                @Override
                public AbstractRootMethod getFakeRootMethod(IClassHierarchy cha, AnalysisOptions options, IAnalysisCacheView cache) {
                    return null;
                }

                @Override
                public <T extends InstanceKey> ModRef.RefVisitor<T, ? extends ExtendedHeapModel> makeRefVisitor(CGNode n, Collection<PointerKey> result, PointerAnalysis<T> pa, ExtendedHeapModel h) {
                    return null;
                }

                @Override
                public <T extends InstanceKey> ModRef.ModVisitor<T, ? extends ExtendedHeapModel> makeModVisitor(CGNode n, Collection<PointerKey> result, PointerAnalysis<T> pa, ExtendedHeapModel h, boolean ignoreAllocHeapDefs) {
                    return null;
                }
            };
    @Override
    protected TranslatorToCAst getTranslatorToCAst(CAst ast, ModuleEntry M, List<Module> modules) throws IOException {
        TranslatorToCAst translator = translatorFactory.make(ast, M);
        if (preprocessor != null) translator.addRewriter(preprocessor, true);
        return translator;
    }

    @Override
    protected boolean shouldTranslate(CAstEntity entity) {
        return true;
    }

    @Override
    protected TranslatorToIR initTranslator(Set<Pair<CAstEntity, ModuleEntry>> topLevelEntities) {
        return new ABAPAstTranslator(this);
    }

    @Override
    public ClassLoaderReference getReference() {
        return ABAPTypes.abLoader;
    }

    @Override
    public Language getLanguage() {
        return ABAP;
    }

    @Override
    public SSAInstructionFactory getInstructionFactory() {
        return Language.JAVA.instructionFactory();
    }

    public IClass makeCodeBodyType(
            String name,
            TypeReference P,
            CAstSourcePositionMap.Position sourcePosition,
            CAstEntity entity,
            AstTranslator.WalkContext context) {
        return new DynamicCodeBody(
                TypeReference.findOrCreate(ABAPTypes.abLoader, TypeName.string2TypeName(name)),
                P,
                this,
                sourcePosition,
                entity,
                context);
    }

    public IClass defineFunctionType(
            String name, CAstSourcePositionMap.Position pos, CAstEntity entity, AstTranslator.WalkContext context) {
        return makeCodeBodyType(name, ABAPTypes.Function, pos, entity, context);
    }

    public IClass defineScriptType(
            String name, CAstSourcePositionMap.Position pos, CAstEntity entity, AstTranslator.WalkContext context) {
        return makeCodeBodyType(name, ABAPTypes.Script, pos, entity, context);
    }

    public IMethod defineCodeBodyCode(
            String clsName,
            AbstractCFG<?, ?> cfg,
            SymbolTable symtab,
            boolean hasCatchBlock,
            Map<IBasicBlock<SSAInstruction>, TypeReference[]> caughtTypes,
            boolean hasMonitorOp,
            AstTranslator.AstLexicalInformation lexicalInfo,
            AstMethod.DebuggingInformation debugInfo) {
        DynamicCodeBody C = (DynamicCodeBody) lookupClass(clsName, cha);
        assert C != null : clsName;
        return C.setCodeBody(
                makeCodeBodyCode(
                        cfg, symtab, hasCatchBlock, caughtTypes, hasMonitorOp, lexicalInfo, debugInfo, C));
    }

    //WHY are we adding this?
    private static final Set<CAstQualifier> functionQualifiers;

    static {
        functionQualifiers = HashSetFactory.make();
        functionQualifiers.add(CAstQualifier.PUBLIC);
        functionQualifiers.add(CAstQualifier.FINAL);
    }
    public DynamicMethodObject makeCodeBodyCode(
            AbstractCFG<?, ?> cfg,
            SymbolTable symtab,
            boolean hasCatchBlock,
            Map<IBasicBlock<SSAInstruction>, TypeReference[]> caughtTypes,
            boolean hasMonitorOp,
            AstTranslator.AstLexicalInformation lexicalInfo,
            AstMethod.DebuggingInformation debugInfo,
            IClass C) {
        return new DynamicMethodObject(
                C,
                functionQualifiers,
                cfg,
                symtab,
                hasCatchBlock,
                caughtTypes,
                hasMonitorOp,
                lexicalInfo,
                debugInfo);
    }
    final CoreClass ROOT = new CoreClass(ABAPTypes.Root.getName(), null, this, null);
    final CoreClass SCRIPT = new CoreClass(ABAPTypes.Script.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass PRIMITIVES =
            new CoreClass(
                    ABAPTypes.Primitives.getName(), ABAPTypes.Root.getName(), this, null);


    final CoreClass STRING =
            new CoreClass(ABAPTypes.String.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass NULL =
            new CoreClass(ABAPTypes.Null.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass INTEGER =
            new CoreClass(ABAPTypes.Integer.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass NUMBER =
            new CoreClass(ABAPTypes.Number.getName(), ABAPTypes.Root.getName(), this, null);


    final CoreClass NUMBER_OBJECT =
            new CoreClass(
                    ABAPTypes.NumberObject.getName(), ABAPTypes.Root.getName(), this, null);


    final CoreClass STRING_OBJECT =
            new CoreClass(
                    ABAPTypes.StringObject.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass BOOLEAN =
            new CoreClass(ABAPTypes.Boolean.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass SQL =
            new CoreClass(ABAPTypes.DataLoader.getName(), ABAPTypes.Root.getName(), this, null);

    final CoreClass PRINT =
            new CoreClass(ABAPTypes.Print.getName(), ABAPTypes.Root.getName(), this, null);
}
