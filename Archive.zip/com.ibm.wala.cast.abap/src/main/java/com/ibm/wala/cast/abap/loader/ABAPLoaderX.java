//package com.ibm.wala.cast.abap.loader;
//
//import com.ibm.wala.cast.abap.translator.ABAPAstTranslator;
//import com.ibm.wala.cast.abap.translator.ABAPTranslatorFactory;
//import com.ibm.wala.cast.abap.types.ABAPTypes;
//import com.ibm.wala.cast.ir.translator.AstTranslator;
//import com.ibm.wala.cast.ir.translator.TranslatorToCAst;
//import com.ibm.wala.cast.ir.translator.TranslatorToIR;
//import com.ibm.wala.cast.loader.AstMethod;
//import com.ibm.wala.cast.loader.CAstAbstractModuleLoader;
//import com.ibm.wala.cast.tree.CAst;
//import com.ibm.wala.cast.tree.CAstEntity;
//import com.ibm.wala.cast.tree.CAstQualifier;
//import com.ibm.wala.cast.tree.CAstSourcePositionMap;
//import com.ibm.wala.cast.tree.rewrite.CAstRewriterFactory;
//import com.ibm.wala.cfg.AbstractCFG;
//import com.ibm.wala.cfg.IBasicBlock;
//import com.ibm.wala.classLoader.*;
//import com.ibm.wala.ipa.cha.IClassHierarchy;
//import com.ibm.wala.ssa.SSAInstruction;
//import com.ibm.wala.ssa.SSAInstructionFactory;
//import com.ibm.wala.ssa.SymbolTable;
//import com.ibm.wala.types.ClassLoaderReference;
//import com.ibm.wala.types.TypeName;
//import com.ibm.wala.types.TypeReference;
//import com.ibm.wala.util.collections.HashSetFactory;
//import com.ibm.wala.util.collections.Pair;
//import com.ibm.wala.cast.abap.types.AbapPrimitiveTypeMap.*;
//
//import java.io.IOException;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//public class ABAPLoaderX extends CAstAbstractModuleLoader {
//
////    public static final Language ABAP =
////            new LanguageImpl() {
////
////                {
////                    AbapPrimitiveType.init();
////                }
//    private final ABAPTranslatorFactory translatorFactory;
//
//    private final CAstRewriterFactory<?, ?> preprocessor;
//
//    public ABAPLoader(IClassHierarchy cha, ABAPTranslatorFactory translatorFactory) {
//        this(cha, translatorFactory, null);
//    }
//    public ABAPLoader(
//            IClassHierarchy cha,
//            ABAPTranslatorFactory translatorFactory,
//            CAstRewriterFactory<?, ?> preprocessor) {
//        super(cha);
//        this.translatorFactory = translatorFactory;
//        this.preprocessor = preprocessor;
//    }
//    public IMethod defineCodeBodyCode(
//            String clsName,
//            AbstractCFG<?, ?> cfg,
//            SymbolTable symtab,
//            boolean hasCatchBlock,
//            Map<IBasicBlock<SSAInstruction>, TypeReference[]> caughtTypes,
//            boolean hasMonitorOp,
//            AstTranslator.AstLexicalInformation lexicalInfo,
//            AstMethod.DebuggingInformation debugInfo) {
//        DynamicCodeBody C = (DynamicCodeBody) lookupClass(clsName, cha);
//        assert C != null : clsName;
//        return C.setCodeBody(
//                makeCodeBodyCode(
//                        cfg, symtab, hasCatchBlock, caughtTypes, hasMonitorOp, lexicalInfo, debugInfo, C));
//    }
//    private static final Set<CAstQualifier> functionQualifiers;
//    //TODO: No idea what am I doing.
//    static {
//        functionQualifiers = HashSetFactory.make();
//        functionQualifiers.add(CAstQualifier.PUBLIC);
//        functionQualifiers.add(CAstQualifier.FINAL);
//    }
//
//    public DynamicMethodObject makeCodeBodyCode(
//            AbstractCFG<?, ?> cfg,
//            SymbolTable symtab,
//            boolean hasCatchBlock,
//            Map<IBasicBlock<SSAInstruction>, TypeReference[]> caughtTypes,
//            boolean hasMonitorOp,
//            AstTranslator.AstLexicalInformation lexicalInfo,
//            AstMethod.DebuggingInformation debugInfo,
//            IClass C) {
//        return new DynamicMethodObject(
//                C,
//                functionQualifiers,
//                cfg,
//                symtab,
//                hasCatchBlock,
//                caughtTypes,
//                hasMonitorOp,
//                lexicalInfo,
//                debugInfo);
//    }
//
//    public IClass defineScriptType(
//            String name, CAstSourcePositionMap.Position pos, CAstEntity entity, AstTranslator.WalkContext context) {
//        return makeCodeBodyType(name, ABAPTypes.Script, pos, entity, context);
//    }
//    public IClass makeCodeBodyType(
//            String name,
//            TypeReference P,
//            CAstSourcePositionMap.Position sourcePosition,
//            CAstEntity entity,
//            AstTranslator.WalkContext context) {
//        return new DynamicCodeBody(
//                TypeReference.findOrCreate(ABAPTypes.abLoader, TypeName.string2TypeName(name)),
//                P,
//                this,
//                sourcePosition,
//                entity,
//                context);
//    }
//    @Override
//    protected TranslatorToCAst getTranslatorToCAst(CAst ast, ModuleEntry M, List<Module> modules) throws IOException {
//        TranslatorToCAst translator = translatorFactory.make(ast, M);
//        if (preprocessor != null) translator.addRewriter(preprocessor, true);
//        return translator;
//    }
//
//    @Override
//    protected boolean shouldTranslate(CAstEntity entity) {
//        return false;
//    }
//
//    @Override
//    protected TranslatorToIR initTranslator(Set<Pair<CAstEntity, ModuleEntry>> topLevelEntities) {
//        return new ABAPAstTranslator(this);
//    }
//
//    @Override
//    public ClassLoaderReference getReference() {
//        return null;
//    }
//
//    @Override
//    public Language getLanguage() {
//        return null;
//    }
//
//    @Override
//    public SSAInstructionFactory getInstructionFactory() {
//        return null;
//    }
//}
