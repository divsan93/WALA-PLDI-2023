package com.ibm.wala.cast.abap.translator;

import com.ibm.wala.cast.abap.types.AbapPrimitiveTypeMap;
import com.ibm.wala.cast.tree.CAstSymbol;
import com.ibm.wala.cast.tree.CAstType;

public class ABAPCastutils {
    public static Object defaultValueForType(CAstType type) {
        if(type==null)
        {
            return CAstSymbol.NULL_DEFAULT_VALUE;
        }
        else {
            if (isLongOrLess(type)) return 0;
            else if (type.getName().equals("D") || type.getName().equals("F") || type.getName().equals("Z") || type.getName().equals("X"))
                return 0.0;
            else
                return CAstSymbol.NULL_DEFAULT_VALUE;
        }
    }
    public static boolean isLongOrLess(CAstType type) {
        String t = type.getName();
        return t.equals("P") || t.equals("I") || t.equals("J");
    }
}
