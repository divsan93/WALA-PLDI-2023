package com.ibm.wala.cast.abap.types;
import com.ibm.wala.cast.tree.CAstType;
public interface AbapType extends CAstType.Class {
    @Override
    boolean isInterface();
}
