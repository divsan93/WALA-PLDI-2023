package com.ibm.wala.cast.abap.loader;

import com.ibm.wala.classLoader.Module;
import com.ibm.wala.classLoader.ModuleEntry;
import com.ibm.wala.util.debug.Assertions;
import org.antlr.v4.runtime.ANTLRFileStream;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;

public class FileEntry implements ModuleEntry {
    String filename;

    public FileEntry(String filename){this.filename=filename;}
    @Override
    public String getName() {
        return filename;
    }

    @Override
    public boolean isClassFile() {
        return false;
    }

    @Override
    public boolean isSourceFile() {
        return true;
    }

    @Override
    public InputStream getInputStream() {
        try {
            return new FileInputStream(new File(filename));
        } catch (IOException e) {
            assert false : e;
            return null;
        }
    }

    @Override
    public boolean isModuleFile() {
        return false;
    }

    @Override
    public Module asModule() {
        return null;
    }

    @Override
    public String getClassName() {
        return null;
    }

    @Override
    public Module getContainer() {
        return null;
    }
}
