package com.ibm.wala.cast.abap.analysis.typeinference;

import com.ibm.wala.analysis.typeInference.PointType;
import com.ibm.wala.analysis.typeInference.TypeAbstraction;
import com.ibm.wala.cast.abap.types.ABAPTypes;
import com.ibm.wala.cast.analysis.typeInference.AstTypeInference;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SymbolTable;

public class ABAPTypeInference extends AstTypeInference {
    public ABAPTypeInference(IR ir, TypeAbstraction booleanType, boolean doPrimitives) {
        super(ir, booleanType, doPrimitives);
    }
    public ABAPTypeInference(IR ir, IClassHierarchy cha) {
        super(ir, new PointType(cha.lookupClass(ABAPTypes.Boolean)), true);
    }
    @Override
    public TypeAbstraction getConstantType(int valueNumber) {
        SymbolTable st = ir.getSymbolTable();
        if (st.isStringConstant(valueNumber)) {
            return new PointType(cha.lookupClass(ABAPTypes.String));
        } else if (st.isBooleanConstant(valueNumber)) {
            return new PointType(cha.lookupClass(ABAPTypes.Boolean));
        } else if (st.isNullConstant(valueNumber)) {
            return new PointType(cha.lookupClass(ABAPTypes.Null));
        } else {
            return new PointType(cha.lookupClass(ABAPTypes.Number));
        }
    }
}
