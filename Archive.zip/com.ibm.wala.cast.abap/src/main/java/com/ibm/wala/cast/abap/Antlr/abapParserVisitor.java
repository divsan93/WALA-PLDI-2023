// Generated from abapParser.g4 by ANTLR 4.5.3
package com.ibm.wala.cast.abap.Antlr;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link abapParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface abapParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link abapParser#number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(abapParser.NumberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_number(abapParser.Use1_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_number(abapParser.Def_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_number(abapParser.Usedef_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_symbol}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_symbol(abapParser.Field_symbolContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#identifier_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier_lex(abapParser.Identifier_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_identifier(abapParser.Use1_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_identifier(abapParser.Def_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_identifier(abapParser.Usedef_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#macro_symbol_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMacro_symbol_lex(abapParser.Macro_symbol_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sarrow_identifier_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSarrow_identifier_lex(abapParser.Sarrow_identifier_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sarrow_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSarrow_identifier(abapParser.Sarrow_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(abapParser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#udvar_keyword_as_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUdvar_keyword_as_identifier(abapParser.Udvar_keyword_as_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#keyword_as_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyword_as_identifier(abapParser.Keyword_as_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#end_of_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnd_of_statement(abapParser.End_of_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(abapParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#single_line_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingle_line_stmt(abapParser.Single_line_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#modified_single_line_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModified_single_line_stmt(abapParser.Modified_single_line_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#forms}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForms(abapParser.FormsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#program_or_report_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram_or_report_option(abapParser.Program_or_report_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#program_or_report_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram_or_report_definition(abapParser.Program_or_report_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#module_form_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModule_form_line(abapParser.Module_form_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endmodule_form_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndmodule_form_line(abapParser.Endmodule_form_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#module_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModule_form(abapParser.Module_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#event_header}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvent_header(abapParser.Event_headerContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#event_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvent_form(abapParser.Event_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#at_event}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAt_event(abapParser.At_eventContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#at_screen_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAt_screen_option(abapParser.At_screen_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#initialization_event}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInitialization_event(abapParser.Initialization_eventContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#start_of_selection_event}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart_of_selection_event(abapParser.Start_of_selection_eventContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#top_level_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTop_level_form(abapParser.Top_level_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#statement_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement_form(abapParser.Statement_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#start_statement_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart_statement_form(abapParser.Start_statement_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_clause(abapParser.Provide_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_from_clause(abapParser.Provide_from_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_into_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_into_clause(abapParser.Provide_into_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_valid_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_valid_clause(abapParser.Provide_valid_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_bounds_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_bounds_clause(abapParser.Provide_bounds_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_between_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_between_clause(abapParser.Provide_between_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_where_clause(abapParser.Provide_where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_fields}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_fields(abapParser.Provide_fieldsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#provide_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProvide_statement(abapParser.Provide_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#reject_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReject_statement(abapParser.Reject_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#nodes_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNodes_statement(abapParser.Nodes_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#macro_hrabap_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMacro_hrabap_statement(abapParser.Macro_hrabap_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#return_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturn_statement(abapParser.Return_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#krntrc_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKrntrc_statement(abapParser.Krntrc_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#dynpro_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDynpro_statement(abapParser.Dynpro_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assert_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssert_statement(abapParser.Assert_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#throw_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitThrow_statement(abapParser.Throw_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#catch_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCatch_clause(abapParser.Catch_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#try_statement_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTry_statement_line(abapParser.Try_statement_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endtry_statement_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndtry_statement_line(abapParser.Endtry_statement_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#try_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTry_statement(abapParser.Try_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sum_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSum_statement(abapParser.Sum_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#end_of_selection_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnd_of_selection_statement(abapParser.End_of_selection_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#load_of_program_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoad_of_program_statement(abapParser.Load_of_program_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#overlay_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOverlay_statement(abapParser.Overlay_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#position_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPosition_statement(abapParser.Position_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#generate_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenerate_option(abapParser.Generate_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_generate_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_generate_option(abapParser.Use1_generate_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#generate_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenerate_statement(abapParser.Generate_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#end_page_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnd_page_statement(abapParser.End_page_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#new_line_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew_line_statement(abapParser.New_line_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#new_page_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew_page_option(abapParser.New_page_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#new_page_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew_page_statement(abapParser.New_page_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#top_of_page_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTop_of_page_statement(abapParser.Top_of_page_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_options_modifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_options_modifier(abapParser.Select_options_modifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_options_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_options_clause(abapParser.Select_options_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_options_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_options_statement(abapParser.Select_options_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#authority_check_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAuthority_check_statement(abapParser.Authority_check_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_statement_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_statement_option(abapParser.Field_statement_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_statement(abapParser.Field_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#expression_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression_statement(abapParser.Expression_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#controls_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControls_clause(abapParser.Controls_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#controls_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControls_statement(abapParser.Controls_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#type_pool_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_pool_declaration(abapParser.Type_pool_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#type_pools_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_pools_declaration(abapParser.Type_pools_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_pool_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_pool_declaration(abapParser.Function_pool_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#include_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInclude_statement(abapParser.Include_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#scan_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScan_option(abapParser.Scan_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#scan_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScan_statement(abapParser.Scan_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#exit_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExit_statement(abapParser.Exit_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#stop_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStop_statement(abapParser.Stop_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assign_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign_clause(abapParser.Assign_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assign_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign_statement(abapParser.Assign_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#concatenate_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcatenate_tail(abapParser.Concatenate_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#concatenate_exprs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcatenate_exprs(abapParser.Concatenate_exprsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#concatenate_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcatenate_statement(abapParser.Concatenate_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#at_block_form_udvar_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAt_block_form_udvar_identifier(abapParser.At_block_form_udvar_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#at_block_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAt_block_form(abapParser.At_block_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#at_form_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAt_form_line(abapParser.At_form_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endat_form_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndat_form_line(abapParser.Endat_form_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#at_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAt_form(abapParser.At_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#chain_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChain_definition_line(abapParser.Chain_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endchain_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndchain_definition_line(abapParser.Endchain_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#chain_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChain_definition(abapParser.Chain_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_definition_line(abapParser.Function_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endfunction_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndfunction_definition_line(abapParser.Endfunction_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_definition(abapParser.Function_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#method_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod_definition_line(abapParser.Method_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endmethod_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndmethod_definition_line(abapParser.Endmethod_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#method_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod_definition(abapParser.Method_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_method_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_method_definition(abapParser.Use1_method_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitName(abapParser.NameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#define_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefine_definition_line(abapParser.Define_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#enddefine_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnddefine_definition_line(abapParser.Enddefine_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#define_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefine_definition(abapParser.Define_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#module_statement_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModule_statement_option(abapParser.Module_statement_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#module_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModule_statement(abapParser.Module_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#class_definition_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_definition_options(abapParser.Class_definition_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#class_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_definition_line(abapParser.Class_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endclass_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndclass_definition_line(abapParser.Endclass_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#class_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_definition(abapParser.Class_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#interfaces_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInterfaces_decl(abapParser.Interfaces_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#section_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSection_decl(abapParser.Section_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#class_method_decls}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_method_decls(abapParser.Class_method_declsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#method_decls}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod_decls(abapParser.Method_declsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#default_rule}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefault_rule(abapParser.Default_ruleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#superclass}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSuperclass(abapParser.SuperclassContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#event}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvent(abapParser.EventContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#first}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFirst(abapParser.FirstContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#last}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLast(abapParser.LastContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_last}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_last(abapParser.Use1_lastContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#work_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWork_area(abapParser.Work_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#control}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControl(abapParser.ControlContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#cursor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor(abapParser.CursorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#method_decl_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod_decl_options(abapParser.Method_decl_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#method_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod_decl(abapParser.Method_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#table_decl_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_decl_clause(abapParser.Table_decl_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#table_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable_declaration(abapParser.Table_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#include_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInclude_decl(abapParser.Include_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#type_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_clause(abapParser.Type_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#type_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_declaration(abapParser.Type_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#constant_decl_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstant_decl_clause(abapParser.Constant_decl_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#constant_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstant_declaration(abapParser.Constant_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#decl_type_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl_type_clause(abapParser.Decl_type_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#decl_option_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl_option_clause(abapParser.Decl_option_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#part_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPart_decl(abapParser.Part_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#occurs_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOccurs_clause(abapParser.Occurs_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#valid_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValid_clause(abapParser.Valid_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#data_decl_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitData_decl_clause(abapParser.Data_decl_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#data_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitData_declaration(abapParser.Data_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#data_common_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitData_common_declaration(abapParser.Data_common_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#statics_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatics_declaration(abapParser.Statics_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#ranges_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRanges_clause(abapParser.Ranges_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#ranges_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRanges_declaration(abapParser.Ranges_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#decimal_places}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecimal_places(abapParser.Decimal_placesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_decimal_places}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_decimal_places(abapParser.Use1_decimal_placesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#record}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecord(abapParser.RecordContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#r_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR_type(abapParser.R_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#clazz}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClazz(abapParser.ClazzContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#itab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitItab(abapParser.ItabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_itab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_itab(abapParser.Use1_itabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_itab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_itab(abapParser.Def_itabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_itab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_itab(abapParser.Usedef_itabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField(abapParser.FieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_field(abapParser.Use1_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_field(abapParser.Def_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_field(abapParser.Usedef_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter(abapParser.ParameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_parameter(abapParser.Use1_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_parameter(abapParser.Def_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_parameter(abapParser.Usedef_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#template}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTemplate(abapParser.TemplateContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue(abapParser.ValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#tabkind}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTabkind(abapParser.TabkindContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#size}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSize(abapParser.SizeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#itabtype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitItabtype(abapParser.ItabtypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#linetype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLinetype(abapParser.LinetypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#lineobj}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLineobj(abapParser.LineobjContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRef(abapParser.RefContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKey(abapParser.KeyContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_key(abapParser.Usedef_keyContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#dest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDest(abapParser.DestContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#dialog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDialog(abapParser.DialogContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_dialog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_dialog(abapParser.Use1_dialogContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#dialogfield_x}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDialogfield_x(abapParser.Dialogfield_xContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_dialogfield_x}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_dialogfield_x(abapParser.Use1_dialogfield_xContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_dialogfield_x}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_dialogfield_x(abapParser.Def_dialogfield_xContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#excep_tab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExcep_tab(abapParser.Excep_tabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_excep_tab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_excep_tab(abapParser.Use1_excep_tabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#exception}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitException(abapParser.ExceptionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction(abapParser.FunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_function(abapParser.Use1_functionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#method}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod(abapParser.MethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_method}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_method(abapParser.Use1_methodContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#r_object}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR_object(abapParser.R_objectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_object}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_object(abapParser.Use1_objectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#param_tab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParam_tab(abapParser.Param_tabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_param_tab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_param_tab(abapParser.Use1_param_tabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#program_field_x}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram_field_x(abapParser.Program_field_xContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_program_field_x}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_program_field_x(abapParser.Use1_program_field_xContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_program_field_x}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_program_field_x(abapParser.Def_program_field_xContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#screen}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScreen(abapParser.ScreenContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#subroutine}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubroutine(abapParser.SubroutineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#task_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTask_name(abapParser.Task_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_task_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_task_name(abapParser.Def_task_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#group_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_name(abapParser.Group_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_group_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_group_name(abapParser.Def_group_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#typing_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTyping_decl(abapParser.Typing_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#form_parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForm_parameter(abapParser.Form_parameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#form_parameter_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForm_parameter_clause(abapParser.Form_parameter_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_form_parameter_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_form_parameter_clause(abapParser.Use1_form_parameter_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_form_parameter_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_form_parameter_clause(abapParser.Def_form_parameter_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_form_parameter_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_form_parameter_clause(abapParser.Usedef_form_parameter_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#form_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForm_clauses(abapParser.Form_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#using_form_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsing_form_clauses(abapParser.Using_form_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#changing_form_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChanging_form_clauses(abapParser.Changing_form_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#tables_form_clauses}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTables_form_clauses(abapParser.Tables_form_clausesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_form_parameter_clause1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_form_parameter_clause1(abapParser.Use1_form_parameter_clause1Context ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_form_parameter_clause1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_form_parameter_clause1(abapParser.Usedef_form_parameter_clause1Context ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#form_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForm_definition_line(abapParser.Form_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endform_definition_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndform_definition_line(abapParser.Endform_definition_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#form_definition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForm_definition(abapParser.Form_definitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#condense_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondense_statement(abapParser.Condense_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#message_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMessage_clause(abapParser.Message_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#message_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMessage_statement(abapParser.Message_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#raise_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRaise_statement(abapParser.Raise_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#elseif_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseif_clause(abapParser.Elseif_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#else_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElse_clause(abapParser.Else_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#then_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitThen_clause(abapParser.Then_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#if_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf_stmt_line(abapParser.If_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endif_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndif_stmt_line(abapParser.Endif_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#if_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf_statement(abapParser.If_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#break_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreak_statement(abapParser.Break_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#distance}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDistance(abapParser.DistanceContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_start(abapParser.Use1_startContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart(abapParser.StartContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#do_times_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDo_times_clause(abapParser.Do_times_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#do_varying_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDo_varying_clause(abapParser.Do_varying_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#do_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDo_stmt_line(abapParser.Do_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#enddo_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnddo_stmt_line(abapParser.Enddo_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#do_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDo_statement(abapParser.Do_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#append_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAppend_stmt(abapParser.Append_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#parameter_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter_value(abapParser.Parameter_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_parameter_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_parameter_value(abapParser.Use1_parameter_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_parameter_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_parameter_value(abapParser.Def_parameter_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#parameter_equals_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter_equals_clause(abapParser.Parameter_equals_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_parameter_equals_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_parameter_equals_clause(abapParser.Use1_parameter_equals_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_parameter_equals_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_parameter_equals_clause(abapParser.Def_parameter_equals_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_parameter_equals_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_parameter_equals_clause(abapParser.Usedef_parameter_equals_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_exporting_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_exporting_clause(abapParser.Function_exporting_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_function_exporting_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_function_exporting_clause(abapParser.Usedef_function_exporting_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_importing_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_importing_clause(abapParser.Function_importing_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_tables_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_tables_clause(abapParser.Function_tables_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_changing_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_changing_clause(abapParser.Function_changing_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_receiving_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_receiving_clause(abapParser.Function_receiving_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_parameter_table_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_parameter_table_clause(abapParser.Function_parameter_table_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_exception_table_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_exception_table_clause(abapParser.Function_exception_table_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_destination_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_destination_clause(abapParser.Function_destination_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_performing_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_performing_clause(abapParser.Function_performing_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_subroutine}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_subroutine(abapParser.Use1_subroutineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_exceptions_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_exceptions_clause(abapParser.Function_exceptions_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_others_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_others_clause(abapParser.Function_others_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_error_message_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_error_message_clause(abapParser.Function_error_message_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_message_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_message_clause(abapParser.Function_message_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_call_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_call_clause(abapParser.Function_call_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_call_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_call_option(abapParser.Function_call_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#transformation_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransformation_part(abapParser.Transformation_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_transformation_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_transformation_part(abapParser.Use1_transformation_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_transformation_part}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_transformation_part(abapParser.Def_transformation_partContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#call_transaction_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCall_transaction_option(abapParser.Call_transaction_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_sarrow_object}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_sarrow_object(abapParser.Use1_sarrow_objectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sarrow_object}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSarrow_object(abapParser.Sarrow_objectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_sarrow_method}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_sarrow_method(abapParser.Use1_sarrow_methodContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sarrow_method}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSarrow_method(abapParser.Sarrow_methodContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#call_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCall_statement(abapParser.Call_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#clear_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClear_clause(abapParser.Clear_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_clear_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_clear_clause(abapParser.Def_clear_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#clear_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClear_stmt(abapParser.Clear_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#local_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocal_clause(abapParser.Local_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#local_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLocal_statement(abapParser.Local_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_screen}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_screen(abapParser.Use1_screenContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_LITERAL_ID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_LITERAL_ID(abapParser.Def_LITERAL_IDContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_decl_type_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_decl_type_clause(abapParser.Use1_decl_type_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_size}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_size(abapParser.Use1_sizeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_local_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_local_clause(abapParser.Use1_local_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#compute_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompute_stmt(abapParser.Compute_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#create_object_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_object_clause(abapParser.Create_object_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#create_data_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_data_clause(abapParser.Create_data_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#create_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCreate_stmt(abapParser.Create_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#describe_field_modifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDescribe_field_modifier(abapParser.Describe_field_modifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#describe_field_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDescribe_field_clause(abapParser.Describe_field_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#describe_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDescribe_stmt(abapParser.Describe_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_cursor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_cursor(abapParser.Use1_cursorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_work_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_work_area(abapParser.Def_work_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_control}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_control(abapParser.Use1_controlContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_FIELD_SYMBOL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_FIELD_SYMBOL(abapParser.Use1_FIELD_SYMBOLContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#loop_at_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoop_at_clause(abapParser.Loop_at_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_arrow_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_arrow_expression(abapParser.Use1_arrow_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#loop_header}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoop_header(abapParser.Loop_headerContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#loop_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoop_stmt_line(abapParser.Loop_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endloop_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndloop_stmt_line(abapParser.Endloop_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#loop_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoop_stmt(abapParser.Loop_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#move_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMove_stmt(abapParser.Move_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#move_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMove_clause(abapParser.Move_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_FIELD_SYMBOL_OR_def_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_FIELD_SYMBOL_OR_def_identifier(abapParser.Def_FIELD_SYMBOL_OR_def_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#perform_id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerform_id(abapParser.Perform_idContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulti_perform_options(abapParser.Multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_binary_expression1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_binary_expression1(abapParser.Use1_binary_expression1Context ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_binary_expression1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_binary_expression1(abapParser.Usedef_binary_expression1Context ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#tables_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTables_multi_perform_options(abapParser.Tables_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#using_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsing_multi_perform_options(abapParser.Using_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#changing_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChanging_multi_perform_options(abapParser.Changing_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#if_found_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf_found_multi_perform_options(abapParser.If_found_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#colon_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColon_multi_perform_options(abapParser.Colon_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#comma_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComma_multi_perform_options(abapParser.Comma_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#binary_expression_multi_perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinary_expression_multi_perform_options(abapParser.Binary_expression_multi_perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_LID_number_assignmentLHS}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_LID_number_assignmentLHS(abapParser.Use1_LID_number_assignmentLHSContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_LID_number_assignmentLHS}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_LID_number_assignmentLHS(abapParser.Usedef_LID_number_assignmentLHSContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_LID_number_assignmentLHS}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_LID_number_assignmentLHS(abapParser.Def_LID_number_assignmentLHSContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#perform_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerform_options(abapParser.Perform_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#perform_options_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerform_options_clause(abapParser.Perform_options_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#multi_perform_options_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulti_perform_options_clause(abapParser.Multi_perform_options_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#perform_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerform_clause(abapParser.Perform_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#perform_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerform_line(abapParser.Perform_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#perform_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPerform_stmt(abapParser.Perform_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#refresh_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRefresh_stmt(abapParser.Refresh_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#r_format}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR_format(abapParser.R_formatContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#function_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction_code(abapParser.Function_codeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#selection_screen_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelection_screen_option(abapParser.Selection_screen_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#num_id_with_paren}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_id_with_paren(abapParser.Num_id_with_parenContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#selection_parameters_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelection_parameters_clause(abapParser.Selection_parameters_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#selection_form_use1_identifier_or_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelection_form_use1_identifier_or_number(abapParser.Selection_form_use1_identifier_or_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#selection_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelection_form(abapParser.Selection_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#skip_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSkip_stmt(abapParser.Skip_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#line_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLine_number(abapParser.Line_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_line_number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_line_number(abapParser.Use1_line_numberContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_index_rule}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_index_rule(abapParser.Use1_index_ruleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#index_rule}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex_rule(abapParser.Index_ruleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#source}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSource(abapParser.SourceContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#target}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTarget(abapParser.TargetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#language}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLanguage(abapParser.LanguageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#length}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLength(abapParser.LengthContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_filename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_filename(abapParser.Usedef_filenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#filename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilename(abapParser.FilenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#page}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPage(abapParser.PageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#r_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR_list(abapParser.R_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#fieldlist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFieldlist(abapParser.FieldlistContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_expression(abapParser.Read_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_option_s}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_option_s(abapParser.Read_option_sContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_clause(abapParser.Read_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_read_table_options_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_read_table_options_tail(abapParser.Def_read_table_options_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_read_table_options_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_read_table_options_tail(abapParser.Use1_read_table_options_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_key(abapParser.Use1_keyContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_record}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_record(abapParser.Use1_recordContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_record}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_record(abapParser.Usedef_recordContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_record}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_record(abapParser.Def_recordContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_FIELD_SYMBOL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_FIELD_SYMBOL(abapParser.Def_FIELD_SYMBOLContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_table_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_table_options(abapParser.Read_table_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_dataset_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_dataset_option(abapParser.Read_dataset_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_line_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_line_options(abapParser.Read_line_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#read_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead_statement(abapParser.Read_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_readtable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_readtable(abapParser.Use1_readtableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#readtable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReadtable(abapParser.ReadtableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_table(abapParser.Usedef_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTable(abapParser.TableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_area(abapParser.Usedef_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArea(abapParser.AreaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_field_with_tablename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_field_with_tablename(abapParser.Use_field_with_tablenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_field_with_tablename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_field_with_tablename(abapParser.Use1_field_with_tablenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_with_tablename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_with_tablename(abapParser.Field_with_tablenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_field_with_fieldname}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_field_with_fieldname(abapParser.Use_field_with_fieldnameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_field_with_fieldname}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_field_with_fieldname(abapParser.Use1_field_with_fieldnameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_table(abapParser.Use1_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_with_fieldname}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_with_fieldname(abapParser.Field_with_fieldnameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_FIELD_SYMBOL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_FIELD_SYMBOL(abapParser.Use_FIELD_SYMBOLContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#delete_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelete_statement(abapParser.Delete_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#client}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClient(abapParser.ClientContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_client}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_client(abapParser.Use1_clientContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#export_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExport_tail(abapParser.Export_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_area(abapParser.Def_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_table(abapParser.Def_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#export_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExport_to(abapParser.Export_toContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#export_from}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExport_from(abapParser.Export_fromContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#export_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExport_statement(abapParser.Export_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#import_db_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImport_db_option(abapParser.Import_db_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#import_from}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImport_from(abapParser.Import_fromContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_import_from}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_import_from(abapParser.Use1_import_fromContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#import_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImport_to(abapParser.Import_toContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#import_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImport_statement(abapParser.Import_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLine(abapParser.LineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#modify_options_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_options_clause(abapParser.Modify_options_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_page}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_page(abapParser.Use1_pageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_source}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_source(abapParser.Use1_sourceContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_fieldlist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_fieldlist(abapParser.Usedef_fieldlistContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#modify_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModify_statement(abapParser.Modify_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_language}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_language(abapParser.Use1_languageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_table}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_table(abapParser.Use_tableContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_work_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_work_area(abapParser.Use1_work_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_first}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_first(abapParser.Use1_firstContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_field_with_tablename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_field_with_tablename(abapParser.Def_field_with_tablenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_index_rule}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_index_rule(abapParser.Def_index_ruleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#insert_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsert_clause(abapParser.Insert_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#insert_first_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsert_first_clause(abapParser.Insert_first_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#insert_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInsert_statement(abapParser.Insert_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#offset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOffset(abapParser.OffsetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#node}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNode(abapParser.NodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#attribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttribute(abapParser.AttributeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#country}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCountry(abapParser.CountryContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#lang}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLang(abapParser.LangContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(abapParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#mod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMod(abapParser.ModContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#status}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatus(abapParser.StatusContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#get_cursor_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGet_cursor_option(abapParser.Get_cursor_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_attribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_attribute(abapParser.Use1_attributeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_line(abapParser.Use1_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_value(abapParser.Use1_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_length}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_length(abapParser.Use1_lengthContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_assignmentLeftHandSide}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_assignmentLeftHandSide(abapParser.Use1_assignmentLeftHandSideContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_mod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_mod(abapParser.Use1_modContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_area(abapParser.Use1_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_prog(abapParser.Use1_progContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_ref(abapParser.Def_refContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_node}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_node(abapParser.Use1_nodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_node}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_node(abapParser.Def_nodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_lang}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_lang(abapParser.Use1_langContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_country}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_country(abapParser.Use1_countryContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_offset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_offset(abapParser.Use1_offsetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#get_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGet_statement(abapParser.Get_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#value_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue_list(abapParser.Value_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_value_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_value_list(abapParser.Use1_value_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#when_clause1_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhen_clause1_stmt_line(abapParser.When_clause1_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#when_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhen_clause(abapParser.When_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#when_others_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhen_others_clause(abapParser.When_others_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#case_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase_stmt_line(abapParser.Case_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endcase_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndcase_stmt_line(abapParser.Endcase_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#case_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase_statement(abapParser.Case_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#systemexception}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSystemexception(abapParser.SystemexceptionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_systemexception}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_systemexception(abapParser.Use1_systemexceptionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#returncode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturncode(abapParser.ReturncodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_returncode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_returncode(abapParser.Use1_returncodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#catch_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCatch_stmt_line(abapParser.Catch_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endcatch_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndcatch_stmt_line(abapParser.Endcatch_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#catch_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCatch_statement(abapParser.Catch_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_cursor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_cursor(abapParser.Usedef_cursorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#close_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClose_statement(abapParser.Close_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#date}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDate(abapParser.DateContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#hexfield}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHexfield(abapParser.HexfieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_convert_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_convert_clause(abapParser.Usedef_convert_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#convert_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConvert_clause(abapParser.Convert_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#convert_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConvert_statement(abapParser.Convert_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#column}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn(abapParser.ColumnContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#handler}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHandler(abapParser.HandlerContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#modification}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModification(abapParser.ModificationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#activation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitActivation(abapParser.ActivationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#title}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTitle(abapParser.TitleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#set_pf_status_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_pf_status_option(abapParser.Set_pf_status_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_screen}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_screen(abapParser.Def_screenContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_title}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_title(abapParser.Def_titleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_handler}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_handler(abapParser.Def_handlerContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_country}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_country(abapParser.Def_countryContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_modification}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_modification(abapParser.Use1_modificationContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_language}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_language(abapParser.Def_languageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_ref(abapParser.Use1_refContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_column}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_column(abapParser.Def_columnContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_column}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_column(abapParser.Use1_columnContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_object}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_object(abapParser.Def_objectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#set_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSet_statement(abapParser.Set_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_value(abapParser.Def_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_name(abapParser.Field_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#position}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPosition(abapParser.PositionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#output_length}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutput_length(abapParser.Output_lengthContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#info}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInfo(abapParser.InfoContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#write_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_option(abapParser.Write_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#write_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_to(abapParser.Write_toContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_write_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_write_to(abapParser.Def_write_toContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_write_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_write_option(abapParser.Use1_write_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#write_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_tail(abapParser.Write_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_format}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_format(abapParser.Use1_formatContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_format_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_format_decl(abapParser.Use1_format_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_write_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_write_tail(abapParser.Use1_write_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#write_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_clause(abapParser.Write_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#write_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite_statement(abapParser.Write_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#transaction_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransaction_code(abapParser.Transaction_codeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#leave_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeave_statement(abapParser.Leave_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_transaction_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_transaction_code(abapParser.Use1_transaction_codeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#update_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpdate_statement(abapParser.Update_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#while_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhile_stmt_line(abapParser.While_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endwhile_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndwhile_stmt_line(abapParser.Endwhile_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#while_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhile_statement(abapParser.While_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sort_by_item_modifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_by_item_modifier(abapParser.Sort_by_item_modifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sort_by_item_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_by_item_field(abapParser.Sort_by_item_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_sort_by_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_sort_by_item(abapParser.Use1_sort_by_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sort_by_item}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_by_item(abapParser.Sort_by_itemContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sort_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_option(abapParser.Sort_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_FIELD_SYMBOL}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_FIELD_SYMBOL(abapParser.Usedef_FIELD_SYMBOLContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_itab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_itab(abapParser.Use_itabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sort_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_clause(abapParser.Sort_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sort_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSort_statement(abapParser.Sort_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_identifier(abapParser.Use_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_statement(abapParser.Select_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_type_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_type_expression(abapParser.Select_type_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_type_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_type_clause(abapParser.Select_type_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_expression_2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_expression_2(abapParser.Select_expression_2Context ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_option_d}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_option_d(abapParser.Select_option_dContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_option_s}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_option_s(abapParser.Select_option_sContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_expression_d}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_expression_d(abapParser.Select_expression_dContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_expression_s}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_expression_s(abapParser.Select_expression_sContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_expression(abapParser.Select_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_clause(abapParser.Select_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#hints_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHints_clause(abapParser.Hints_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_statement_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_statement_expression(abapParser.Select_statement_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_select_statement_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_select_statement_expression(abapParser.Use1_select_statement_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#in_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn_clause(abapParser.In_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_other}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_other(abapParser.Use1_otherContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#other}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOther(abapParser.OtherContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#whenever_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhenever_clause(abapParser.Whenever_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_where_clause(abapParser.Select_where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#sub_unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSub_unary_expression(abapParser.Sub_unary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_sub_unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_sub_unary_expression(abapParser.Use1_sub_unary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#equal_select_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEqual_select_expression(abapParser.Equal_select_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#paren_select_between_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParen_select_between_expression(abapParser.Paren_select_between_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_andor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_andor_expression(abapParser.Select_andor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_between_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_between_expression(abapParser.Select_between_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_select_binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_select_binary_expression(abapParser.Use1_select_binary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_binary_expression(abapParser.Select_binary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_call_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_call_expression(abapParser.Select_call_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_comparison_expression(abapParser.Select_comparison_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_from_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_from_element(abapParser.Use1_from_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#from_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFrom_element(abapParser.From_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_from_clause(abapParser.Use1_from_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#from_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFrom_clause(abapParser.From_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_into_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_into_clause(abapParser.Def_into_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_work_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_work_area(abapParser.Usedef_work_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#into_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInto_clause(abapParser.Into_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_appending_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_appending_clause(abapParser.Use1_appending_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#appending_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAppending_clause(abapParser.Appending_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_where_clause(abapParser.Use1_where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#where_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhere_clause(abapParser.Where_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#group_by_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_tail(abapParser.Group_by_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_group_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_group_by_clause(abapParser.Use1_group_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#group_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroup_by_clause(abapParser.Group_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_having_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_having_clause(abapParser.Use1_having_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#having_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHaving_clause(abapParser.Having_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#order_by_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrder_by_tail(abapParser.Order_by_tailContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_order_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_order_by_clause(abapParser.Use1_order_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#order_by_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrder_by_clause(abapParser.Order_by_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_for_all_entries_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_for_all_entries_clause(abapParser.Use1_for_all_entries_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#for_all_entries_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_all_entries_clause(abapParser.For_all_entries_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_up_to_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_up_to_clause(abapParser.Use1_up_to_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#up_to_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUp_to_clause(abapParser.Up_to_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#alias}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlias(abapParser.AliasContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#textfield}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTextfield(abapParser.TextfieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#pos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPos(abapParser.PosContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#open_dataset_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpen_dataset_option(abapParser.Open_dataset_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_pos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_pos(abapParser.Use1_posContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_filename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_filename(abapParser.Use1_filenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_textfield}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_textfield(abapParser.Use1_textfieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#open_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpen_statement(abapParser.Open_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#select_d_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelect_d_stmt_line(abapParser.Select_d_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#endselect_stmt_line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndselect_stmt_line(abapParser.Endselect_stmt_lineContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_target}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_target(abapParser.Def_targetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#unpack_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnpack_statement(abapParser.Unpack_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#unassign_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnassign_statement(abapParser.Unassign_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#wait_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWait_statement(abapParser.Wait_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_LITERAL_ID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_LITERAL_ID(abapParser.Use1_LITERAL_IDContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_LITERAL_ID}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_LITERAL_ID(abapParser.Usedef_LITERAL_IDContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#window_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWindow_statement(abapParser.Window_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_pattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_pattern(abapParser.Def_patternContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_pattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_pattern(abapParser.Use1_patternContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#pattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPattern(abapParser.PatternContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#shift_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShift_clause(abapParser.Shift_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#shift_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShift_statement(abapParser.Shift_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#split_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSplit_statement(abapParser.Split_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#uline_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUline_statement(abapParser.Uline_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#codepage}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCodepage(abapParser.CodepageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_codepage}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_codepage(abapParser.Use1_codepageContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#translate_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTranslate_clause(abapParser.Translate_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#translate_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTranslate_statement(abapParser.Translate_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#transfer_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransfer_statement(abapParser.Transfer_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#subtract_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubtract_clause(abapParser.Subtract_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_subtract_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_subtract_clause(abapParser.Use1_subtract_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#subtract_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubtract_statement(abapParser.Subtract_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#report}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReport(abapParser.ReportContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_report}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_report(abapParser.Use1_reportContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_with_report_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_with_report_name(abapParser.Field_with_report_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_field_with_report_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_field_with_report_name(abapParser.Use1_field_with_report_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#submit_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubmit_option(abapParser.Submit_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_submit_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_submit_option(abapParser.Use1_submit_optionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#submit_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubmit_statement(abapParser.Submit_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_filename}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_filename(abapParser.Def_filenameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#search_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSearch_statement(abapParser.Search_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#scroll_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScroll_statement(abapParser.Scroll_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#divide_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDivide_statement(abapParser.Divide_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#multiply_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiply_statement(abapParser.Multiply_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#add_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_statement(abapParser.Add_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#add_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_clause(abapParser.Add_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_add_target}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_add_target(abapParser.Usedef_add_targetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#add_target}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdd_target(abapParser.Add_targetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#collect_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollect_clause(abapParser.Collect_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#collect_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollect_statement(abapParser.Collect_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#commit_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommit_statement(abapParser.Commit_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#rollback_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRollback_statement(abapParser.Rollback_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#continue_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinue_statement(abapParser.Continue_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#program_field}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram_field(abapParser.Program_fieldContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#context}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContext(abapParser.ContextContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_context}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_context(abapParser.Use1_contextContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#demand_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDemand_statement(abapParser.Demand_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#supply_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSupply_statement(abapParser.Supply_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#backup_tab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBackup_tab(abapParser.Backup_tabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_backup_tab}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_backup_tab(abapParser.Def_backup_tabContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_title}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_title(abapParser.Use1_titleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#editor_call_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEditor_call_statement(abapParser.Editor_call_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#fetch_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFetch_statement(abapParser.Fetch_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#process_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProcess_statement(abapParser.Process_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#replace_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplace_clause(abapParser.Replace_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#find_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFind_statement(abapParser.Find_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#replace_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReplace_statement(abapParser.Replace_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#message_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMessage_class(abapParser.Message_classContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_message_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_message_class(abapParser.Use1_message_classContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#number_of_columns}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber_of_columns(abapParser.Number_of_columnsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_number_of_columns}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_number_of_columns(abapParser.Use1_number_of_columnsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#number_of_lines}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber_of_lines(abapParser.Number_of_linesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_number_of_lines}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_number_of_lines(abapParser.Use1_number_of_linesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#number_of_footer_lines}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber_of_footer_lines(abapParser.Number_of_footer_linesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_number_of_footer_lines}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_number_of_footer_lines(abapParser.Use1_number_of_footer_linesContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#logical_database}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogical_database(abapParser.Logical_databaseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_logical_database}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_logical_database(abapParser.Def_logical_databaseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#check_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCheck_clause(abapParser.Check_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#check_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCheck_statement(abapParser.Check_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#ret}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRet(abapParser.RetContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#r_buffer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR_buffer(abapParser.R_bufferContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#communication_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommunication_statement(abapParser.Communication_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_ret}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_ret(abapParser.Use1_retContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_type(abapParser.Use1_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_info}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_info(abapParser.Use1_infoContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_buffer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_buffer(abapParser.Use1_bufferContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_dest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_dest(abapParser.Use1_destContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_dest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_dest(abapParser.Def_destContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_status}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_status(abapParser.Use1_statusContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_event}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_event(abapParser.Use1_eventContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_default_rule}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_default_rule(abapParser.Use1_default_ruleContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#control_type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControl_type(abapParser.Control_typeContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#events_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEvents_statement(abapParser.Events_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#fieldgroup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFieldgroup(abapParser.FieldgroupContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_fieldgroup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_fieldgroup(abapParser.Use1_fieldgroupContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#extract_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExtract_statement(abapParser.Extract_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_groups_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_groups_statement(abapParser.Field_groups_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_symbols_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_symbols_clause(abapParser.Field_symbols_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_class(abapParser.Use1_classContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#field_symbols_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitField_symbols_statement(abapParser.Field_symbols_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#color}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColor(abapParser.ColorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#format_decl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFormat_decl(abapParser.Format_declContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#format_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFormat_statement(abapParser.Format_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#dataobject}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDataobject(abapParser.DataobjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#free_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFree_statement(abapParser.Free_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_dataobject}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_dataobject(abapParser.Def_dataobjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_key(abapParser.Def_keyContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#data}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitData(abapParser.DataContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_data}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_data(abapParser.Use1_dataContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#hide_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHide_statement(abapParser.Hide_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#nnnn}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNnnn(abapParser.NnnnContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_nnnn}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_nnnn(abapParser.Use1_nnnnContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#roll_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRoll_area(abapParser.Roll_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#infotypes_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInfotypes_statement(abapParser.Infotypes_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_name(abapParser.Use1_nameContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_roll_area}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_roll_area(abapParser.Use1_roll_areaContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_SPACE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_SPACE(abapParser.Use1_SPACEContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_parameter_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_parameter_options(abapParser.Use1_parameter_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#parameter_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameter_options(abapParser.Parameter_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#parameters_clause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameters_clause(abapParser.Parameters_clauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#parameters_form}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParameters_form(abapParser.Parameters_formContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment(abapParser.AssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assignmentLeftHandSide_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignmentLeftHandSide_stmt(abapParser.AssignmentLeftHandSide_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_andor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_andor_expression(abapParser.Use1_andor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use_andor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse_andor_expression(abapParser.Use_andor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_andor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_andor_expression(abapParser.Def_andor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#andor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAndor_expression(abapParser.Andor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#paren_andor_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParen_andor_expression(abapParser.Paren_andor_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#between_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBetween_expression(abapParser.Between_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#comparison_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparison_expression(abapParser.Comparison_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinary_expression(abapParser.Binary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_binary_expression(abapParser.Use1_binary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_binary_expression(abapParser.Def_binary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_binary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_binary_expression(abapParser.Usedef_binary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#call_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCall_expression(abapParser.Call_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#arrow_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrow_expression(abapParser.Arrow_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#prefix_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrefix_operator(abapParser.Prefix_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#prefix_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrefix_expression(abapParser.Prefix_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#is_initial_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIs_initial_expression(abapParser.Is_initial_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#predefined_fields_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPredefined_fields_lex(abapParser.Predefined_fields_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_predefined_fields_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_predefined_fields_lex(abapParser.Use1_predefined_fields_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_predefined_fields_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_predefined_fields_lex(abapParser.Def_predefined_fields_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_predefined_fields_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_predefined_fields_lex(abapParser.Usedef_predefined_fields_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#unary_identifier_lex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnary_identifier_lex(abapParser.Unary_identifier_lexContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#unary_identifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnary_identifier(abapParser.Unary_identifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnary_expression(abapParser.Unary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#use1_unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse1_unary_expression(abapParser.Use1_unary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_unary_expression(abapParser.Def_unary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#usedef_unary_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUsedef_unary_expression(abapParser.Usedef_unary_expressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assignmentLeftHandSide}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignmentLeftHandSide(abapParser.AssignmentLeftHandSideContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#def_assignmentLeftHandSide}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef_assignmentLeftHandSide(abapParser.Def_assignmentLeftHandSideContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#assignment_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment_operator(abapParser.Assignment_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#andor_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAndor_operator(abapParser.Andor_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#comparison_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparison_operator(abapParser.Comparison_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#binary_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinary_operator(abapParser.Binary_operatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link abapParser#arrow_operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrow_operator(abapParser.Arrow_operatorContext ctx);
}