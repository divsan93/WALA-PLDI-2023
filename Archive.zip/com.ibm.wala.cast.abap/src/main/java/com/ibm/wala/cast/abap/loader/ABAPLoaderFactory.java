package com.ibm.wala.cast.abap.loader;

import com.ibm.wala.cast.abap.translator.ABAPTranslatorFactory;
import com.ibm.wala.cast.abap.translator.CAstABAPTranslator;
import com.ibm.wala.cast.abap.types.ABAPTypes;
import com.ibm.wala.cast.loader.SingleClassLoaderFactory;
import com.ibm.wala.cast.tree.rewrite.CAstRewriterFactory;
import com.ibm.wala.classLoader.IClassLoader;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.types.ClassLoaderReference;

public class ABAPLoaderFactory extends SingleClassLoaderFactory {
    protected final CAstABAPTranslator translatorFactory;
    protected final CAstRewriterFactory<?, ?> preprocessor;

    public ABAPLoaderFactory(CAstABAPTranslator factory) {
        this(factory, null);
    }

    public ABAPLoaderFactory(
            CAstABAPTranslator factory, CAstRewriterFactory<?, ?> preprocessor) {
        this.translatorFactory = factory;
        this.preprocessor = preprocessor;
    }

    @Override
    protected IClassLoader makeTheLoader(IClassHierarchy cha) {
        return new ABAPLoader(cha, translatorFactory, preprocessor);
    }

    @Override
    public ClassLoaderReference getTheReference() {
        return ABAPTypes.abLoader;
    }
}